//
//  LSShareItemCell.h
//  LSShare
//
//  Created by aaaaa aaaaa on 2019/12/12.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LSShareItemCell : UICollectionViewCell
@property (weak, nonatomic) UIImageView *imageView;
@property (weak, nonatomic) UILabel *textLabel;

@end

NS_ASSUME_NONNULL_END
