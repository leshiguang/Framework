//
//  LSShareFootReusableView.h
//  Pods
//
//  Created by aaaaa aaaaa on 2019/12/17.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LSShareFootReusableView : UICollectionReusableView

@property (nonatomic, strong) UIButton *button;

@end

NS_ASSUME_NONNULL_END
