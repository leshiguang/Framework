//
//  LZWxTools.h
//  Pods
//
//  Created by aaaaa aaaaa on 2020/1/19.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LZWxTools : NSObject

+ (UIImage * _Nullable)image:(UIImage *)image reSizeImagetoSize:(CGSize)reSize;

+ (UIViewController *)topViewController;

@end

NS_ASSUME_NONNULL_END
