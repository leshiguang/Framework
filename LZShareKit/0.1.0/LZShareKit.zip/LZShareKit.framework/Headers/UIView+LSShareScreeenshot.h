//
//  UIView+LSShareScreeenshot.h
//  Pods
//
//  Created by aaaaa aaaaa on 2019/12/16.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIView (LSShareScreeenshot)

- (nullable UIImage *)ls_sh_screenshot;


- (nullable UIImage *)ls_sh_screenshotWithSize:(CGSize)size;


- (void)ls_sh_screenshotCompletionHandler:(void(^)(UIImage *image))completionHandler;

/// 绘制出分享的图片
/// @param image 正图
/// @param logoImage logo
/// @param qrImage 二维码
+ (UIImage *)ls_sh_screenImageWithImage:(UIImage *)image logoImage:(UIImage *)logoImage qrImage:(nullable UIImage *)qrImage;

@end



NS_ASSUME_NONNULL_END
