//
//  LSShareScreenView.h
//  Pods
//
//  Created by aaaaa aaaaa on 2019/12/17.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LSShareScreenView : UIView

@property (nonatomic, strong) UIImageView *logoImageView;
@property (nonatomic, strong) UIImageView *qrImageView;
@property (nonatomic, strong) UIImageView *screenImageView;

@end

NS_ASSUME_NONNULL_END
