//
//  LSShareViewController.h
//  Pods
//
//  Created by aaaaa aaaaa on 2019/12/12.
//

#import <UIKit/UIKit.h>
#import "LSShareConfig.h"


NS_ASSUME_NONNULL_BEGIN

@interface LSShareViewController : UIViewController

/// 分享配置
/// @param config 分享配置
/// @param completion 完成回调
+ (instancetype)shareWithConfig:(LSShareConfig *)config completion:(LSShareCompletion)completion;

@end

NS_ASSUME_NONNULL_END
