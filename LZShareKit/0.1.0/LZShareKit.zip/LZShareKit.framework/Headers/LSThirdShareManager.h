//
//  LSThirdShareManager.h
//  Pods
//
//  Created by aaaaa aaaaa on 2019/12/16.
//

#import <Foundation/Foundation.h>
#import "LSShareConfig.h"

NS_ASSUME_NONNULL_BEGIN

@interface LSThirdShareManager : NSObject

+ (instancetype)sharedInstance;

/// 分享到对应的类型
/// @param shareType 类型
/// @param config 配置
/// @param screenshotImage 截图
/// @param completion 回调
- (void)shareWithType:(LSShareType)shareType config:(LSShareConfig *)config screenshotImage:(UIImage *)screenshotImage completion:(LSShareCompletion)completion;


@end

NS_ASSUME_NONNULL_END
