//
//  LSShareConfig.h
//  LZShareKit
//
//  Created by tanjian on 2021/5/12.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, LSShareContentType) {
    /// 分享图片
    LSShareContentTypeImage,
    /// 分享url
    LSShareContentTypeUrl,
    /// 分享小程序
    LSShareContentTypeWxMiniProgram,
    /// 分享pdf
    LSShareContentTypePdf,
};

typedef NS_ENUM(NSUInteger, LSShareResult) {
    /// 成功
    LSShareResultSuccess = 0,
    /// 失败
    LSShareResultFailed,
    /// 取消
    LSShareResultCancel,
};

typedef NS_ENUM(NSUInteger, LSShareType) {
    /// 微信
    LSShareTypeWechat       = 1,
    
    /// 朋友圈
    LSShareTypeWechatFriend = 2,
    
    /// QQ
    LSShareTypeQQ           = 3,
    
    /// 新浪微博
    LSShareTypeSina         = 4,
    
    /// 微信小程序
    LSShareTypeWxMiniProgram  = 100,
    
    /// 截图
    LSShareTypeScreenshot   = 1000,
    
    /// 复制url
    LSShareTypeCopyUrl      = 1001,
    
    /// 保存图片
    LSShareTypeSaveImage    = 1002,
    
    /// 更多（系统分享）
    LSShareTypeTypeMore        = 1003,
};

/// 分享完成的回调
typedef void(^LSShareCompletion)(LSShareResult code, NSString *msg);

@interface LSShareConfig : NSObject

/// 分型的类型
@property (nonatomic, assign) LSShareContentType contentType;

/// 标题
@property (nonatomic, nullable) NSString *title;

/// 副标题
@property (nonatomic, nullable) NSString *des;

/// 缩略图 二选一
@property (nonatomic, nullable) UIImage *thumbImage;
@property (nonatomic, nullable) NSData *thumImageData;

/// 分享的图片 二选一 (小程序的图像必须要使用imageData)
@property (nonatomic, nullable) UIImage *image;
@property (nonatomic, nullable) NSData *imageData;

/// 分享的url
@property (nonatomic, nullable) NSString *url;

/// 分享文件的本地路径， 或小程序的页面路径
@property (nonatomic, nullable) NSString *path;

/// 分享的type 参考 LSShareType
@property (nonatomic, nullable) NSArray <NSNumber *> *shareTypes;

/// 从哪个View分享的，用于截图
@property (nonatomic, nullable) UIView *fromView;

/// 二维码图片,  用于图片合成
@property (nonatomic, nullable) NSString *qrCodeUrl;


/// 小程序专用  小程序的userName
@property (nonatomic, nullable) NSString *userName;

@end

NS_ASSUME_NONNULL_END
