//
//  LSSharePresentationcontroller.h
//  LSShare
//
//  Created by aaaaa aaaaa on 2019/12/12.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

FOUNDATION_EXPORT NSString * const LSSharePresentationScreenImageKey;
FOUNDATION_EXPORT NSString * const LSSharePresentationQRCodeURLKey;

typedef void(^LSSharePresentationClickedHandle)(void);

@interface LSSharePresentationcontroller : UIPresentationController <UIViewControllerAnimatedTransitioning>

@property (nonatomic, readonly) UIView *dimmingView;

@property (nonatomic, copy) LSSharePresentationClickedHandle clickedHandle;


/// 截图
@property (nonatomic, readonly) UIImage *screenImage;

/// 显示截图
/// @param options 配置
- (void)showScreenViewWithOption:(NSDictionary *)options;



@end

NS_ASSUME_NONNULL_END
