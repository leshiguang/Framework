//
//  LZShareKit.h
//  LZShareKit
//
//  Created by tanjian on 2021/5/12.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/*
 下面就是一些key的参数
 
 
 /// 分型的类型
 LSShareContentType contentType;

 /// 标题
 NSString *title;

 /// 副标题
 NSString *des;

 /// 缩略图 二选一
 UIImage *thumbImage;
 NSData *thumImageData;

 /// 分享的图片 二选一 (小程序的图像必须要使用imageData)
 UIImage *image;
 NSData *imageData;

 /// 分享的url
 NSString *url;

 /// 分享文件的本地路径， 或小程序的页面路径
 NSString *path;

 /// 分享的type 参考 LSShareType
 NSArray <NSNumber *> *shareTypes;

 /// 从哪个View分享的，用于截图
 UIView *fromView;

 /// 二维码图片,  用于图片合成
 NSString *qrCodeUrl;


 /// 小程序专用  小程序的userName
 NSString *userName;
 */

@interface LZShareKit : NSObject

+ (instancetype)sharedInstance;

- (void)shareWithConfig:(NSDictionary *)config completion:(void(^)(int code, NSString *msg))completion;

/// 注册微信
/// @param appid 微信appid
/// @param universalLink universalLink
- (BOOL)registerWxApp:(NSString *)appid universalLink:(NSString *)universalLink;

/// 处理回调
- (BOOL)handleUrl:(NSURL *)url;

/// 处理UniversalLink回调
- (BOOL)handleOpenUniversalLink:(NSUserActivity *)userActivity;

@end

NS_ASSUME_NONNULL_END
