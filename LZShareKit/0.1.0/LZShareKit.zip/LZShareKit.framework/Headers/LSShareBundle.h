//
//  LSShareBundle.h
//  Pods
//
//  Created by aaaaa aaaaa on 2019/12/17.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LSShareBundle : NSObject

+ (NSBundle *)bundle;

@end

NS_ASSUME_NONNULL_END
