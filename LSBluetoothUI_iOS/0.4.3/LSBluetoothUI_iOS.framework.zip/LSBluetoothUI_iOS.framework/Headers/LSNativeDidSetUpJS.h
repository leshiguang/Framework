//
//  LSNativeDidSetUpJS.h
//  LSWearable
//
//  Created by Wenzheng Zhang on 2017/5/26.
//  Copyright © 2017年 lifesense. All rights reserved.
//

#import <Foundation/Foundation.h>

NSString *LSNativeDidSetUpJS(void);
