//
//  LSWMacro.h
//  LSWearable
//
//  Created by wenZheng Zhang on 16/1/14.
//  Copyright © 2016年 lifesense. All rights reserved.
//

#ifndef LSWMacro_h
#define LSWMacro_h

#define SYSTEM_VERSION_EQUAL_TO(v) ([[[UIDevice currentDevice] systemVersion] compare:[NSString stringWithFormat:@"%.1f",v] options:NSNumericSearch] == NSOrderedSame)
#define SYSTEM_VERSION_GREATER_THAN(v) ([[[UIDevice currentDevice] systemVersion] compare:[NSString stringWithFormat:@"%.1f",v] options:NSNumericSearch] == NSOrderedDescending)
#define SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v) ([[[UIDevice currentDevice] systemVersion] compare:[NSString stringWithFormat:@"%.1f",v] options:NSNumericSearch] != NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN(v) ([[[UIDevice currentDevice] systemVersion] compare:[NSString stringWithFormat:@"%.1f",v] options:NSNumericSearch] == NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN_OR_EQUAL_TO(v) ([[[UIDevice currentDevice] systemVersion] compare:[NSString stringWithFormat:@"%.1f",v] options:NSNumericSearch] != NSOrderedDescending)

#define kLSScreenScale(number) ([[UIScreen mainScreen]bounds].size.width / 375 * number)

#endif /* LSWMacro_h */
