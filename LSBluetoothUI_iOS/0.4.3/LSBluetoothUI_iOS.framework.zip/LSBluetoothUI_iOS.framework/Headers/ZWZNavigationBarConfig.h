//
//  ZWZNavigationBarConfig.h
//  LSWearable
//
//  Created by Wenzheng Zhang on 2017/8/1.
//  Copyright © 2017年 lifesense. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZWZNavigationBarConfig : NSObject <NSCopying>
@property (nonatomic, strong) UIColor *backgroundColor;
@property (nonatomic, assign) BOOL lineViewHidden;

/**
 id一样，两个config除backgroundColor外其他的都认为一致
 */
//@property (nonatomic, assign) NSString *configId;
@property (nonatomic, strong) UIImage *backButtonImage;
//@property (nonatomic, assign) BOOL shouldRenderBackButtonImageAsOrigin;
@property (nonatomic, strong) UIColor *titleTextColor;
@property (nonatomic, strong) UIFont *titleTextFont;
@property (nonatomic, strong) UIColor *tintColor;
@property (nonatomic, assign) UIStatusBarStyle statusBarStyle;
@property (nonatomic, assign) CGFloat lineViewAlaph;
@end
