//
//  LSDeviceManager.h
//  FBSnapshotTestCase
//
//  Created by tanjian on 2020/12/23.
//

#import <Foundation/Foundation.h>
#import "LSDevice.h"
#import "LSDevice+Utility.h"
#import "LSDeviceManagerDefine.h"
#import "LSDeviceManagerDelegate.h"

#import "LSSettingUtil.h"

#import "LSEDeviceInfo.h"
#import "LSEProductInfo.h"

#import <LZBluetooth/LZBluetooth.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^LSDeviceSettingBlock)(LSDeviceSetResult result);
typedef void(^LSSearchBlock)(LSDevice *info, NSInteger rssi);
typedef void(^LSEStopSearchBlock)(BOOL isStop);

@interface LSDeviceManager : NSObject

/// 当退出登陆的时候，currentUserId为空
@property (nonatomic, readonly, nullable) NSString *currentUserId;

/// 蓝牙是否可用
@property (nonatomic, assign, readonly) BOOL isBluetoothEnabled;

/// 单例初始化
+ (instancetype)shareInstance;

/// 增加代理
/// @param delegate 代理
- (void)addDelegate:(id<LSDeviceManagerDelegate>)delegate;

/// 删除代理
/// @param delegate 代理
- (void)removeDlegate:(id<LSDeviceManagerDelegate>)delegate;

/// 退出登录时/切换账号时调用一次
- (void)logout;

/// 登录成功后调用
/// @param userId userId
- (void)loginWithUserId:(NSString *)userId;

/// 获取当前版本号
+ (NSString *)getVersion;

/// 发送数据到设备
/// @param model 数据
/// @param device 设备
/// @param completion 回调
- (void)sendData:(id<LZDeviceSettingProtocol>)model
        toDevice:(LSDevice *)device
      completion:(LZSendDataCompletion)completion;

/// 删除事件提醒
/// @param model 事件
/// @param device 设备
/// @param completion 回调
- (void)deleteWithEventReminder:(LZA5SettingEventRemindData *)model toDevice:(LSDevice *)device completion:(LZSendDataCompletion)completion;

/// 获取该类型的设置
/// @param deviceId 设备id
/// @param settingType 设置类型
/// @return 设置项，可能是id<LZDeviceSettingProtocol>，或者NSArray<id<LZDeviceSettingProtocol>>
- (id)getSettingDataWithDeviceId:(NSString *)deviceId
                     settingType:(LZDeviceSettingType)settingType;

/// 搜索设备,在结束配对流程后需要调用调用startDataReceiveService
/// @param searchBlock 设备信息回调
- (void)searchDeviceBlock:(LSSearchBlock)searchBlock;

/// 停止搜索设备
- (void)stopSearchDevice;

/// 获取已绑定设备列表
- (NSArray <LSDevice *> *)getBoundDevices;

/// 获取已绑定设备列表
- (NSArray <LSDevice *> *)getBoundBandDevices;

/// 获取活跃设备
- (nullable LSDevice *)getActivityDevice;

/// 同步数据
- (void)syncFromServerCompletion:(void(^)(int code,NSString *msg))completion;

/// 获取产品信息
- (NSArray <LSEProductInfo *> *)getProductInfoListAry;

@end

NS_ASSUME_NONNULL_END
