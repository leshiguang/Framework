//
//  LSBluetoothUI.h
//  LSBluetoothUI_iOS
//
//  Created by tanjian on 2021/2/8.
//

#import <Foundation/Foundation.h>
#import <LSBluetoothUI_iOS/LSDevice.h>
#import <LSBluetoothUI_iOS/LSDeviceManagerDelegate.h>
#import <LSBluetoothUI_iOS/LSReceiveDataHeader.h>
#import <LZBluetooth/LZBluetooth.h>


NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, LSPage) {
    /// 步数页面
    LSPageStep,
    /// 血压页面
    LSPageBloodPressure,
    /// 心率
    LSPageHr,
    /// 体重
    LSPageWeight,
    /// 睡眠
    LSPageSleep,
    /// 设备列表
    LSPageDeviceList
};

@interface LSBluetoothUIConfig : NSObject

/// 租户ID，用来隔离数据和服务，公司唯一
@property (nonatomic, strong) NSString *appKey;
/// 订阅ID，标识订阅的服务和隔离数据，应用唯一
@property (nonatomic, strong) NSString *appSecret;
/// 渠道
@property (nonatomic, strong) NSString *tn;
/// 是否打印日志，及是否显示vConsole
@property (nonatomic, assign, getter=isDebug) BOOL debug;

@end

@interface LSBluetoothUI : NSObject

/// 初始化只能调用一次（多次无效）
/// @param config 初始化
+ (void)initWithConfig:(LSBluetoothUIConfig *)config;

/// 登陆用户id（主要作用是标示用户的）
/// @param associatedId 用户id
/// @param completion 回调
+ (void)loginWithAssociatedId:(NSString *)associatedId completion:(void(^)(BOOL result))completion;

/// 用户退出的时候调用
+ (void)logout;

/// 直接跳转某页面，会获取到[UIApplication sharedApplication].delegate.window 上的nav然后push
/// @param page 页面类型
+ (void)openPage:(LSPage)page;

/// 通过页面类型获取到对应的viewController
/// @param page 页面类型
+ (UIViewController *)viewControllerWithPage:(LSPage)page;

/// 只有登陆的情况下才能获取到已绑定设备
+ (nullable NSArray <LSDevice *> *)getBoundDevices;

/// 设置代理
/// @param delegate 代理
+ (void)addDelegate:(id<LSDeviceManagerDelegate>)delegate;

/// 删除代理
/// @param delegate 代理
+ (void)removeDelegate:(id<LSDeviceManagerDelegate>)delegate;

/// 设置到手环
/// @param setting 设置项
/// @param device 设备
/// @param completion 回调
+ (void)setSetting:(id<LZDeviceSettingProtocol>)setting device:(LSDevice *)device completion:(void(^)(LZBluetoothErrorCode code))completion;

/// 版本号
+ (NSString *)version;

@end

NS_ASSUME_NONNULL_END
