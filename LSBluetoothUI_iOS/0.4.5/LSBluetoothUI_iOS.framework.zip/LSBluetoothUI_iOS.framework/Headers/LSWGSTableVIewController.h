//
//  LSWGSTableVIewController.h
//  LSWearable
//
//  Created by wenZheng Zhang on 16/2/12.
//  Copyright © 2016年 lifesense. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZWZLoadMoreControl.h"
#import "LSWGSTableViewBackgroundView.h"
#import "LSWBaseViewController.h"


@interface LSWGSTableVIewController : LSWBaseViewController <UITableViewDataSource, UITableViewDelegate, ZWZLoadMoreControlDataSource, ZWZLoadMoreControlDelegate, LSWGSTableViewBackgroundViewDelegate>
@property (nonatomic, readonly) UITableView *tableView;
@property (nonatomic, readonly) ZWZLoadMoreControl *loadMoreControl;
@property (nonatomic, strong, readonly) LSWGSTableViewBackgroundView *tableViewBackgroundView;


/**
 是否需要添加加载更多控件，默认YES。若需要设置此属性，请在VC的view加载之前设置，否则不生效
 */
@property (nonatomic, assign) BOOL shouldAddLoadMoreControl;

/**
 初始化LSWGSTableVIewController

 @param initailContentInsets 初始的tableView.contentInsets，通常为UIEdgeInsetsZero

 @return LSWGSTableVIewController实例
 */
- (instancetype)initWithInitialContentInsets:(UIEdgeInsets)initailContentInsets;


/**
  初始化LSWGSTableVIewController

 @param initailContentInsets 初始的tableView.contentInsets，通常为UIEdgeInsetsZero
 @param tableViewType        tableViewStyle类型

 @return LSWGSTableVIewController实例
 */
- (instancetype)initWithInitialContentInsets:(UIEdgeInsets)initailContentInsets tableType:(UITableViewStyle)tableViewType;


/**
 在tableViewBackgroundView上显示提示消息

 @param message    提示消息
 @param state      状态
 @param edgeInsets backgroundView四周的insets，可用于居中backgroundView的内容
 */
- (void)showMessage:(NSString *)message withState:(LSWGSTableViewBackgroundViewState)state edgeInsets:(UIEdgeInsets)edgeInsets;


/**
 设置backgroundView无数据时的提示消息所对应的image

 @param image image
 */
- (void)setIconImageForNoDataView:(UIImage *)image;

@end
