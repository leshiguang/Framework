//
//  NSBundle+LSBluetoothUI.h
//  LSBluetoothUI_iOS
//
//  Created by wm on 2020/9/9.
//

#import <Foundation/Foundation.h>

#define LSBluetoothUILocal(str) [NSBundle ls_localizedStringForKey:str]

#define IsLocalizedZH [NSBundle isLanguageCN]

#define LSBluetoothUIImage(name) [NSBundle ls_bluetoothUIImage:name]

#define LSLocalImage(name) [NSBundle imageWithName:name]

#define LSBluetoothPlistPath(plistName) [NSBundle ls_bluetoothPlistPathWihtName:plistName]

NS_ASSUME_NONNULL_BEGIN

@interface NSBundle (LSBluetoothUI)

//获取bundle;
+ (instancetype)ls_BluetoothUIBundle;

/// 获取图片
/// @param imageName 图片名称
+ (UIImage *)ls_bluetoothUIImage:(NSString *)imageName;

/// 获取文字
/// @param key 文字key值
+ (NSString *)ls_localizedStringForKey:(NSString *)key;

/// 当前是否是中文
+ (BOOL)isLanguageCN;

/// 图片name格式xxx_cn/xxx_en，用于中英文图片资源不同的情况
/// @param name 图片名称(不需要_cn/_en后缀)
+ (UIImage *)imageWithName:(NSString *)name;

/// 获取plist文件路径
/// @param plistName plist文件名称
+ (NSString *)ls_bluetoothPlistPathWihtName:(NSString *)plistName;

@end

NS_ASSUME_NONNULL_END
