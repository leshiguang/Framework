//
//  WDTitleView.h
//  WDGroup
//
//  Created by wenZheng Zhang on 15/12/22.
//  Copyright © 2015年 WDG. All rights reserved.
//

#import <UIKit/UIKit.h>
@class WDTitleView;

@protocol WDTitleViewDelegate <NSObject>
@optional
- (void)titleViewDidTapShowMoreButton:(WDTitleView *)titleView;
- (void)titleViewDidTapHideMoreButton:(WDTitleView *)titleView;
@end

@interface WDTitleView : UIView
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *subTitle;

@property (nonatomic, copy) NSString *leftImageURL;
@property (nonatomic, copy) NSString *rightImageURL;

@property (nonatomic, strong) UIImageView *leftImageView;
@property (nonatomic, strong) UIImageView *rightImageView;

@property (nonatomic, copy) dispatch_block_t rightImageViewClickBlock;
@property (nonatomic, copy) dispatch_block_t leftImageViewClickBlock;
@property (nonatomic, copy) dispatch_block_t titleLabelClickBlock;

@property (nonatomic, assign) BOOL showMoreIocn;
@property (nonatomic, weak) id <WDTitleViewDelegate> delegate;
@property (nonatomic, strong) UIColor *titleColor;

- (void)changeShowingStatus;
- (void)setContentAlpha:(CGFloat)alpha;

- (void)reset;

@end
