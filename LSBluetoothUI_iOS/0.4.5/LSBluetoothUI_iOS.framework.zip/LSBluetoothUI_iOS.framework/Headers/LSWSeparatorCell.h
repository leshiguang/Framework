//
//  LSWSeparatorCell.h
//  LSWearable
//
//  Created by wenZheng Zhang on 16/1/25.
//  Copyright © 2016年 lifesense. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@protocol LSWSeparatorCell <NSObject>
@required
@property (nonatomic, strong, readonly) UIImageView *separatorLineImageView;
@property (nonatomic) UIEdgeInsets separatorLineImageViewInsets;
@end
