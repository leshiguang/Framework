//
//  LSWOTAUpgradingViewController.h
//  LSWearable
//
//  Created by ZhangWenzheng on 16/5/12.
//  Copyright © 2016年 lifesense. All rights reserved.
//

#import "LSWBaseViewController.h"

@class LSDevice;

@interface LSWOTAUpgradingViewController : LSWBaseViewController
@property (nonatomic, strong) LSDevice *deviceInfo;
@property (nonatomic, strong) NSDictionary *otaDict;
@property (nonatomic, assign) BOOL fromUpdateFailed;
@end
