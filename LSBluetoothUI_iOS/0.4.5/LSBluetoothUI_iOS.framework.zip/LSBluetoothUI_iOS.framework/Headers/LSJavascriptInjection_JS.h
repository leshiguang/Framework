//
//  LSJavascriptInjection_JS.h
//  LSWearable
//
//  Created by Wenzheng Zhang on 2017/5/3.
//  Copyright © 2017年 lifesense. All rights reserved.
//

#import <Foundation/Foundation.h>
//借鉴WebViewJavascriptBridge框架的实现原理
NSString *LSJavascriptBridgeInjection_js(NSString *syncMessageCallScheme);

