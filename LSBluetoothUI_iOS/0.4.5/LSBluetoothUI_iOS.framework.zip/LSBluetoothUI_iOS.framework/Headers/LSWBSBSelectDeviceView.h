//
//  LSWBSBSelectDeviceView.h
//  LSWearable
//
//  Created by Wenzheng Zhang on 2017/3/7.
//  Copyright © 2017年 lifesense. All rights reserved.
//  选择需要绑定的设备页面

#import <UIKit/UIKit.h>


@class LSWBSBSelectDeviceView;
@class LSDevice;
@class LSEProductInfo;

@protocol LSWBSBSelectDeviceViewDelegate <NSObject>
@optional
- (void)selectDeviceView:(LSWBSBSelectDeviceView *)selectDeviceView didSelectDeviceAtIndex:(NSInteger)index;
@end

@interface LSWBSBSelectDeviceView : UIView
@property (nonatomic, weak) id<LSWBSBSelectDeviceViewDelegate> delegate;
@property (nonatomic, strong, readonly) NSArray<LSDevice *> *rawDeviceInfos;

- (void)setUpWithRawDeviceInfos:(NSArray<LSDevice *> *)rawDeviceInfos productInfo:(LSEProductInfo *)productInfo isUseProductInfoName:(BOOL)isUseProductInfoName;
@end
