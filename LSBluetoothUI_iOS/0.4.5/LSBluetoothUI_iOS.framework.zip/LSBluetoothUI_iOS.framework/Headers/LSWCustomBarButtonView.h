//
//  LSWCustomBarButtonView.h
//  LSWearable
//
//  Created by Wenzheng Zhang on 2017/9/22.
//  Copyright © 2017年 lifesense. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LSWAppAppearanceConfigrationConstants.h"

NS_ASSUME_NONNULL_BEGIN

@interface LSWCustomBarButtonViewItem : NSObject
@property (nonatomic, nullable, readonly) SEL action;
@property (nonatomic, nullable, weak, readonly) id target;
@property (nonatomic, nullable, strong, readonly) UIImage *image;
@property (nonatomic, nullable, strong, readonly) NSString *title;
@property (nonatomic, assign, readonly) LSWNavigationBarStyle style;

- (instancetype)initWithImage:(nonnull UIImage *)image badge:(nullable NSString *)badge target:(id)target action:(SEL)action;
- (nullable instancetype)initWithImage:(nonnull UIImage *)image target:(nullable id)target action:(nullable SEL)action;
- (nullable instancetype)initWithTitle:(nonnull NSString *)title target:(nullable id)target action:(nullable SEL)action style:(LSWNavigationBarStyle)style;
- (instancetype)initWithImage:(nullable UIImage *)image urlStr:(nullable NSURL *)url title:(nullable NSString *)title target:(id)target action:(SEL)action;
@end

@interface LSWCustomBarButtonView : UIView

/**
 与此View关联的BarButtonView
 */
@property (nonatomic, weak, nullable) UIBarButtonItem *parentBarButtonItem;

/**
 创建包含多个button的UIBarButtonItem

 @param items 多个item配置
 @return UIBarButtonItem
 */
+ (nullable UIBarButtonItem *)barButtonItemWithItems:(nonnull NSArray<LSWCustomBarButtonViewItem *> *)items;


/**
 创建含单个ImageButton的UIBarButtonItem

 @param image image
 @param target target
 @param action action
 @return UIBarButtonItem
 */
+ (nullable UIBarButtonItem *)barButtonItemWithImage:(nonnull UIImage *)image target:(nullable id)target action:(nullable SEL)action;


/**
 创建含单个TextButton的UIBarButtonItem

 @param title title
 @param target target
 @param action action
 @param style style
 @return UIBarButtonItem
 */
+ (nullable UIBarButtonItem *)barButtonItemWithTitle:(nonnull NSString *)title target:(nullable id)target action:(nullable SEL)action style:(LSWNavigationBarStyle)style;

+ (nullable UIBarButtonItem *)barButtonItemWithImage:(nullable UIImage *)image imageUrl:(nullable NSURL *)url title:(NSString *)title target:(nullable id)target action:(nullable SEL)action;


- (nullable instancetype)initWithItems:(nonnull NSArray<LSWCustomBarButtonViewItem *> *)items;
- (void)updateButtonImageWithImage:(nonnull UIImage *)image atIndex:(NSInteger)index;
@end


NS_ASSUME_NONNULL_END
