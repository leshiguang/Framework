//
//  DeviceUnitCfg.h
//  LSBluetooth-Library
//
//  Created by Dylan on 16/1/21.
//  Copyright © 2016年 Lifesense. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DeviceUnitCfg : NSObject
@property(nonatomic,assign)int unit;

@end
