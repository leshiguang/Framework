//
//  UIImage+LSDStretching.h
//  LSDoctor
//
//  Created by malai on 16/6/24.
//  Copyright © 2016年 lifesense. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (LSDStretching)

/**
 *  拉伸最中间的一个点
 *
 *  @return 拉伸后的图片
 */
- (UIImage *)lsd_stretchingCenter;

/**
 *  在底部位置拉伸
 *
 *  @param bottom 
 *
 *  @return 拉伸后的图片
 */
- (UIImage *)lsd_stretchingBottom:(CGFloat)bottom;





@end
