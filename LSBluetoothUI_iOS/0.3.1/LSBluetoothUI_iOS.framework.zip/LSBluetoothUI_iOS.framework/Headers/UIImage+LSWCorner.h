//
//  UIImage+LSWCorner.h
//  LSWearable
//
//  Created by pengpeng on 2019/12/11.
//  Copyright © 2019 lifesense. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIImage (LSWCorner)

- (UIImage *)lsw_drawRectWithRoundedCorner:(CGFloat)radius
                                      size:(CGSize)size
                         byRoundingCorners:(UIRectCorner)corners;

@end

NS_ASSUME_NONNULL_END
