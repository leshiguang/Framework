////
////  LSWWeightValuePicker.h
////  LSWearable
////
////  Created by Wenzheng Zhang on 2016/10/18.
////  Copyright © 2016年 lifesense. All rights reserved.
////
//
//#import "LSWFullScreenHUDBackgroundView.h"
//
//@class LSWWeightValuePicker;
//
//@protocol LSWWeightValuePickerDelegate <NSObject>
//@optional
//- (void)weightValuePicker:(LSWWeightValuePicker *)weightValuePicker didSelectWeight:(double)weight;
//@end
//
//typedef void(^LSWWeightValuePickerDidSelectValueBlock)(double weight);
//
//@interface LSWWeightValuePicker : LSWFullScreenHUDBackgroundView
//
//@property (nonatomic, weak) id <LSWWeightValuePickerDelegate> delegate;
//
//@property (nonatomic, strong) LSWWeightValuePickerDidSelectValueBlock didSelectValueBlock;
//
//
///**
// 最小可选体重，保留小数点后一位
// */
//@property (nonatomic, readonly, assign) double minWeight;
//
///**
// 最大可选体重，保留小数点后一位
// */
//@property (nonatomic, readonly, assign) double maxWeight;
//
//
///**
// 设置最小，最大可选体重，最大体重必须大于等于最小体重
//
// @param minWeight 最小可选体重，保留小数点后一位
// @param maxWeight 最大可选体重，保留小数点后一位
// */
//- (void)setMinWeight:(double)minWeight maxWeight:(double)maxWeight;
//
//
///**
// 设置选择器title和选中值
//
// @param title  title
// @param weight 选中的体重，只保留小数点后一位
// */
//- (void)setUpWithTitle:(NSString *)title selectedWeight:(double)weight;
//@end
