//
//  LSDeviceManagerDBModels.h
//  LSDeviceManager
//
//  Created by Wenzheng Zhang on 2017/9/12.
//  Copyright © 2017年 Wenzheng Zhang. All rights reserved.
//

#ifndef LSDeviceManagerDBModels_h
#define LSDeviceManagerDBModels_h
#import "DeviceStatus+CoreDataProperties.h"
#import "DeviceSetting+CoreDataProperties.h"
#import "Device+CoreDataProperties.h"
#import "DeviceUser+CoreDataProperties.h"
#endif /* LSDeviceManagerDBModels_h */
