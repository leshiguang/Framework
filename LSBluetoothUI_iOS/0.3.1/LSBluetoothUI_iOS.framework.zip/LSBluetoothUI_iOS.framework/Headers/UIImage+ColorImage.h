//
//  UIImage+ColorImage.h
//  LSWearable
//
//  Created by wm on 2020/7/1.
//  Copyright © 2020 lifesense. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIImage (ColorImage)
+ (UIImage *)imageWithColor:(UIColor *)color size:(CGSize)size;
@end

NS_ASSUME_NONNULL_END
