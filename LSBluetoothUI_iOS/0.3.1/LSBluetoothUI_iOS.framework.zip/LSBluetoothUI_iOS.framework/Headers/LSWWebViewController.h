//
//  LSWWebViewController.h
//  LSWearable
//
//  Created by Wenzheng Zhang on 2017/8/10.
//  Copyright © 2017年 lifesense. All rights reserved.
//

#import "LSWBaseViewController.h"
#import "LSWGSTableViewBackgroundView.h"
#import "WDTitleView.h"
#import "LSWKWebViewJavascriptBridge.h"

@interface LSWWebViewController : LSWBaseViewController <WKNavigationDelegate, WKUIDelegate, UIScrollViewDelegate, LSWGSTableViewBackgroundViewDelegate>
@property (nonatomic, strong) NSURL *url;
@property (nonatomic, assign) BOOL shouldHideCustomBackAndCloseButton;
@property (nonatomic, assign) BOOL shouldHideCustomCloseButton;
@property (nonatomic, assign) BOOL shouldHiddenActivityView;
@property (nonatomic, assign) BOOL isBounces; //是否关闭webView scrollView bounces
@property (nonatomic, assign) CGFloat bottomPadding;
@property (nonatomic, assign) BOOL viewWillAppearUpdateNavigation; //默认为NO

- (void)set_topPadding:(CGFloat)topPadding;
- (void)set_navigationBarHidden:(BOOL)isHidden;
- (void)set_barLineHidden:(BOOL)isHidden;
- (void)set_color:(UIColor *)color;
- (void)set_tintColorType:(NSInteger)type;
- (void)set_title:(NSString *)title;

@property (nonatomic, strong, readonly) WDTitleView *titleView;
@property (nonatomic, strong, readonly) NSURL *currentUrl;

@property (nonatomic, strong, readonly) LSWGSTableViewBackgroundView *loadingBackgroundView;
@property (nonatomic, strong, readonly) WKWebView *webView;
@property (nonatomic, assign, readonly) BOOL hasLoadedInitialUrl;
@property (nonatomic, assign, readwrite) BOOL hasAddedConstraints;
@property (nonatomic, assign, readonly) BOOL isFirstTimeAppear;

@property (nonatomic, assign) BOOL shouldPopToRootView;
- (void)handleHttpAndHtppsNavigation:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler;
- (void)handleLSWSchemeNavigation:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler;
- (void)handleOtherCustomSchemeNavigation:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler;
@end
