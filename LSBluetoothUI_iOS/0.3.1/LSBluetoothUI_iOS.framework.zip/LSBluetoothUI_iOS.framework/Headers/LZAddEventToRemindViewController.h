//
//  LZAddEventToRemindViewController.h
//  LSBluetoothUI_iOS
//
//  Created by wm on 2020/12/8.
//

#import "LZBaseSettingViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface LZAddEventToRemindViewController : LZBaseSettingViewController

/// 如果没有就是新加
@property (nonatomic, strong, nullable) LZA5SettingEventRemindData *editData;


@end

NS_ASSUME_NONNULL_END
