//
//  LSApplyDeviceIdRequest.h
//  LSWearable
//
//  Created by wenzhengzhang on 2017/7/31.
//  Copyright © 2017年 lifesense. All rights reserved.
//

#import "LSDMBaseRequest.h"

@interface LSApplyDeviceIdRequest : LSDMBaseRequest

/**
 mac地址
 */
@property (nonatomic, copy) NSString *mac;

/**
 硬件版本
 */
@property (nonatomic, copy) NSString *hardwareVersion;

/**
 固件版本
 */
@property (nonatomic, copy) NSString *softwareVersion;

/**
 厂商Id
 */
@property (nonatomic, copy) NSString *venderId;

/**
 通信类型
 */
@property (nonatomic, copy) NSNumber *communicationType;

/**
 型号
 */
@property (nonatomic, copy) NSString *model;

/**
 产品类别
 */
@property (nonatomic, copy) NSString *productTypeCode;

/**
 名称
 */
@property (nonatomic, copy) NSString *name;

/**
 销售型号
 */
@property (nonatomic, copy) NSString *salesModel;




@end
