//
//  NSMutableDictionary+TCAddition.h
//  Utility
//
//  Created by rolandxu on 15/12/16.
//  Copyright (c) 2015年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSMutableDictionary(LSAddition)

//设置非空的值
- (void)setNonEmptyObject:(id)object forKey:(id)key;

//解析字符串,默认值为nil
- (NSString *)objectStringForKey:(id)key;
- (NSString *)objectStringForKey:(id)key defaultValue:(NSString*)fallback;

//解析int整数，默认值为0
- (int)objectIntForKey:(id)key;
- (int)objectIntForKey:(id)key defaultValue:(int)fallback;

//解析long整数，默认值为0
- (long)objectLongForKey:(id)key;
- (long)objectLongForKey:(id)key defaultValue:(long)fallback;

//解析nsnumber，默认值为0的NSNumber对象
- (NSNumber *)objectNumberForKey:(id)key;
- (NSNumber *)objectNumberForKey:(id)key defaultValue:(NSNumber*)fallback;

//解析nsdictionary，默认值为0个keyvalue的字典
- (NSDictionary *)objectDictionaryForKey:(id)key;
- (NSDictionary *)objectDictionaryForKey:(id)key defaultValue:(NSDictionary*)fallback;

//解析nsarray，默认值为0个item的数组
- (NSArray*)objectArrayForKey:(id)key;
- (NSArray *)objectArrayForKey:(id)key defaultValue:(NSArray*)fallback;

//设置int(自动转nsnumber)
- (void)setObjectInt:(int)intValue forKey:(id)key;

//设置Long(自动转nsnumber)
- (void)setObjectLong:(long)longValue forKey:(id)key;

//设置bool(自动转nsnumber)
- (void)setObjectBool:(BOOL)boolValue forKey:(id)key;
@end
