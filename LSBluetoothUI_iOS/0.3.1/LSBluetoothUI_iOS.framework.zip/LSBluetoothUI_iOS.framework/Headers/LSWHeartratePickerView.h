//
//  LSWHeartratePickerView.h
//  LSWearable
//
//  Created by Wenzheng Zhang on 2017/11/2.
//  Copyright © 2017年 lifesense. All rights reserved.
//

#import "LSWFullScreenHUDBackgroundView.h"

@class LSWHeartratePickerView;

typedef void(^LSWHeartratePickerViewDidSelectValueBlock)(NSInteger heartrate);

@protocol LSWHeartratePickerViewDataSource <NSObject>
@optional
- (NSAttributedString *)heartratePicker:(LSWHeartratePickerView *)heartratePicker heartrateTagLabelForHeartrate:(NSInteger)heartrate;
- (UIColor *)heartratePicker:(LSWHeartratePickerView *)heartratePicker heartrateTagBackgroundColorForHeartrate:(NSInteger)heartrate;
@end

@interface LSWHeartratePickerView : LSWFullScreenHUDBackgroundView
@property (nonatomic, weak) id <LSWHeartratePickerViewDataSource> dataSource;

@property (nonatomic, strong) LSWHeartratePickerViewDidSelectValueBlock didSelectValueBlock;


/**
 最小心率值
 */
@property (nonatomic, assign, readonly) NSInteger minHeartrate;

/**
 最大心率值
 */
@property (nonatomic, assign, readonly) NSInteger maxHeartrate;

/**
 设置最大，最小心率值
 
 @param minHeight 最小心率
 @param maxHeight 最大心率
 */
- (void)setMinHeartrate:(NSInteger)minHeartrate maxHeartrate:(NSInteger)maxHeartrate;

/**
 设置选择器title和选中值，目前有小bug，需要先show再设置选中值
 
 @param title  title
 @param heartrate 选中的心率
 */
- (void)setUpWithTitle:(NSString *)title selectedHeartrate:(NSInteger)heartrate;
@end
