//
//  NSObject+LZPerform.h
//  LZBluetooth
//
//  Created by tanjian on 2020/11/19.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSObject (LZPerform)

- (id)lz_performSelectorWithArgs:(SEL)sel, ...;

- (id)lz_performSelectorWithArgs:(SEL)sel args:(va_list)args;

@end

NS_ASSUME_NONNULL_END
