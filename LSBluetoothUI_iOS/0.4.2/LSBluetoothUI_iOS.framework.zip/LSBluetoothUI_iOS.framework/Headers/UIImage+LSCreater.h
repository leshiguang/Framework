//
//  UIImage+LSCreater.h
//  LSWearable
//
//  Created by malai on 2016/10/21.
//  Copyright © 2016年 lifesense. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (LSCreater)

+ (UIImage *)lsw_imageWithColor:(UIColor *)color rect:(CGRect)rect;

- (UIImage *)lsw_imageWithColor:(UIColor *)color;

@end
