//
//  UIViewController+LSWNavigationBarControlling.h
//  LSWearable
//
//  Created by Wenzheng Zhang on 2017/8/1.
//  Copyright © 2017年 lifesense. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LSWAppAppearanceConfigrationConstants.h"
#import "LSWCustomBarButtonView.h"

@interface UIViewController (LSWNavigationBarControlling)

/**
 设置初始导航栏颜色和导航栏样式，push进入动画时使用，若后续不在修改，则作为常驻颜色存在
 
 
 @param color 颜色
 @param style 样式
 */
- (void)lsw_setInitialNavigationBarColor:(nonnull UIColor *)color barStyle:(LSWNavigationBarStyle)style;


/**
 修改导航栏颜色
 
 @param color 颜色
 */
- (void)lsw_changeNavigationBarColor:(nonnull UIColor *)color;

/**
 修改导航栏title颜色 立即生效
 
 @param color 颜色
 */
- (void)lsw_changeNavigationTitleColor:(nonnull UIColor *)color;

/**
 修改导航栏底部线的颜色
 
 @param color 颜色
 */
- (void)lsw_changeNavigationLineAlpha:(CGFloat)alpha;

/**
 设置导航栏样式
 
 @param style 导航栏样式
 */
- (void)lsw_setNavigationBarStyle:(LSWNavigationBarStyle)style;


/**
 修改导航栏样式
 
 @param style 样式
 */
- (void)lsw_changeNavigationBarStyle:(LSWNavigationBarStyle)style;


/**
 设置是否展示导航栏下面的黑线，非立即生效
 
 @param hidden 是否展示
 */
- (void)lsw_setNavigationBarBottomLineHidden:(BOOL)hidden;

/**
 设置是否展示导航栏下面的黑线，立即生效
 
 @param hidden 是否展示
 */
- (void)lsw_setNavigationBarBottomLineHidden:(BOOL)hidden immediately:(BOOL)immediately;


/// 设置导航栏显示隐藏
/// @param hidden hidden
- (void)lsw_setNavigationHidden:(BOOL)hidden;


/**
 根据指定样式生成特定样式的barButtonItem
 
 @param style 样式
 @param title 标题
 @param target 目标
 @param action selector
 @return BarButtonItem
 */
- (nullable UIBarButtonItem *)lsw_textBarButtonItemWithBarStyle:(LSWNavigationBarStyle)style title:(nullable NSString *)title target:(nullable id)target action:(nullable SEL)action;


/**
 构造imageBarButtonItem

 @param image image
 @param target target
 @param action action
 @return UIBarButtonItem
 */
- (nullable UIBarButtonItem *)lsw_imageBarButtonItemWithImage:(nonnull UIImage *)image target:(nullable id)target action:(nullable SEL)action;


/**
 构造含多个button的BarButtonItem

 @param items items
 @return UIBarButtonItem
 */
- (nullable UIBarButtonItem *)lsw_multiButtonBarButtonItemWithItems:(nonnull NSArray<LSWCustomBarButtonViewItem *> *)items;
@end
