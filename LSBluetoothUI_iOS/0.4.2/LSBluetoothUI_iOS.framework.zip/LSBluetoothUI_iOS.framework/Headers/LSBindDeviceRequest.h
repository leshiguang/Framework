//
//  LSBindDeviceRequest.h
//  LSWearable
//
//  Created by wenzhengzhang on 2017/7/31.
//  Copyright © 2017年 lifesense. All rights reserved.
//

#import "LSDMBaseRequest.h"

@interface LSBindDeviceRequest : LSDMBaseRequest

/**
 qrcode
 */
@property (nonatomic, copy) NSString *qrcode;

/**
 userId
 */
@property (nonatomic, copy) NSString *userId;

/**
 userNo
 */
@property (nonatomic, copy) NSNumber *userNo;

@end
