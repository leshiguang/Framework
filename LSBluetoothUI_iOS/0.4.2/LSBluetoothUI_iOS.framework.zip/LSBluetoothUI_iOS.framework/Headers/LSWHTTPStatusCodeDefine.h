//
//  LSWHTTPStatusCodeDefine.h
//  LSWearable
//
//  Created by pengpeng on 2019/5/24.
//  Copyright © 2019 lifesense. All rights reserved.
//

#ifndef LSWHTTPStatusCodeDefine_h
#define LSWHTTPStatusCodeDefine_h

/*
 * http 状态码
 */

/** 成功  **/
#define  kLSWHTTP_SUCCESS             200
/** 图片验证码错误 **/
#define  kLSWHTTP_PICCODE_ERROR       412
/** 图片验证码已经失效 **/
#define  kLSWHTTP_PICCODE_INVALID     416


#endif /* LSWHTTPStatusCodeDefine_h */
