//
//  LSWMyDeviceListViewController.h
//  LSWearable
//
//  Created by ShunQing Cao on 2019/9/20.
//  Copyright © 2019 lifesense. All rights reserved.
//

#import "LSWBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface LSWMyDeviceListViewController : LSWBaseViewController

@end

NS_ASSUME_NONNULL_END
