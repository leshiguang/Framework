//
//  LSDeviceUser.h
//  LSDeviceManager
//
//  Created by tanjian on 2020/12/23.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LSDeviceUser : NSObject

@end

NS_ASSUME_NONNULL_END
