//
//  LSDevice.h
//  LSDeviceManager
//
//  Created by tanjian on 2020/12/23.
//

#import <Foundation/Foundation.h>
#import "LSDeviceManagerDefine.h"
#import "LSDeviceConstants.h"

NS_ASSUME_NONNULL_BEGIN

@interface LSDevice : NSObject

/// 显示名称
@property (nonatomic, readonly, nullable) NSString *name;
/// 设备id
@property (nonatomic, readonly, nullable) NSString *id;
/// 设备图片
@property (nonatomic, readonly, nullable) NSString *imgUrl;
/// 设备mac
@property (nonatomic, readonly, nullable) NSString *mac;
/// sn码
@property (nonatomic, readonly) NSString *sn;
/// 电量 0~100 
@property (nonatomic, readonly, nullable) NSNumber *batteryPercentage;
/// 是否正在充电
@property (nonatomic, readonly) BOOL isChanging;
/// 连接状态
@property (nonatomic, readonly) LSDeviceConnectStatus connectStatus;
/// 连接方式
@property (nonatomic, readonly) LSCommunicationType communicationType;
/// 产品类型
@property (nonatomic, readonly) LSDeviceType deviceType;

@property (nullable, nonatomic, readonly) NSString *softwareVersion;
@property (nullable, nonatomic, readonly) NSString *hardwareVersion;
@property (nullable, nonatomic, readonly) NSString *model;
@property (nullable, nonatomic, readonly) NSString *salesModel;
@property (nullable, nonatomic, readonly) NSString *venderId;

- (NSArray<LSEDialProertyValue *> *)getDialProperties;

/// 是否激活；1-激活；0未激活
@property (nonatomic, readonly) BOOL isActive;
/// 最近同步数据时间
@property (nonatomic, copy, nullable, readonly) NSNumber *lastDataTime;

@property (nonatomic, readonly, nullable) NSNumber *rssi;

@property (nonatomic, strong, nullable) NSNumber *created;

@property (nonatomic, strong, nullable) NSArray<LSEDialProertyValue *> * getDialProperties;

@property (nonatomic, assign) int codeLength;

- (instancetype)init UNAVAILABLE_ATTRIBUTE;


@end

NS_ASSUME_NONNULL_END
