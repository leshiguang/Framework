//
//  UIImage+LSWQRCode.h
//  LSWearable
//
//  Created by malai on 2018/7/17.
//  Copyright © 2018年 lifesense. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (LSWQRCode)

+ (UIImage *)ls_imageWithQr:(NSString *)qr size:(CGFloat)size;

@end
