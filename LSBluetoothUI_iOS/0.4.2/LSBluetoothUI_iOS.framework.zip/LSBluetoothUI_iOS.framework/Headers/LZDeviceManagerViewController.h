//
//  LZDeviceManagerViewController.h
//  LZBluetooth Example
//
//  Created by tanjian on 2021/1/14.
//

#import <UIKit/UIKit.h>
#import "LSWBaseViewController.h"
#import "LSDeviceManager.h"
#import "LSDeviceManager+Bind.h"
#import "UIViewController+MBProgressHUD.h"

NS_ASSUME_NONNULL_BEGIN

@interface LZDeviceManagerViewController : LSWBaseViewController

@property (nonatomic, strong, readonly) LSDeviceManager *deviceManager;

@property (nonatomic, strong, nullable) LSDevice *device;

/// 设置类型
@property (nonatomic, assign) LZDeviceSettingType settingType;

@property (nonatomic, strong) NSArray <NSString *> *hours;
@property (nonatomic, strong) NSArray <NSString *> *minutes;

/// 可以重写方法刷新UI
- (void)updateUIWithResult:(LZBluetoothErrorCode)result;

- (void)sendData:(id<LZDeviceSettingProtocol>)settingData;

/// 获取缓存的设置项
- (id)settingData;

/// 默认的设置
- (id)defaultData;

@end

NS_ASSUME_NONNULL_END
