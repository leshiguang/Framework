//
//  ShareMacro.h
//  LSWearable
//
//  Created by May on 16/2/23.
//  Copyright © 2016年 lifesense. All rights reserved.
//

#ifndef ShareMacro_h
#define ShareMacro_h

#define Share_ShareType @"shareType"
#define Share_Avatar @"avatar"
#define Share_Nickname @"nickname"
#define Share_ShareDate @"shareDate"
#define Share_Day @"day"
#define Share_DeviceName @"deviceName"
#define Share_DeviceRecordList @"deviceRecordList"
#define Share_DeviceName @"deviceName"
#define Share_DeviceModel @"deviceModel"

#define Share_PedometerRecord @"pedometerRecord"
#define Share_Step @"step"
#define Share_Distance @"distance"
#define Share_Calories @"calories"

#define Share_WeightRecord @"weightRecord"
#define Share_Weight @"weight"
#define Share_ChangeRecord @"changeRecord"

#define Share_SleepRecord @"sleepRecord"
#define Share_SleepTime @"sleepTime"
#define Share_UpTime @"upTime"
#define Share_SleepMinute @"sleepMinute"

#define Share_HeartRateRecord @"heartRateRecord"
#define Share_FastestHR @"fastestHR"
#define Share_ReducedFat @"reducedFat"
#define Share_Endurance @"endurance"
#define Share_SuperData @"superData"

#define Share_SportRecord @"sportRecord"
#define Share_ExerciseTime @"exerciseTime"
#define Share_AvgHeartRate @"avgHeartRate"

#define Share_Url @"url"

#endif /* ShareMacro_h */
