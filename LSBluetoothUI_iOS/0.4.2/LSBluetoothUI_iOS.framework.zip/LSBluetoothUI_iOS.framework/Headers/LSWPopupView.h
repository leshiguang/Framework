//
//  LSWPopupView.h
//  LSWearable
//
//  Created by malai on 2017/5/12.
//  Copyright © 2017年 lifesense. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol LSWPopupViewDelegate;

@interface LSWPopupView : UIView

@property (nonatomic, readonly) UIView *contentView;

@property (nonatomic, readonly) UIView *backgroundView;



- (void)showInView:(UIView *)view animation:(BOOL)animation;


- (void)hiddenWithAnimation:(BOOL)animation;

- (void)showInKeyWindow;

- (void)showInKeyWindowWithAnimation:(BOOL)animation;

@end


@protocol LSWPopupViewDelegate <NSObject>

@end
