//
//  LSDeviceManager+Bind.h
//  LSDeviceManagerTests
//
//  Created by alex.wu on 2019/9/9.
//  Copyright © 2019 Wenzheng Zhang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LSDeviceManager.h"
#import "LSEProductInfo.h"
#import "LSEApplyDeviceIdInfo.h"

NS_ASSUME_NONNULL_BEGIN

@class DeviceUser;

@interface LSDeviceManager(Bind) <LZDeviceBindDelegate>

- (void)applyDeviceIdWithInfo:(LSEApplyDeviceIdInfo *)deviceInfo completion:(void(^)(int code, NSString *msg, NSString *deviceId, NSString *mac))completion;

/**
 * 仅绑定设备时使用，其它时候不要用
 */
- (void)findTargetDevice:(NSString *)broadcastId type:(NSString *)type completion:(void(^)(BOOL isSuccess))findCompletion;

/**
 *  根据二维码绑定设备（蓝牙或wifi）
 */
-(void)bindingDeviceuserId:(NSString *)userId qrCode:(NSString *)qrCode userNo:(NSNumber *)userNo Completion:(void(^)(int code,NSString *msg,Device *device,NSArray<DeviceUser *>*user))completion;

// 通过DeviceID来绑定设备
- (void)bindDeviceWithDeviceId:(NSString *)deviceId userId:(NSString *)userId completion:(void(^)(int code,NSString *msg,Device *device,NSArray<DeviceUser *>*user))completion;

/// 新增
/// @param deviceId 设备id
/// @param completion 完成回调
- (void)unbindDeviceWithId:(NSString *)deviceId completion:(void(^)(int code,NSString *msg))completion;

/// 绑定手环
/// @param deviceInfo 配对手环
- (void)pairDevice:(LSDevice *)deviceInfo;

/// 用户绑定手环校验码
/// @param code 校验码
/// @param deviceInfo 设备信息
- (void)inputCode:(NSString *)code deviceInfo:(LSDevice *)deviceInfo;

/// 取消绑定
/// @param deviceInfo 设备信息
- (void)cancelPair:(LSDevice *)deviceInfo;


- (Device *)getPairDevice:(id)device;

- (void)resetActiveDevice;

-(void)cancelFindTargetDevice;

@end

NS_ASSUME_NONNULL_END
