//
//  LSUploadBpDataRequest.h
//  LSBluetoothUI_iOS
//
//  Created by tanjian on 2021/3/9.
//

#import "LSBaseRequest.h"
#import "LSBloodPressureData.h"

NS_ASSUME_NONNULL_BEGIN

@interface LSUploadBpDataRequest : LSBaseRequest

@property (nonatomic, strong) LSBloodPressureData *bpData;

@end

NS_ASSUME_NONNULL_END
