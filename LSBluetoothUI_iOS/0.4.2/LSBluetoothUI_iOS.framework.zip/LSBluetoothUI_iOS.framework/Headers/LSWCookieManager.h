//
//  LSWCookieManager.h
//  LSWearable
//
//  Created by boluobill on 2/24/17.
//  Copyright © 2017 lifesense. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LSWCookieManager : NSObject

+ (void)setBaseCookieWithURL:(NSURL *)url;
+ (void)deleteCookieWithURL:(NSURL *)url;

// 清除所有的cookie
//+ (void)clearAllCookie;

+ (NSString *)readCurrentCookie;
@end
