//
//  LZEventToRemindTableViewCell.h
//  LSBluetoothUI_iOS
//
//  Created by wm on 2020/12/8.
//

#import <UIKit/UIKit.h>
#import "LZBaseSetTableViewCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface LZEventToRemindTableViewCell : LZBaseSetTableViewCell

@end

NS_ASSUME_NONNULL_END
