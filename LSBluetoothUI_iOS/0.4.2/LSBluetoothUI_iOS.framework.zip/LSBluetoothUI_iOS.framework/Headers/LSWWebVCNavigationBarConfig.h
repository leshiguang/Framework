//
//  LSWWebVCNavigationBarConfig.h
//  LSWearable
//
//  Created by wm on 2020/7/1.
//  Copyright © 2020 lifesense. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import "LSWWebVCScrollingTransition.h"

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, LSWWebVCNavigationBarTintColorType) {
    LSWWebVCNavigationBarTintColorTypeWhite = 1,
    LSWWebVCNavigationBarTintColorTypeDark  = 2,
};

typedef NS_ENUM(NSUInteger, LSWWebVCNavigationBarBackButtonType) {
    LSWWebVCNavigationBarBackButtonTypeArrowBack = 1,
    LSWWebVCNavigationBarBackButtonTypeXClose = 2,
};

@interface LSWWebVCNavigationBarConfig : NSObject
@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) NSString *subTitle;
@property (nonatomic, strong) UIColor *color;
@property (nonatomic, assign) LSWWebVCNavigationBarTintColorType tintColorType;
@property (nonatomic, assign) CGFloat topPadding;
@property (nonatomic, assign) BOOL barLineHidden;
@property (nonatomic, assign) BOOL autoResetToDefaultConfigWhtenOpenLink;
@property (nonatomic, assign) LSWWebVCNavigationBarBackButtonType backButtonType;
@property (nonatomic, strong) NSArray<UIBarButtonItem *> *rightBarButtons;
@property (nonatomic, strong) UIBarButtonItem *jsControlledBarButtonItem;
@property (nonatomic, assign) BOOL autoTopPadding;
@property (nonatomic, assign) BOOL isNavigationBarHidden;
- (instancetype)initWithDict:(NSDictionary *)dict fillDefaultValueWith:(LSWWebVCNavigationBarConfig *)defalutConfig;
@end

NS_ASSUME_NONNULL_END
