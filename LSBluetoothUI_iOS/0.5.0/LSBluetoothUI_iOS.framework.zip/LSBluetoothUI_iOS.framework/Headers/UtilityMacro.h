//
//  UtilityMacro.h
//  LSWearable
//
//  Created by bill on 16/1/14.
//  Copyright © 2016年 lifesense. All rights reserved.
//

#ifndef UtilityMacro_h
#define UtilityMacro_h
#define Normal_Date_Format @"yyyy-MM-dd HH:mm:ss"
#endif /* UtilityMacro_h */
