//
//  LSWTimeUtil.h
//  LSWearable
//
//  Created by malai on 2018/9/3.
//  Copyright © 2018年 lifesense. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_OPTIONS(NSUInteger, LSWAddAlarmSelectWeekDay) {
    LSWAddAlarmSelectWeekDayNone = 0,
    LSWAddAlarmSelectWeekMon = 1 << 0,
    LSWAddAlarmSelectWeekTue = 1 << 1,
    LSWAddAlarmSelectWeekWed = 1 << 2,
    LSWAddAlarmSelectWeekThu = 1 << 3,
    LSWAddAlarmSelectWeekFri = 1 << 4,
    LSWAddAlarmSelectWeekSat = 1 << 5,
    LSWAddAlarmSelectWeekSun = 1 << 6,
    LSWAddAlarmSelectWeekDayAll = 0b1111111,
    
};

@interface LSWTimeUtil : NSObject


/**
 xx分钟xx秒

 */
+ (NSString *)timeWithStartDate:(NSDate *)startDate endDate:(NSDate *)endDate;


//xx小时xx分
//xx分
+ (NSString *)timeWithMin:(int)min;

+ (LSWAddAlarmSelectWeekDay)weekdayFromStr:(NSString *)str;

+ (NSString *)strWithWeekDay:(LSWAddAlarmSelectWeekDay)weekDay;

+ (NSArray <NSString *> *)weekStrs;

@end
