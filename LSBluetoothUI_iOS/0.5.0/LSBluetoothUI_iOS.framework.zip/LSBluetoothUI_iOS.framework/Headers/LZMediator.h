//
//  LZMediator.h
//  LSBluetoothUI_iOS
//
//  Created by tanjian on 2021/5/11.
//  超轻量组件通信工具

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/// 如果你的协议与你的模块名称相同，则可以使用此宏，
#define LZMediatorService(service_protocol) ((id<service_protocol>)[LZMediator instanceWithModuleName:NSStringFromProtocol(@protocol(service_protocol))])

/// 这里有个硬性规定
@interface LZMediator : NSObject

- (instancetype)init NS_UNAVAILABLE;

/// 判断是否存在模块
/// @param moduleName 模块名称
+ (BOOL)checkModuleExistWithModuleName:(NSString *)moduleName;

/// 初始化模块，如果已经有缓存了，则优先使用缓存。
/// @param moduleName 模块名称
+ (id _Nullable )instanceWithModuleName:(NSString *)moduleName;

/// 执行某个模块的某个方法（如果某个模块没有初始化，则会调用初始化方法，并缓存下来）
/// @param moduleName 模块名称
/// @param selector 方法名称 （该方法是只有一个参数的方法 如 print:）
/// @param params 参数（推荐使用字典）
+ (id _Nullable )performModuleName:(NSString *)moduleName
                          selector:(NSString *)selector
                            params:(id _Nullable)params;

/// 释放某个模块
/// @param moduleName 模块名称
+ (void)releaseWithModuleName:(NSString *)moduleName;

@end

NS_ASSUME_NONNULL_END
