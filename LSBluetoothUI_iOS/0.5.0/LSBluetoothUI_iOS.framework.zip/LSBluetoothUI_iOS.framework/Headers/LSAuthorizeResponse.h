//
//  LSAuthorizeResponse.h
//  LSAuthorization
//
//  Created by alex.wu on 2020/3/3.
//
//#import <LSNetworkFramework/LSNetworkingModule.h>
#import "LSJSonResponse.h"

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LSAuthorizeResponse : LSJSonResponse



@end

NS_ASSUME_NONNULL_END
