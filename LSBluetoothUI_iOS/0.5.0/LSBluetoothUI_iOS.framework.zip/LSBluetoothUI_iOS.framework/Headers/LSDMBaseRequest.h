//
//  LSDMBaseRequest.h
//  LSDeviceManager
//
//  Created by Wenzheng Zhang on 2017/9/19.
//  Copyright © 2017年 Wenzheng Zhang. All rights reserved.
//

//#import <LSNetworkingModule/LSNetworkingModule.h>
#import "LSBaseRequest.h"


@interface LSDMBaseRequest : LSBaseRequest

@end
