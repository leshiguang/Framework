//
//  ZWZLoadMoreControlFailedViewDelegate.h
//  ZWZLoadMoreControlDemo
//
//  Created by wenZheng Zhang on 16/1/5.
//  Copyright © 2016年 ZWZ. All rights reserved.
//

#import <Foundation/Foundation.h>
@protocol ZWZLoadMoreControlFailedViewProtocol;

@protocol ZWZLoadMoreControlFailedViewDelegate <NSObject>
@optional
- (void)loadMoreControlFailedViewDidTriggerLoading:(UIView <ZWZLoadMoreControlFailedViewProtocol> *)loadMoreControlFailedView;
@end
