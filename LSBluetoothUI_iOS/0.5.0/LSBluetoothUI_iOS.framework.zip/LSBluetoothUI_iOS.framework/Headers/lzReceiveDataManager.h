//
//  lzReceiveDataManager.h
//  LSDeviceManagerTests
//
//  Created by wm on 2020/11/9.
//  Copyright © 2020 Wenzheng Zhang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LSReceiveData.h"
#import "LSDeviceManagerDefine.h"

NS_ASSUME_NONNULL_BEGIN

@interface lzReceiveDataManager : NSObject

+ (instancetype)shareInstance;


/// check 未同步的手环数据
/// @param userId userId
/// @param dataType 数据枚举
/// @param block 未同步数据回调
- (void)checkUnsynchronizedDataForUserId:(NSString *)userId dataType:(LSMeasurementDataType)dataType block:(void(^)(NSArray *ary))block;


/// 存储测量数据
/// @param dataAry 接收到的数据
/// @param dataType 数据类型
- (void)saveWithDataAry:(NSArray <LSReceiveData *> *)dataAry dataType:(LSMeasurementDataType)dataType;

/// 上传所有的缓存数据
/// @param userId 用户id
- (void)tryUploadAllDataForUserId:(NSString *)userId;

@end

NS_ASSUME_NONNULL_END
