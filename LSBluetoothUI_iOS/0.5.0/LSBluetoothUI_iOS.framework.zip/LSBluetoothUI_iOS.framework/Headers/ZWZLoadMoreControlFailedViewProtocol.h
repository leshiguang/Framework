//
//  ZWZLoadMoreControlFailedViewProtocol.h
//  ZWZLoadMoreControlDemo
//
//  Created by wenZheng Zhang on 16/1/5.
//  Copyright © 2016年 ZWZ. All rights reserved.
//

#import <Foundation/Foundation.h>
@protocol ZWZLoadMoreControlFailedViewDelegate;

@protocol ZWZLoadMoreControlFailedViewProtocol <NSObject>
@required
@property (nonatomic, weak) id <ZWZLoadMoreControlFailedViewDelegate>delegate;
@end
