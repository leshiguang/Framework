//
//  LSWConstants.h
//  LSWearable
//
//  Created by wenZheng Zhang on 16/1/27.
//  Copyright © 2016年 lifesense. All rights reserved.
//

#import <Foundation/Foundation.h>

/*!
 *  返回按钮图片名
 */
//extern NSString *const kSLWNavigationBarBackImageName;

/*!
 *  保存到PList的上次打APP开时间
 */
extern NSString *const kLSWLastOpenDateKey;

/*!
 *  设备组件操作成功码
 */
extern const NSInteger kLSWDeviceManagerSuccessCode;

/*!
 *  错误信息显示时长
 */
extern const NSTimeInterval kLSWHUDMessageShowDuration;


/*!
 *  是否已经展示V2.0欢迎页
 */
extern NSString *const kLSWHasShowV2IntroductionViewKey;

/*!
 *  群logo占位图
 */
extern NSString *const kLSWGSGroupLogoPlaceHolderImageName;

/*!
 *  用户占位图
 */
extern NSString *const kLSWGSUserAvatarImagePlaceHolderImageName;

/*!
 *  app scheme名称
 */
extern NSString *const kLSWSchemeName;

/**
 *  图片最大的大小，单位为byte
 */
extern const NSInteger kLSWMaxImageSizeInBytes;

extern const NSInteger kLSWMaxStepTarget;
extern const NSInteger kLSWMinStepTarget;

/**
 *  日志类型
 */
typedef NS_ENUM(NSUInteger, LSWLogType) {
    
    /**
     *  所有日志
     */
    LSWLogTypeAllLog,

    
    /**
     *  蓝牙日志
     */
    LSWLogTypeBluetooth,
    
    /**
     *  睡眠模块日志
     */
    LSWLogTypeSleepModule,
    
    /**
     *  设备组件网络日志
     */
    LSWLogTypeDeviceNetworkModule,
    
    /**
     *  性能问题日志
     */
    LSWLogTypePerformanceIssue,
};


/**
 *  上传蓝牙日志的notification名称
 */
extern NSString *kLSWUplaodLogNotificationName;

/**
 *  成员被踢出个人群的ViewType
 */
extern NSString *const kLSWBeKickedOutGroupViewType;

/**
 *  成员被踢出企业群的ViewType
 */
extern NSString *const kLSWBeKickedOutEnterpriseGroupViewType;


/**
 *  上传日志的ViewType
 */
extern NSString *const kLSWUploadLogViewType;

typedef NS_ENUM(NSUInteger, LSWChallengeType) {
    LSWChallengeTypeAlways  = 1,
    LSWChallengeTypeDynamic = 2,
};

typedef NS_ENUM(NSUInteger, LSWTargetType) {
    LSWTargetTypeAccumulate = 1,
    LSWTargetTypeRepeat = 2,
};

typedef NS_ENUM(NSUInteger, LSWChallengeResult) {
    LSWChallengeResultSucceed = 1,
    LSWChallengeResultFailed = 2,
};

typedef NS_ENUM(NSUInteger, LSWChallengeUnitType) {
    LSWChallengeUnitTypeStep = 1,
    LSWChallengeUnitTypeDistance = 2,
    LSWChallengeUnitTypeCalorie = 3,
    LSWChallengeUnitTypeSleep = 4,
    LSWChallengeUnitTypeSleepStartTimeRange = 5,
    LSWChallengeUnitTypeSportTime = 6,
};


/**
 indicatorType

 - LSWChallengeIndicatorTypeDaliyData: 日常数据
 - LSWChallengeIndicatorTypeSleep: 睡眠
 - LSWChallengeIndicatorTypeSportWalk: 锻炼-健走
 - LSWChallengeIndicatorTypeSportRun: 锻炼-跑步
 - LSWChallengeIndicatorTypeSportCycling: 锻炼-骑行
 - LSWChallengeIndicatorTypeEquivalent: 只有常规挑战有
 */
typedef NS_ENUM(NSUInteger, LSWChallengeIndicatorType) {
    LSWChallengeIndicatorTypeDaliyData = 1,
    LSWChallengeIndicatorTypeSleep = 2,
    LSWChallengeIndicatorTypeSportWalk = 3,
    LSWChallengeIndicatorTypeSportRun = 4,
    LSWChallengeIndicatorTypeSportCycling = 5,
    LSWChallengeIndicatorTypeEquivalent = 7,
};

typedef NS_ENUM(NSUInteger, LSWChallengeDataType) {
    LSWChallengeDataTypeJoined = 1,
    LSWChallengeDataTypeActivity = 2,
};

/**
 *  挑战成功消息的NotificationName
 */
extern NSString *const kLSWChallengeSucceedMessageNotificationName;

/**
 *  体重新数据同步
 */
extern NSString *const kWeightSyncViewType;

/**
 *  未知数据匹配
 */
extern NSString *const kWeightMatchingViewType;

/**
 *  体重数据消息
 */
extern NSString *const kWeightDataViewType;

/**
 *  设备组件的数据消息
 */
extern NSString *const kDeviceNewDataViewType;

/**
 *  设备解绑
 */
extern NSString *const kDeviceUnbindViewType;

/**
 *  群成员被踢出个人群
 */
extern NSString *const kBeKickedOutGroupViewType;

/**
 *  AccessToken失效
 */
extern NSString *const kTickOfflineViewType;

/**
 *  上传日志
 */
extern NSString *const kLoggingViewType;

/**
 *  活动消息
 */
extern NSString *const kActivityMessageViewType;

/**
 *  个人群组消息
 */
extern NSString *const kPersonGroupMsgType;

/**
 *  挑战成功消息
 */
extern NSString *const kChallengeSuccessMsgType;

/**
 *  通知客户端,有新的未读消息需要马上调用接口拉取
 */
extern NSString *const kSyncMsgNotifyType;
@interface LSWConstants : NSObject
@end
