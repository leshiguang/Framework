//
//  LSSyncDataToServerRequest.h
//  LSWearable
//
//  Created by wenzhengzhang on 2017/7/31.
//  Copyright © 2017年 lifesense. All rights reserved.
//

#import "LSDMBaseRequest.h"

@interface LSSyncDataToServerRequest : LSDMBaseRequest

/**
 未同步的设备信息
 */
@property (nonatomic, copy) NSArray *devices;

/**
 未同步的设备状态
 */
@property (nonatomic, copy) NSArray *deviceStatus;

/**
 未同步的设备设置
 */
@property (nonatomic, copy) NSArray *deviceSettings;

@end
