//
//  LSSettingModeProtocol.h
//  LSDeviceManager
//
//  Created by tanjian on 2021/1/7.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, LSSettingType) {
    /// 类型未知
    LSSettingTypeUnknow,
    /// 设置游泳池长度
    LSSettingTypeSwimmingLenght,
    /// 运动项设置
    LSSettingTypeSportPages,
    /// 设置步数目标
    LSSettingTypeStepTarget,
    /// 运动心率区间
    LSSettingTypeSportHrSection,
    /// 步数、卡路里、距离目标设置
    LSSettingTypeEncourage,
    /// 心率预警
    LSSettingTypeHeartRateRemind,
    /// 夜间模式设置
    LSSettingTypeNightMode,
    /// 消息提醒
    LSSettingTypeMsgReminder,
    /// 勿扰模式
    LSSettingTypeNoDisturbMode,
    /// 时间制式
    LSSettingTypeTimeType,
    /// 佩戴习惯
    LSSettingTypeWristState,
    /// 设置屏幕方向
    LSSettingTypeScreenDirection,
    /// 自定义屏幕
    LSSettingTypeScreenContent,
    /// 自动识别多运动类型
    LSSettingTypeAutomaticSports,
    /// 设置手环表盘
    LSSettingTypeDial,
    /// 设置天气
    LSSettingTypeWeatherData,
    /// 设置运动信息
    LSSettingTypeSportInfo,
    /// 闹钟
    LSSettingTypeEventReminder,
    /// 久坐提醒
    LSSettingTypeSedentary
};

@protocol LSSettingModeProtocol <NSObject>

- (LSSettingType)settingType;

@end

NS_ASSUME_NONNULL_END
