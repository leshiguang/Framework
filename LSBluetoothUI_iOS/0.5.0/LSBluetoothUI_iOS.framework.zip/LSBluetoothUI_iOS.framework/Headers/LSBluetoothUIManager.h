//
//  LSBluetoothUIManager.h
//  KMNavigationBarTransition
//
//  Created by wm on 2020/9/4.
//

typedef enum : NSUInteger {
    LSBluetoothResultTypeSusses, //成功
    LSBluetoothResultTypeFaile   //失败
} LSBluetoothResultType;

#import <Foundation/Foundation.h>


NS_ASSUME_NONNULL_BEGIN

@interface LSBluetoothUIManager : NSObject
+ (instancetype)shareInstance;

@property (nonatomic, assign) LSBluetoothResultType resultType;
#pragma mark - 初始化Api
/// 初始化
/// @param accuountInfo 账号信息
- (void)initBluetoothUISDK:(LSBluetoothUIAccountInfo *)accuountInfo;

/// 更新用户信息
/// @param userInfo 用户信息
- (void)updateUserInfo:(LSBluetoothUIUserInfo *)userInfo completion:(void(^)(LSBluetoothResultType resultType))completion;

#pragma mark - 调用乐智界面Api

- (UIViewController *)pageWithUrl:(NSString *)url;

/// 我的设备页面
- (UIViewController *)deviceListPage;


#pragma mark - 版本

@end

NS_ASSUME_NONNULL_END
