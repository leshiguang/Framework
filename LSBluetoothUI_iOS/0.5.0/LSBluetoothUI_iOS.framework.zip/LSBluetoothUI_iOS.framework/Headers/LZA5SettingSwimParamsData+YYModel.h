//
//  LZA5SettingSwimParamsData+YYModel.h
//  LSDeviceManager
//
//  Created by tanjian on 2021/2/4.
//

#import <LZBluetooth/LZBluetooth.h>

NS_ASSUME_NONNULL_BEGIN

@interface LZA5SettingSwimParamsData (YYModel)

@end

NS_ASSUME_NONNULL_END
