//
//  LSBloodPressureData.h
//  LSBluetoothUI_iOS
//
//  Created by tanjian on 2021/3/9.
//

#import <Foundation/Foundation.h>
#import "LSReceiveData.h"

NS_ASSUME_NONNULL_BEGIN

@interface LSBloodPressureData : LSReceiveData
/// 测量时间戳，毫秒
@property (nonatomic, assign) long long measurementDate;
@property (nonatomic, assign) NSInteger systolicPressure;
@property (nonatomic, assign) NSInteger diastolicPressure;
@property (nonatomic, assign) NSInteger heartRate;
@property (nonatomic, assign) int userNo;
@property (nonatomic, assign) int movementError;

@property (nonatomic, strong, nullable) NSString *remark;
@property (nonatomic, strong, nullable) NSNumber *temperature;


@end

NS_ASSUME_NONNULL_END
