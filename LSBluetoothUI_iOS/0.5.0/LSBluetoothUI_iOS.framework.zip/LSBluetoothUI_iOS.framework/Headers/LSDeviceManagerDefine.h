//
//  LSDeviceManagerDefine.h
//  LSDeviceManager
//
//  Created by tanjian on 2020/12/23.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, LSDeviceSetResult) {
    LSDeviceSetResultSuccess,
    LSDeviceSetResultFailed,
};

typedef NS_ENUM(NSUInteger, LSUnit) {
    /// 千克
    LSUnitKg = 1,
    /// 斤
    LSUnitJin = 2,
    /// 磅
    LSUnitPounds = 3,
    /// 米
    LSUnitM = 4,
    /// 千米
    LSUnitKm = 5,
    /// 英石
    LSUnitSt = 6,
    /// 中文公斤
    LSUnitGongjin = 7,
    
};

typedef NS_ENUM(NSUInteger, LSEWifiConfigType) {
    /// 老产品，默认使用airkiss
    LSEWifiConfigTypeOld,
    /// airkiss
    LSEWifiConfigTypeAirkiss,
    /// smartlink
    LSEWifiConfigTypeSmartLink,
    /// 未知状态
    LSEWifiConfigTypeUnknown
};

/// AirKiss错误代码
typedef NS_ENUM(NSInteger, AirKissCode) {
    /// 配对成功
    AirKissSuccess = 0,
    /// 配对超时
    AirKissTimeOut,
    /// WIFI不能使用
    AirKissWifiNotUse,
    /// 出错
    AirKissError,
};

typedef NS_ENUM(NSUInteger, LSBindStatus) {
    /// 输入校验码
    LSBindStatusInputCode,
    /// 输入验证码错误
    LSBindStatusInputCodeError,
    /// 绑定成功
    LSBindStatusSuccessful,
    /// 绑定失败
    LSBindStatusFail,
};

/// 连接状态
typedef NS_ENUM(NSUInteger, LSDeviceConnectStatus) {
    /// 未连接
    LSDeviceConnectStatusDisconnected,
    /// 已连接
    LSDeviceConnectStatusConnecting,
    /// 正在连接中
    LSDeviceConnectStatusConnected,
    /// 正在断开连接中
    LSDeviceConnectStatusDisconnecting,
};

/// 连接方式
typedef NS_ENUM(NSUInteger, LSCommunicationType) {
    /// 网络
    LSCommunicationTypeNetwork = 1,
    /// wifi
    LSCommunicationTypeWifi = 2,
    /// GPRS
    LSCommunicationTypeGPRS = 3,
    /// 蓝牙模块
    LSCommunicationTypeBluetooth = 4,
    /// gprs 与 wifi
    LSCommunicationTypeGPRSWifi = 5,
};

/// 设备类型：01 体重秤、02 脂肪秤、03 身高、04 计步器、05  腰围尺、06 血糖仪、07 体温计、08 血压计

/// 产品类型
typedef NS_ENUM(NSUInteger, LSDeviceType) {
    LSDeviceTypeUnknow = 0,
    /// 体重称
    LSDeviceTypeWeightScale = 1,
    /// 脂肪称
    LSDeviceTypeFatScale = 2,
    /// 身高
    LSDeviceTypeHeightMiriam = 3,
    /// 计步器（也就是手环）
    LSDeviceTypePedometer = 4,
    /// 腰围尺
    LSDeviceTypeWaistlineMiriam = 5,
    /// 血糖仪
    LSDeviceTypeGlucoseMeter = 6,
    /// 体温计
    LSDeviceTypeThermometer = 7,
    /// 血压计
    LSDeviceTypeBloodPressure = 8,
    /// 厨房秤
    LSDeviceTypeKitchenScale = 9,
    /// 手环
    LSDeviceTypeBand = 10,
    /// 支付卡
    LSDeviceTypePaycard = 11,
    /// 第三方设备-智能枕头
    LSDeviceTypeThirdDeviceSleepace = 14,
};

typedef NS_ENUM(NSUInteger, LSMeasurementDataType) {
    /// 每天测量数据，也就是步数 参考
    LSMeasurementDataTypeDay = 1,
    /// 睡眠压缩数据 参考
    LSMeasurementDataTypeSleep,
    /// 心率数据 参考
    LSMeasurementDataTypeHeartRate,
    /// 运动模式状态 参考
    LSMeasurementDataTypeSportStatus,
    /// 运动报告 参考
    LSMeasurementDataTypeSportReport,
    /// 运动配速 参考
    LSMeasurementDataTypeSportPace,
    /// 运动心率 参考
    LSMeasurementDataTypeSportHeartRate,
    /// 运动卡路里 参考
    LSMeasurementDataTypeSportCalories,
    /// 体重数据 对应
    LSMeasurementDataTypeWeight,
    /// 血压数据 对应
    LSMeasurementDataTypeBp,
};

#define CLASS_NAME(cls) NSStringFromClass([cls class])
#define ISRequestSuccess(code) (code == 200 ? YES : NO)
#define DLUserDefaults [NSUserDefaults standardUserDefaults]

static NSString *const _kLSDMNetDisconnectedStr = @"网络未连接，请检查网络并重试";
static const NSString *DyLan = @"DyLan";


NS_ASSUME_NONNULL_END
