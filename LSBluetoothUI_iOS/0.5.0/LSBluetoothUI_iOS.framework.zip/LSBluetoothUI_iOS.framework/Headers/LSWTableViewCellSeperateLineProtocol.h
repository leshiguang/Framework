//
//  LSWTableViewCellSeperateLineProtocol.h
//  LSWearable
//
//  Created by malai on 2016/12/8.
//  Copyright © 2016年 lifesense. All rights reserved.
//  分割线

#import <Foundation/Foundation.h>

@protocol LSWTableViewCellSeperateLineProtocol <NSObject>

- (void)isSeperateLineHidden:(BOOL)isHidden;

- (void)setSeparatorLineInsets:(UIEdgeInsets)edgeInsets;

- (void)lswSetSeparatorColor:(UIColor *)color;

@end
