//
//  LSWWebKitSupport.h
//  LSWearable
//
//  Created by malai on 2017/8/22.
//  Copyright © 2017年 lifesense. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WebKit/WebKit.h>

@interface LSWWebKitSupport : NSObject

@property (nonatomic, strong, readonly) WKProcessPool *processPool;

+ (instancetype)sharedSupport;

+ (WKWebView *)createSharableWKWebView;

@end

