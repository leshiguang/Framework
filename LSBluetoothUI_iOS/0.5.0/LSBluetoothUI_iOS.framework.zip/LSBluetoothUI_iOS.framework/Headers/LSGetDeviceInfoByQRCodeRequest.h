//
//  LSGetDeviceInfoByQRCodeRequest.h
//  LSWearable
//
//  Created by wenzhengzhang on 2017/7/31.
//  Copyright © 2017年 lifesense. All rights reserved.
//

#import "LSDMBaseRequest.h"

@interface LSGetDeviceInfoByQRCodeRequest : LSDMBaseRequest

/**
 qrcode
 */
@property (nonatomic, copy) NSString *qrcode;

@end
