//
//  CornerButton.h
//  微动UIByTJ
//
//  Created by malai on 16/1/12.
//  Copyright © 2016年 malai. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CornerButton : UIButton

@end
