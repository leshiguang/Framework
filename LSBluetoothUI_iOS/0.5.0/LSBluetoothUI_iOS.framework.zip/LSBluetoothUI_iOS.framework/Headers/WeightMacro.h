//
//  WeightMacro.h
//  LSWearable
//
//  Created by sillker on 16/2/28.
//  Copyright © 2016年 lifesense. All rights reserved.
//

#ifndef WeightMacro_h
#define WeightMacro_h

//发布体重心情
#define WEIGHT_POST_MOOD_NOTIFICATION @"weightPostMoodNotification"

// jpush消息
// 通知栏收到的未知消息
#define WEIGHT_UNCONFIRM_RECORD_JPUSH_NOTIFICATION @"weightUnconfirmRecordFromJpush"
// 通知栏收到的同步消息
#define WEIGHT_UPDATE_RECORD_JPUSH_NOTIFICATION @"weightRecodUpdateByJpush"
// websocket失效收到的jpush消息
#define WEIGHT_UNCONFIRM_RECORD_JPUSH_APP_FRON @"weightUnconfirmRecordFromJpushAndWebSocketUnUsed"
// 同步最新的体重数据
#define WEIGHT_UPDATE_RECORD_NOTIFICATION @"weightRecordSyncToUpdate"
// 获取服务器发送的消息（通知栏只能获取所点击的那一条，这个是把全部获取下来）
#define WEIGHT_UNCONFIRM_RECORD_REQUEST_NOTIFICATION @"unconfirmRecordRequestToServer"
// 获取服务器发送消息的ts
#define WEIGHT_MESSAGE_REQUEST_TO_SERVER_TS @"requestToServerForJpushMessage"

// websocket
// 解绑消息
//#define DEVICE_UNBIND_NOTIFICATION @"receiveDeviceUnbindNotificationFromServer"
// 设备更新的消息
//#define DEVICE_NEWDATA_NOTIFICATION @"receiveDeviceNewDataNotificationFromWebSocket"

// 确认数据
#define confirmPostName @"confirmWeightRecordPostName"
// 登录
#define syncByLogin @"SyncWeightRecordByLogin"
#endif /* WeightMacro_h */
