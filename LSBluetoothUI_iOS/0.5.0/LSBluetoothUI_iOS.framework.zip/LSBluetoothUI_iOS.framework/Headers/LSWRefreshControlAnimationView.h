//
//  LSWRefreshControlAnimationView.h
//  LSWearable
//
//  Created by wenZheng Zhang on 16/1/15.
//  Copyright © 2016年 lifesense. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LSWRefreshControlAnimationView : UIView
+ (CGSize)preferredSize;
- (void)startAnimating;
- (void)stopAnimating;
@end
