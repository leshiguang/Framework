//
//  LSSFPRCRefreshingStateView.h
//  LSSport
//
//  Created by wenZheng Zhang on 16/1/11.
//  Copyright © 2016年 Lifesense. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LSWRefreshingStateView : UIView
@property (nonatomic) NSString *message;

- (void)startAnimating;
- (void)stopAnimating;
@end
