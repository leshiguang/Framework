//
//  LSWNewFirmwareView.h
//  LSWearable
//
//  Created by ZhangWenzheng on 16/5/14.
//  Copyright © 2016年 lifesense. All rights reserved.
//

#import "LSWFullScreenHUDBackgroundView.h"

@interface LSWNewFirmwareView : LSWFullScreenHUDBackgroundView
@property (nonatomic, strong, readonly) UIButton *cancleButton;
@property (nonatomic, strong, readonly) UIButton *upgradeButton;

- (void)setUpWithDeviceName:(NSString *)deviceName versionNum:(NSString *)versionNum featureStrings:(NSArray<NSString *> *)featureStrings;
@end
