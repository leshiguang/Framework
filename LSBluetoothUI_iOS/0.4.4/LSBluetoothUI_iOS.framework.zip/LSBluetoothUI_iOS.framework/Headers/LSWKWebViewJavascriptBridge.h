//
//  LSWKWebViewJavascriptBridge.h
//  LSWearable
//
//  Created by Wenzheng Zhang on 2017/5/3.
//  Copyright © 2017年 lifesense. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LSJavascriptBatchBridge.h"
#import <WebKit/WebKit.h>

//借鉴WebViewJavascriptBridge框架的实现原理

@interface LSWKWebViewJavascriptBridge : NSObject <WKNavigationDelegate, LSJavascriptBatchBridgeDelegate>
+ (instancetype)bridgeForWebView:(WKWebView*)webView;
+ (void)enableLogging;

- (void)registerHandler:(NSString*)handlerName handler:(LSJBHandler)handler;
- (void)registerSyncHandler:(NSString*)handlerName synchandler:(LSJBSyncMessageHandler)handler;

- (void)removeHandler:(NSString*)handlerName;
- (void)callHandler:(NSString*)handlerName;
- (void)callHandler:(NSString*)handlerName data:(id)data;
- (void)callHandler:(NSString*)handlerName data:(id)data responseCallback:(LSJBResponseCallback)responseCallback;
- (void)reset;
- (void)setWebViewDelegate:(id)webViewDelegate;
- (void)disableJavscriptAlertBoxSafetyTimeout;
- (void)injectJavascriptFile;
- (void)nativeDidSetUp;
@end
