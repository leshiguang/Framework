////
////  LSWWeightPickerViewCell.h
////  LSWearable
////
////  Created by wenZheng Zhang on 16/1/19.
////  Copyright © 2016年 lifesense. All rights reserved.
////
//
//#import <UIKit/UIKit.h>
//
//typedef NS_ENUM(NSUInteger, LSWValuePickerViewCellValueType) {
//    LSWValuePickerViewCellValueTypeSmall,
//    LSWValuePickerViewCellValueTypeMiddle,
//    LSWValuePickerViewCellValueTypeBig,
//};
//
//@interface LSWValuePickerViewCell : UICollectionViewCell
//- (void)setUpWithValueType:(LSWValuePickerViewCellValueType)valueType value:(NSInteger)value;
//@end
