//
//  NSObject+YYModel.h
//  LSDeviceManager
//
//  Created by tanjian on 2021/2/5.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSObject (YYModel)

@end

NS_ASSUME_NONNULL_END
