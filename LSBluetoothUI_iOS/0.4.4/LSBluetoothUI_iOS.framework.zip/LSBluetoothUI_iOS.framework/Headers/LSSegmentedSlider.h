//
//  LSSegmentedSlider.h
//  LSWearable
//
//  Created by Wenzheng Zhang on 2017/5/10.
//  Copyright © 2017年 lifesense. All rights reserved.
//

#import <UIKit/UIKit.h>

@class LSSegmentedSlider;

@protocol LSSegmentedSliderDelegate <NSObject>
@optional
- (void)segmentedSlider:(LSSegmentedSlider *)segmentedSlider selectedValueChanged:(double)value;
- (void)segmentedSlider:(LSSegmentedSlider *)segmentedSlider didSelectValue:(double)value;
@end

@interface LSSegmentedSlider : UIView
@property (nonatomic, weak) id <LSSegmentedSliderDelegate> delegate;


/**
 进度条到两边边距，默认20
 */
@property (nonatomic, assign) CGFloat progressViewEdgePadding;

/**
 控制点数组
 */
@property (nonatomic, copy) NSArray<NSNumber *> *controlPoints;


/**
 每个控制点的title，数量与控制点数组一致。若title长度等于0，则不显示该控制点的title
 */
@property (nonatomic, copy) NSArray<NSString *> *controlPointTitles;


/**
 分区的名字，分区数量由控制点决定。
 如[10, 20, 30, 40]四个控制点，决定的分区为[10, 20], [20, 30], [30, 40];
 */
@property (nonatomic, copy) NSArray<NSString *> *segmentNames;

/**
 分区的颜色
 */
@property (nonatomic, copy) NSArray<UIColor *> *segmentColors;


/**
 选中值
 */
@property (nonatomic, assign) double selectedValue;

//尚未构建出View，animated无效
- (void)setSelectedValue:(double)selectedValue animated:(BOOL)animated;

/**
 获取某个值所在分区索引

 @param value 数值
 @return 分区索引，小于最小值返回0，大于最大值返回最后一个分区
 */
- (NSInteger)segmentIndexForValue:(double)value controlPoints:(NSArray<NSNumber *> *)controlPoints;
@end
