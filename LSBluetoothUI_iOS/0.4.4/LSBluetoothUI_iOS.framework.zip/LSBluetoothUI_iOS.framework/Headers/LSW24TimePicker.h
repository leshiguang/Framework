//
//  LSW24TimePicker.h
//  LSWearable
//
//  Created by ZhangWenzheng on 16/8/23.
//  Copyright © 2016年 lifesense. All rights reserved.
//

#import "LSWFullScreenHUDBackgroundView.h"

@class LSW24TimePicker;

@protocol LSW24TimePickerDelegate <NSObject>
@optional
- (void)lsw24timePicker:(LSW24TimePicker *)lsw24timePicker didSelectHour:(NSInteger)hour minute:(NSInteger)minute;
@end

@interface LSW24TimePicker : LSWFullScreenHUDBackgroundView
@property (nonatomic, weak) id <LSW24TimePickerDelegate> delegate;

@property (nonatomic, copy) void(^pickHandle)(NSInteger hour, NSInteger minute);

/**
 *  最小可选小时, 默认0
 */
@property (nonatomic, assign) NSInteger minHour;

/**
 *  在最小可选小时下的最小可选分钟，默认为0
 */
@property (nonatomic, assign) NSInteger minMinitueUnderMinHour;

- (void)setUpWithTitle:(NSString *)title selectedHour:(NSInteger)selectedHour selectedMinute:(NSInteger)selectedMinute;


@end
