//
//  LSWWeightTableViewCell.h
//  LSWearable
//
//  Created by wenZheng Zhang on 16/1/21.
//  Copyright © 2016年 lifesense. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LSWSeparatorCell.h"


@interface LSWBraceletBaseTableViewCell : UITableViewCell <LSWSeparatorCell>
@property (nonatomic, strong, readonly) UIImageView *separatorLineImageView;
@property (nonatomic) UIEdgeInsets separatorLineImageViewInsets;
@end
