//
//  LSDevice+Utility.h
//  LSDeviceManager
//
//  Created by tanjian on 2020/12/28.
//

#import "LSDeviceManager.h"

NS_ASSUME_NONNULL_BEGIN

extern const NSInteger LSWDeviceUnknownSoftwareVersion;

extern const NSInteger LSWDeviceZivaOrMambo2SupportDefaltVerticalScreenMinSoftwareVersion;

extern const NSInteger LSWDeviceZivaOrMambo2SupportBatteryScreenMinSoftwareVersion;

extern const NSInteger LSWDeviceZivaOrMambo2SupportRouteRunScreenMinSoftwareVersion;

extern const NSTimeInterval kLSWDeviceBatteryStatusUpdateInterval;



typedef NS_ENUM(NSUInteger, LSWDeviceType) {
    LSWDeviceTypeUnkonwn,
    
    /*************************************************************************************************/
    /*                                              手环                                             */
    /*************************************************************************************************/
    
    /*!
     *  Bonbon
     */
    LSWDeviceTypeBraceletBonbon,
    
    /*!
     *  BonbonC
     */
    LSWDeviceTypeBraceletBonbonC,
    
    /*!
     *  Mambo 只含步数
     */
    LSWDeviceTypeBraceletMambo,
    
    /*!
     *  Mambo 来电版，含步数，来电提醒，闹钟提醒
     */
    LSWDeviceTypeBraceletMamboWithCallRemind,
    
    /*!
     *  Mambo HR，含步数，来电提醒，闹钟提醒，心率
     */
    LSWDeviceTypeBraceletMamboHR,
    
    /*!
     *  Mambo Plus，含步数，来电提醒，闹钟提醒，心率，跑步模式
     */
    LSWDeviceTypeBraceletMamboPlus,
    
    /*!
     *  Mambo Plus，含步数，来电提醒，闹钟提醒，心率，跑步模式，血氧
     */
    LSWDeviceTypeBraceletMamboPlusWithBloodO2,
    
    /*!
     *  MamboGold，LSWDeviceTypeBraceletMamboMT，含步数，来电提醒，闹钟提醒，心率，扩展设置选项
     */
    LSWDeviceTypeBraceletMamboGold,
    LSWDeviceTypeBraceletZivaI,//ziva国际版
    LSWDeviceTypeBraceletMamboMT,
    
    
    LSWDeviceTypeBraceletMid, // ziva plus
    
    /*!
     *  LSWDeviceTypeBraceletDD，含步数，来电提醒，闹钟提醒，扩展设置选项
     */
    LSWDeviceTypeBraceletDD,
    
    
    /*!
     *   1. 扫码或输入SN绑定设备，不支持蓝牙搜索绑定；
     *   2. 计步、睡眠监测，不支持心率监测；
     *   3. 来电提醒、闹钟提醒、久坐提醒、活动目标完成提醒（距离、步数、消耗）；
     *   4. OTA 中途失败后可继续使用，不会变砖；
     */
    LSWDeviceTypeBraceletEASY,
    
    /*!
     * 针对新品手环M3，APP需要新增功能包括：
     * 1. 展示并保持M3手环新增的运动类型的记录，包括：骑行/健身/瑜伽/篮球/足球/羽毛球/排球/乒乓球；
     * 2. 手环设置中，新增“运动项设置”，选择3种运动类型，并同步到手环，手环在屏幕上显示这3种运动的入口；
     
     * M3手环信息：
     * 名称：乐心手环M3
     * 工厂型号：LS428-B
     */
    LSWDeviceTypeBraceletM3,
    
    
    /**
        MIO手表
     */
    LSWDeviceTypeMIO,
    
    
    /**
        健康手表（附带ECG功能）
     */
    LSWDeviceTypeHealth,

    LSWDeviceTypeBraceletM5,
    
    LSWDeviceTypeBraceletM5S,
    
    LSWDeviceTypeBraceletMamboHR2,
    
    /*************************************************************************************************/
    /*                                             体重秤                                             */
    /*************************************************************************************************/
    
    /*!
     *  A3 (LCD)版，蓝牙
     */
    LSWDeviceTypeWeightScaleA3WithLCD,
    
    /*!
     *  A3，蓝牙
     */
    LSWDeviceTypeWeightScaleA3,
    
    /*!
     *  Q3，WIFI
     */
    LSWDeviceTypeWeightScaleQ3,
    
    /*!
     *  S3，WIFI
     */
    LSWDeviceTypeWeightScaleS3,
    
    /*!
     *  S1/S3，WIFI
     */
    LSWDeviceTypeWeightScaleS1S3,
    
    /*!
     *  S1，蓝牙
     */
    LSWDeviceTypeWeightScaleS1,
    
    /*!
     *  A4，蓝牙
     */
    LSWDeviceTypeWeightScaleA4WithBluetooth,
    
    /*!
     *  A4，WIFI
     */
    LSWDeviceTypeWeightScaleA4WithWIFI,
    
    /*!
     *  X1，蓝牙
     */
    LSWDeviceTypeWeightScaleX1,
    
    /*************************************************************************************************/
    /*                                             体脂秤                                             */
    /*************************************************************************************************/
    
    /*!
     *  S7，WIFI
     */
    LSWDeviceTypeFatScaleS7,
    
    /*!
     *  S5，WIFI
     */
    LSWDeviceTypeWeightScaleS5,
    
    /*!
     *  Melody，蓝牙
     */
    LSWDeviceTypeWeightScaleMelodyWithBluetooth,
    
    /*!
     *  Melody， WIFI
     */
    LSWDeviceTypeWeightScaleMelodyWithWIFI,
    
    /*!
     *  A3-F，蓝压
     */
    LSWDeviceTypeWeightScaleA3_F,
    
    LSWDeviceTypeWeightScaleLS202,
    
    LSWDeviceTypeWeightScaleLS206,
    
    /*!
     *  S5 mini，蓝牙
     */
    LSWDeviceTypeFatScaleNANA,
    
    //蓝牙
    LSWDeviceTypeFatScaleFIT,
    
    //血压计
    LSWDeviceTypeBloodPressureLS805H,
    
    // 1597血压计，走的是标准的ble4.0协议
    LSWDeviceTypeBloodPressureLS1597,
    
    LSWDeviceTypePayCard,

    LSWDeviceTypeBloodPressureLS818F,

    LSWDeviceTypeBloodPressureLS818NB,
    
    // A6 血压计
    LSWDeviceTypeBloodPressureLS818B,
    
    LSWDeviceTypeThirdDeviceSleepace,

};



/**
 设备支持的设置类型

 - LSWDeviceSettingTypeAlarm: 闹钟设置
 - LSWDeviceSettingTypeMixedMessageRemind: 混合消息设置
 - LSWDeviceSettingTypeSplitedMessageRemind: 分开的消息设置
 - LSWDeviceSettingTypeCallRemind: 来电提醒
 - LSWDeviceSettingTypeLongSitRemind: 久坐提醒
 - LSWDeviceSettingTypeNightMode: 夜间模式
 - LSWDeviceSettingTypeWearStateMode: 佩戴方式
 - LSWDeviceSettingTypeScreenDirection: 屏幕方向
 - LSWDeviceSettingTypeScreenContent: 显示内容
 - LSWDeviceSettingTypeDialMode: 表盘设置
 - LSWDeviceSettingTypeWeatherData: 天气设置
 - LSWDeviceSettingTypeActivityTarget: 活动目标
 - LSWDeviceSettingTypeHeartrateMode: 心率测量模式
 - LSWDeviceSettingTypeHeartrateAlarm: 心率预警
 - LSWDeviceSettingTypeSportItem: 运动项设置
 */
typedef NS_ENUM(NSUInteger, LSWDeviceSettingType) {
    LSWDeviceSettingTypeAlarm,                              //闹钟设置
    LSWDeviceSettingTypeMixedMessageRemind,                 //混合消息设置
    LSWDeviceSettingTypeSplitedMessageRemind,               //分开的消息设置
    LSWDeviceSettingTypeSplitedMessageRemind_M3Version,
    LSWDeviceSettingTypeSplitedMessageRemind_M5NewVersion,
    LSWDeviceSettingTypeSplitedMessageRemind_ZivaIVersion,
    LSWDeviceSettingTypeCallRemind,                         //来电提醒
    LSWDeviceSettingTypeLongSitRemind,                      //久坐提醒
    LSWDeviceSettingTypeLongSitRemindWatch,                 //久坐提醒(H1手表，目前hardcode，只有开关提醒)
    LSWDeviceSettingTypeNightMode,                          //夜间模式
    LSWDeviceSettingTypeNoDisturbMode,                      //勿扰模式
    LSWDeviceSettingType1224Mode,                           //24小时制
    LSWDeviceSettingTypeWearStateMode,                      //佩戴习惯
    LSWDeviceSettingTypeScreenDirection,                    //屏幕方向
    LSWDeviceSettingTypeScreenContent,                      //显示内容
    LSWDeviceSettingTypeDialMode,                           //表盘设置
    LSWDeviceSettingTypeWeatherData,                        //天气设置
    LSWDeviceSettingTypeActivityTarget,                     //活动目标
    LSWDeviceSettingTypeHeartrateMode,                      //心率测量模式
    LSWDeviceSettingTypeHeartrateAlarm,                     //心率预警
    LSWDeviceSettingTypeSportItem,                          //运动项设置
    LSWDeviceSettingTypeFamilyMember,                       //血压计家庭成员
    LSWDeviceSettingTypeSplashesMonitoring,                 //散点图心率监测
};

@interface LSDevice (LSWDeviceUtility)

+ (LSWDeviceType)LSWDU_braceletDeviceTypeWithModel:(NSString *)model salesModel:(NSString *)salesModel softwareVersion:(NSString *)softwareVersion;

+ (LSWDeviceType)LSWDU_braceletDeviceTypeWithModel:(NSString *)model;

//+ (Device *)LSWDU_currentActivtyDevice;

/**
 此设备支持的设置项

 @return 此设备支持的设置项
 */
- (NSArray<NSNumber *> *)LSWDU_supportedDeviceSettings;


/**
 设备是否支持某项设置

 @param settingType 设置类型
 @return 是否支持
 */
- (BOOL)LSWDU_isDeviceSupportSettingType:(LSWDeviceSettingType)settingType;

//普通设置
- (BOOL)LSWDU_isDeviceSupportAlarmSetting;
- (BOOL)LSWDU_isDeviceSupportMixedMessageRemind;
- (BOOL)LSWDU_isDeviceSupportSplitedMessageRemind;
- (BOOL)LSWDU_isDeviceSupportCallRemind;
- (BOOL)LSWDU_isDeviceSupportLongSitRemind;

//更多设置
- (BOOL)LSWDU_isDeviceSupportNightModeSetting;
- (BOOL)LSWDU_isDeviceSupportWearStateModeSetting;
- (BOOL)LSWDU_isDeviceSupportScreenDirectionSetting;
- (BOOL)LSWDU_isDeviceSupportScreenContentSetting;
- (BOOL)LSWDU_isDeviceSupportDialModeSetting;
- (BOOL)LSWDU_isDeviceSupportWwatherDataSetting;
- (BOOL)LSWDU_isDeviceSupportActivityTargetSetting;
- (BOOL)LSWDU_isDeviceSupportHeartrateSetting;
- (BOOL)LSWDU_isDeviceSupportHeartrateAlarmSetting;


//此设备支持的自定义屏幕内容类型
- (NSArray<NSNumber *> *)LSWDU_supportedScreenContent;


//基础记录功能
- (BOOL)LSWDU_isDeviceSupportSleepRecording;
- (BOOL)LSWDU_isDeviceSupportHeartrateRecording;
- (BOOL)LSWDU_isDeviceSupportSprotRecording;
- (BOOL)LSWDU_isDeviceTypeSupportGPSRecording;


/**
 是否支持有氧运动

 @return yes or no
 */
- (BOOL)LSWDU_isDeviceSupportAerobicSport;

/**
 是否支持ECG
 
 @return yes or no
 */
- (BOOL)LSWDU_isDeviceSupportEcg;

/**
 是否支持散点图心率监测
 
 @return yes or no
 */
- (BOOL)LSWDU_isDeviceSupportHMSplashes;
/**
 获取设备的固件版本
 
 @return 获取成功则返回相应数值，否则返回LSWDeviceUnknownSoftwareVersion
 */
- (NSInteger)LSWDU_softwareVersionIntegerValue;


/**
 是否为乐心互联设备

 @return 是否为乐心互联设备
 */
- (BOOL)LSWDU_isLifesenseInterconnectDevice;

#pragma mark -
- (LSWDeviceType)LSWDU_deviceType;
- (BOOL)LSWDU_deviceM3Family;
- (LSWDeviceType)LSWDU_braceletDeviceType;
- (LSWDeviceType)LSWDU_weightScaleDeviceType;
- (UIImage *)LSWDU_deviceIconImage;
- (NSString *)LSWDU_powerDescriptionWithPowerPersentage:(NSNumber *)powerPersentage;
- (NSString *)LSWDU_powerLevelImageNameForPowerPersentage:(NSNumber *)powerPersentage;
- (BOOL)LSWDU_isCanSetUnit;
- (BOOL)LSWDU_isScalCanOTA;
- (BOOL)LSWDU_isScaleDevice;
- (BOOL)LSWDU_isBloodPressureDevice;
- (BOOL)LSWDU_isBandDevice;
- (NSString *)LSWDU_imageNameForChargingState;

- (BOOL)LSWDU_isPayCard;
- (BOOL)LSWDU_isThirdDevice;
/**
 正常使用下的低电量警告阀值

 @return 0 ～ 1
 */
- (CGFloat)LSWDU_normoalUsageLowBatteryBorder;

- (BOOL)LSWDU_isM3;
- (BOOL)LSWDU_isSupportAlipay;
- (BOOL)LSWDU_isM5Version200;

/*
 * 是否是第三方设备智能枕头Sleepace
 */
- (BOOL)LSWDU_isThirdDeviecSleepace;
@end


@interface LSDevice (Utility)

- (BOOL)isBandDevice;
- (BOOL)isScaleDevice;

@end

NS_ASSUME_NONNULL_END
