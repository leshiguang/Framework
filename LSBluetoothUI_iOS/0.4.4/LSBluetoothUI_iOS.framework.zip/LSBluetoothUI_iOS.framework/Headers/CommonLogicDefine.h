//
//  CommonLogicDefine.h
//  LSWearable
//
//  Created by rolandxu on 12/18/15.
//  Copyright © 2015 lifesense. All rights reserved.
//

#ifndef CommonLogicDefine_h
#define CommonLogicDefine_h

#import "HttpErrcode.h"

#define INVALID_REQUEST_ID -1

//字符串判断为null或是nil,类型必须是NSString
#define IsEmptyNSString(x) ((x)==nil || [(x) length]==0)

#pragma mark DictionaryUtils
// Dictionary操作
#define LSGetDictionaryStringDefaultNil(dict,key) [NSDictionaryUtil getDictionaryString:dict forKey:key defaultValue:nil]
#define LSGetDictionaryString(dict,key,default) [NSDictionaryUtil getDictionaryString:dict forKey:key defaultValue:default]
#define LSGetDictionaryNumberDefaultNil(dict,key) [NSDictionaryUtil getDictionaryNumber:dict forKey:key defaultValue:nil]
#define LSGetDictionaryNumber(dict,key,default) [NSDictionaryUtil getDictionaryNumber:dict forKey:key defaultValue:default]
#define LSGetDictionaryIntDefaultZero(dict,key) [NSDictionaryUtil getDictionaryInt:dict forKey:key defaultValue:0]
#define LSGetDictionaryInt(dict,key,default) [NSDictionaryUtil getDictionaryInt:dict forKey:key defaultValue:default]
#define LSGetDictionaryLongDefaultZero(dict,key) [NSDictionaryUtil getDictionaryLong:dict forKey:key defaultValue:0]
#define LSGetDictionaryLong(dict,key,default) [NSDictionaryUtil getDictionaryLong:dict forKey:key defaultValue:default]
#define LSGetDictionaryBoolDefaultFalse(dict,key) [NSDictionaryUtil getDictionaryLong:dict forKey:key defaultValue:false]
#define LSGetDictionaryBool(dict,key,default) [NSDictionaryUtil getDictionaryLong:dict forKey:key defaultValue:default]
#define LSGetDictionaryArrayDefaultNil(dict,key) [NSDictionaryUtil getDictionaryArray:dict forKey:key defaultValue:nil]
#define LSGetDictionaryArrayDefaultNilWithItemClass(dict,key,itemClass) [NSDictionaryUtil getDictionaryArrayWithItemClass:dict forKey:key defaultValue:nil itemclass:itemClass]

#define LSGetDictionaryDate(dict,key,default) [NSDictionaryUtil getDictionaryDate:dict forKey:key defaultValue:default]
#define LSGetDictionaryDateDefaultNil(dict,key) [NSDictionaryUtil getDictionaryDate:dict forKey:key defaultValue:nil]

#define LSGetDictionaryArray(dict,key) [NSDictionaryUtil getDictionaryArray:dict forKey:key defaultValue:[NSMutableArray arrayWithCapacity:0]]
#define LSGetDictionaryArrayWithItemClass(dict,key,itemClass) [NSDictionaryUtil getDictionaryArrayWithItemClass:dict forKey:key defaultValue:[NSMutableArray arrayWithCapacity:0] itemClass:itemClass]

#define LSGetDictionaryDictionaryDefaultNil(dict,key) [NSDictionaryUtil getDictionaryDictionary:dict forKey:key defaultValue:nil]
#define LSGetDictionaryDictionary(dict,key) [NSDictionaryUtil getDictionaryDictionary:dict forKey:key defaultValue:[NSMutableDictionary dictionaryWithCapacity:0]]


#endif /* CommonLogicDefine_h */
