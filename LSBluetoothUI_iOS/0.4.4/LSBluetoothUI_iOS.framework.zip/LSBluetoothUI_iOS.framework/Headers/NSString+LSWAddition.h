//
//  NSString+TCAddition.h
//  HKWeibo
//
//  Created by Vincentc Lin on 12-9-7.
//  Copyright (c) 2012年 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

#define IsEmptyNSString(x) ((x)==nil || [(x) length]==0)
#define IsNotEmptyNSString(x) ((x)!=nil && [(x) length]>0)

@interface NSString (LSWAddition)

- (NSInteger)byteLengthWithEncoding:(NSStringEncoding)encoding;

+ (NSString *)timestamp;

+ (NSString *)StringOfPreferredLanguage;
+ (NSString *)randomString;
- (NSString *)macUpsizedown;

- (BOOL)isValidEmailAddress;
- (BOOL)isValidPasswordLength;
- (BOOL)isLettersAndNumbersOnly;

- (NSInteger)lsw_ComposedCharacterLength;
- (BOOL)lsw_isComposedCharacterExceedLength:(NSInteger)length;

- (NSString *)lsw_limitComposedCharacterToLength:(NSInteger)length;

// 判断是否有非法字符
- (BOOL)isHaveIllegalCharacter;

#pragma mark - for measurementDate
- (NSString *)yearMonthDay;
- (NSString *)hourMin;

//文字宽度
+(CGFloat)widthOfString:(NSString *)string font:(UIFont *)font height:(CGFloat)height;
+(CGFloat)heightOfString:(NSString *)string font:(UIFont *)font width:(CGFloat)width;

- (BOOL)isEmptyString;

+ (NSString *)timeWithIntValue:(NSInteger)intValue;
+ (NSString *)hourTimeWithValue:(NSInteger)intValue;

/*!
 *  LSDevice SN码
 *
 *  @return SN码 每隔4个空一格
 */
- (NSString *)lsw_stringByDeviceSN;


/**
 转化成url

 @return url
 */
- (NSURL *)lsw_url;

- (NSString *)lsw_stringByRemoveZero;

/**
  时间段获取
 */
+ (NSString *)getTheTimeBucket;

/**
  时间戳转日期字符串
 */
+ (NSString *)dateStringFromTimestamp:(long)timeStamp dateFormat:(NSString *)datFormat;
@end




