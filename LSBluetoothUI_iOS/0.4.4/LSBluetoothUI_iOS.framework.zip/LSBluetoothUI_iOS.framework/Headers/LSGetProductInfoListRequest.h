//
//  LSGetProductInfoListRequest.h
//  LSWearable
//
//  Created by wenzhengzhang on 2017/7/31.
//  Copyright © 2017年 lifesense. All rights reserved.
//

#import "LSDMBaseRequest.h"

@interface LSGetProductInfoListRequest : LSDMBaseRequest

/**
 展示分类  精准匹配
 （0:所有设备 1:手环 2:手表 3:智能秤 4:血压计 5:乐心互联
 */
@property (nonatomic, copy) NSString *productClassify;

@end
