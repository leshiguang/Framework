//
//  LSDownloadManager.h
//  LSWearable
//
//  Created by Wenzheng Zhang on 2017/7/20.
//  Copyright © 2017年 lifesense. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LSDownloadManagerProtocol.h"
@interface LSDownloadManager : NSObject <LSDownloadManagerProtocol>

@end
