//
//  LSWAttributedUtil.h
//  LSWearable
//
//  Created by malai on 2018/6/14.
//  Copyright © 2018年 lifesense. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LSWAttributedUtil : NSObject

/**
 高亮数字字符串

 @param string 字符串
 @param attrs 属性
 @return 富文本
 */
+ (NSAttributedString *)hightlightDigitString:(NSString *)string highlightAttrs:(nullable NSDictionary<NSAttributedStringKey, id> *)highlightAttrs attrs:(nullable NSDictionary<NSAttributedStringKey, id> *)attrs;

/**
 高亮正则匹配的字符串
 
 @param regular 正则表达式
 @param string 字符串
 @param highlightAttrs 高亮属性
 @param attrs 属性
 @return 富文本
 */
+ (NSAttributedString *)highlightWithRegular:(NSString *)regular string:(NSString *)string highlightAttrs:(nullable NSDictionary<NSAttributedStringKey, id> *)highlightAttrs attrs:(nullable NSDictionary<NSAttributedStringKey, id> *)attrs;

/**
 合成图片和文字

 @param icon 图片所对应的富文本
 @param symbol 图片在字符串的替代符号  例如： 没有在配置状态（ * 闪烁）下进行配置；其中 * 就是用icon去替换的
 @param string 文本
 @param attrs 属性
 @return 富文本
 */
+ (NSAttributedString *)composeWithIcon:(NSAttributedString *)icon symbol:(NSString *)symbol string:(NSString *)string attrs:(nullable NSDictionary<NSAttributedStringKey, id> *)attrs;

+ (NSAttributedString *)attributedStringWithText:(NSString *)text textColor:(UIColor *)color textFont:(UIFont *)font;

+ (NSAttributedString *)attributedStringWithText:(NSString *)text textColor:(UIColor *)color textFont:(UIFont *)font hasUnderlineStyle:(BOOL)hasUnderLineStyle lineSpacing:(float)line paragraphSpacing:(float)paragraph;

+ (NSAttributedString *)attributedStringWithImage:(UIImage *)image imageBounds:(CGRect)bounds;

+ (NSMutableAttributedString *)jointAttributedStringWithItems:(NSArray *)items;


+ (NSAttributedString *)attributedTextArray:(NSArray *)texts
                                 textColors:(NSArray *)colors
                                  textfonts:(NSArray *)fonts;


+ (NSAttributedString *)attributedTextArray:(NSArray *)texts
                                 textColors:(NSArray *)colors
                                  textfonts:(NSArray *)fonts
                                lineSpacing:(CGFloat)l_spacing;


+ (CGSize)sizeLabelWidth:(CGFloat)width
          attributedText:(NSAttributedString *)attributted;


+ (CGSize)sizeLabelWidth:(CGFloat)width
                    text:(NSString *)text
                    font:(UIFont *)font;


+ (CGSize)sizeLabelWidth:(CGFloat)width
                    text:(NSString *)text
                    font:(UIFont *)font
             lineSpacing:(CGFloat)l_spacing;

+ (NSMutableParagraphStyle *)paragraphStyleWithLineSpace:(CGFloat)lineSpace;
+ (NSMutableParagraphStyle *)paragraphStyleWithAlignment:(NSTextAlignment)alignment lineSpace:(CGFloat)lineSpace;



@end


@interface NSString (LSWLineSpace)

    // 设置行间距
- (NSAttributedString *)lsw_lineWithSpace:(CGFloat)space;

- (NSAttributedString *)lsw_lineWithSpace:(CGFloat)space textAlignment:(NSTextAlignment)textAlignment;

- (NSAttributedString *)lsw_groupLineSpace;

- (NSAttributedString *)lsw_heartAlertTipLineSpace;

- (NSAttributedString *)lsw_groupLineSpaceByCenter;

- (NSAttributedString *)lsw_defaultLineSpaceByJustified;


/**
 行间距默认为5
 
 @return 富文本
 */
- (NSAttributedString *)lsw_defaultLineSpace;


/**
 行间距默认为5的居中字段
 
 @return 富文本
 */
- (NSAttributedString *)lsw_defaultLineSpaceByCenter;

@end

@interface UILabel (LSWAttributed)

- (void)lsw_labelText:(NSString *)text
          lineSpacing:(CGFloat)l_spacing;


- (void)lsw_labelText:(NSString *)text
       sectionSpacing:(CGFloat)s_spacing
          lineSpacing:(CGFloat)l_spacing;

@end

NS_ASSUME_NONNULL_END




