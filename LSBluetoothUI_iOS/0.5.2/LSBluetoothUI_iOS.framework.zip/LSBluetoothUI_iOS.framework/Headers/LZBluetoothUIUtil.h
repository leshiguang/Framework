//
//  LZBluetoothUIUtil.h
//  CocoaDebug
//
//  Created by tanjian on 2021/1/28.
//

#import <Foundation/Foundation.h>
#import <LZBluetooth/LZBluetooth.h>

NS_ASSUME_NONNULL_BEGIN

@interface LZBluetoothUIUtil : NSObject

/// 设置类型
/// @param settingType 设置类型
+ (NSString *)titleWithSettingType:(LZDeviceSettingType)settingType;

+ (NSString *)displayStringWith:(NSString *)macString;

@end

NS_ASSUME_NONNULL_END
