//
//  LSWechatService.h
//  LSMediator
//
//  Created by aaaaa aaaaa on 2020/1/19.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^LZWechatCallback)(int code, NSString *msg, id _Nullable data);

@protocol LZShareKit <NSObject>

- (void)shareWithConfig:(NSDictionary *)config completion:(void(^)(int code, NSString *msg))completion;

/// 注册微信
/// @param appid 微信appid
/// @param universalLink universalLink
- (BOOL)registerWxApp:(NSString *)appid universalLink:(NSString *)universalLink;

/// 处理回调
- (BOOL)handleUrl:(NSURL *)url;

/// 处理UniversalLink回调
- (BOOL)handleOpenUniversalLink:(NSUserActivity *)userActivity;

@end

NS_ASSUME_NONNULL_END
