//
//  NSCalendar+LSCalendarAdditions.h
//  LSWearable
//
//  Created by ZhangWenzheng on 16/3/8.
//  Copyright © 2016年 lifesense. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSCalendar (LSCalendarAdditions)


- (NSDate *)dateForBeginningOfDay:(NSDate *)date;
- (NSDate *)dateForEndOfDay:(NSDate *)date;

/*!
 * 计算两个Date之间的天数，例如今天和明天的间隔天数为1天
 *
 * @param
 * startDate 开始时间。
 *
 * @param
 * endDate 终止时间。
 *
 * @return
 * 两个date之间的时间间隔。
 */
- (NSInteger)daysBetweentStartDate:(NSDate *)startDate andEndDate:(NSDate *)endDate;

/**
 *   检测某个Date是否在当天的前天
 *
 *  @param date date date
 *
 *  @return YES表示和当天是当天的前天，NO表示不是
 */
- (BOOL)ls_isDateInDayBeforeyesterday:(NSDate *)date;

/**
 *  检测某个Date是否在当周，每周的第一天为周一
 *
 *  @param date date
 *
 *  @return YES表示和当天是在同一周，NO表示不是
 */
- (BOOL)ls_isDateInThisWeek:(NSDate *)date;

/**
 *  检测某个Date是否在上周，每周的第一天为周一
 *
 *  @param date date
 *
 *  @return YES表示是在同上周，NO表示不是
 */
- (BOOL)ls_isDateInLastWeek:(NSDate *)date;

/**
 *  检测某个Date是否在当月
 *
 *  @param date date
 *
 *  @return YES表示和当天是在同一月，NO表示不是
 */
- (BOOL)ls_isDateInThisMonth:(NSDate *)date;

/**
 *  检测某个Date是否在上个月
 *
 *  @param date date
 *
 *  @return YES是在上个月，NO表示不是
 */
- (BOOL)ls_isDateInLastMonth:(NSDate *)date;

/**
 *  获取date所在周的最后一天，每周的第一天为周一
 *
 *  @param date date
 *
 *  @return date所在周的最后一天
 */
- (NSDate *)ls_dateForEndOfWeekWithDate:(NSDate *)date;

/**
 *  获取date所在周的第一天，每周的第一天为周一
 *
 *  @param date date
 *
 *  @return date所在周的第一天
 */
- (NSDate *)ls_dateForBeginningInWeekWithDate:(NSDate *)date;
@end
