//
//  LSApplyThirdDeviceIdRequest.h
//  LSWearable
//
//  Created by symons on 2019/10/24.
//  Copyright © 2019 Wenzheng Zhang. All rights reserved.
//

#import "LSDMBaseRequest.h"


@interface LSApplyThirdDeviceIdRequest : LSDMBaseRequest

/**
 mac地址 非必传
 */
@property (nonatomic, copy) NSString *mac;

/**
 硬件版本 非必传
 */
@property (nonatomic, copy) NSString *hardwareVersion;

/**
 固件版本 非必传
 */
@property (nonatomic, copy) NSString *softwareVersion;

/**
 厂商Id  必传
 */
@property (nonatomic, copy) NSString *venderId;

/**
 型号
 */
@property (nonatomic, copy) NSString *model;

/**
 第三方设备唯一标识 必传
 */
@property (nonatomic, copy) NSString *thirdDeviceId;

/**
  设备的广播ID 必传
*/
@property (nonatomic, copy) NSString *broadcastId;

@end


