//
//  LSDeviceManager+OTA.h
//  LSDeviceManagerTests
//
//  Created by alex.wu on 2019/9/9.
//  Copyright © 2019 Wenzheng Zhang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LSDeviceManager.h"

NS_ASSUME_NONNULL_BEGIN

typedef void(^LSOtaCompletion)(UInt32 result);
typedef void(^LSOtaProgress)(double progress);
typedef void(^LSDMMatchBlock)(BOOL bMatch);

@interface LSDeviceManager(OTA)

/// 取消升级设备(ota)
- (void)cancelUpgradeDevice:(NSString *)deviceId;

- (void)upgradDevice:(NSString *)deviceId
            filePath:(NSString *)filePath
            progress:(LSOtaProgress)progress
          completion:(LSOtaCompletion)completion;


/// 检测是否有固件版本更新
/// @param model 产品型号
/// @param hardwareVersion 硬件版本
/// @param softwareVersion 软件版本
/// @param deviceid 设备id
/// @param completion 回调
- (void)checkFirmwareModel:(NSString *)model hardwareVersion:(NSString *)hardwareVersion softwareVersion:(NSString *)softwareVersion deviceId:(NSString *)deviceid Completion:(void(^)(int code,NSString *msg,NSDictionary *data))completion;

/// 设置设备固件版本
/// @param version 固件版本
/// @param device 设备
- (void)updateDeviceVersion:(NSString *)version device:(Device *)device;



@end

NS_ASSUME_NONNULL_END
