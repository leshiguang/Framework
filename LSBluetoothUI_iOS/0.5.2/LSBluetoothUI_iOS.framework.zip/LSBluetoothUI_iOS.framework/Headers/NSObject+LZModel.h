
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN


@interface NSObject (LZModel)


+ (nullable instancetype)lz_modelWithJSON:(id)json;


+ (nullable instancetype)lz_modelWithDictionary:(NSDictionary *)dictionary;

- (BOOL)lz_modelSetWithJSON:(id)json;


- (BOOL)lz_modelSetWithDictionary:(NSDictionary *)dic;


- (nullable id)lz_modelToJSONObject;


- (nullable NSData *)lz_modelToJSONData;


- (nullable NSString *)lz_modelToJSONString;


- (nullable id)lz_modelCopy;


- (void)lz_modelEncodeWithCoder:(NSCoder *)aCoder;


- (id)lz_modelInitWithCoder:(NSCoder *)aDecoder;


- (NSUInteger)lz_modelHash;


- (BOOL)lz_modelIsEqual:(id)model;

- (NSString *)lz_modelDescription;

@end



@interface NSArray (LZModel)

+ (nullable NSArray *)lz_modelArrayWithClass:(Class)cls json:(id)json;

@end


@interface NSDictionary (LZModel)


+ (nullable NSDictionary *)lz_modelDictionaryWithClass:(Class)cls json:(id)json;
@end


@protocol LZModel <NSObject>
@optional


+ (nullable NSDictionary<NSString *, id> *)modelCustomPropertyMapper;


+ (nullable NSDictionary<NSString *, id> *)modelContainerPropertyGenericClass;


+ (nullable Class)modelCustomClassForDictionary:(NSDictionary *)dictionary;


+ (nullable NSArray<NSString *> *)modelPropertyBlacklist;

+ (nullable NSArray<NSString *> *)modelPropertyWhitelist;


- (NSDictionary *)modelCustomWillTransformFromDictionary:(NSDictionary *)dic;


- (BOOL)modelCustomTransformFromDictionary:(NSDictionary *)dic;


- (BOOL)modelCustomTransformToDictionary:(NSMutableDictionary *)dic;

@end

NS_ASSUME_NONNULL_END
