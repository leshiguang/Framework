//
//  LZPickerAnimator.h
//  LSBluetoothUI_iOS
//
//  Created by wm on 2020/12/14.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LZPickerAnimator : UIPresentationController <UIViewControllerTransitioningDelegate>

@end

NS_ASSUME_NONNULL_END
