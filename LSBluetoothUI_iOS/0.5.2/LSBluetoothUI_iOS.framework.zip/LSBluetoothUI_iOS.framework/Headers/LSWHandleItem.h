//
//  LSWHandleItem.h
//  LSWearable
//
//  Created by malai on 2017/6/27.
//  Copyright © 2017年 lifesense. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LSWHandleItem : NSObject

@property (nonatomic, copy) NSString *identifier;

@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *secondTitle;
@property (nonatomic, copy) UIColor *secondTitleColor;
@property (nonatomic, copy) NSString *thirdTitle;
@property (nonatomic, copy) NSNumber *isOnOff;//boolvalue
@property (nonatomic, copy) dispatch_block_t handle;


/**
 一般cell的item，有个title 有个identifier 还有个点击事件

 @param identifier cell 的identifier
 @param title 标题
 @param handle 点击事件
 @return item
 */
+ (instancetype)handleItemWithIdentifier:(NSString *)identifier title:(NSString *)title handle:(dispatch_block_t)handle;

@end

#pragma mark - LSWDetailHandleItem
@interface LSWDetailHandleItem : LSWHandleItem

@property (nonatomic, copy) NSString *detail;

@property (nonatomic, strong) id origin;

@end

#pragma mark - LSWInputHandleItem
@interface LSWInputHandleItem : LSWHandleItem

@property (nonatomic, copy) NSString *placeHold;

@property (nonatomic, copy) NSString *pwd;

@end



#pragma mark - LSWHeadImageHandleItem
@interface LSWHeadImageHandleItem : LSWHandleItem

@property (nonatomic, copy) NSURL *imgUrl;

@property (nonatomic, copy) UIImage *placeHoldImg;

@end


#pragma mark - LSWDeviceUserHandleItem

@interface LSWDeviceUserHandleItem : LSWHeadImageHandleItem

@property (nonatomic, copy) NSString *userId;

@end

