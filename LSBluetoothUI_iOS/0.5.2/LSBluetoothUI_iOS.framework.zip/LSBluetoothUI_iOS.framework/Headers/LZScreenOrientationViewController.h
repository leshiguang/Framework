//
//  LZScreenOrientationViewController.h
//  LSBluetoothUI_iOS
//
//  Created by wm on 2020/12/8.
//

#import "LZBaseSettingViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface LZScreenOrientationViewController : LZBaseSettingViewController

@end

NS_ASSUME_NONNULL_END
