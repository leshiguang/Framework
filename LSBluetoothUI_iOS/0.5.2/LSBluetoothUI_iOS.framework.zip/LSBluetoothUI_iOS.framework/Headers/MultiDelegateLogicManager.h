//
//  MultiDelegateLogicManager.h
//  WDGroup
//
//  Created by rolandxu on 12/21/15.
//  Copyright © 2015 WDG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MultiDelegateLogicManagerProtocol.h"

@interface MultiDelegateLogicManager : NSObject
<MultiDelegateLogicManagerProtocol>

@end
