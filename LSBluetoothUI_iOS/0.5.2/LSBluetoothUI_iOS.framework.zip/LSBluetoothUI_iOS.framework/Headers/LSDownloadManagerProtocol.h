//
//  LSDownloadManagerProtocol.h
//  LSWearable
//
//  Created by Wenzheng Zhang on 2017/7/20.
//  Copyright © 2017年 lifesense. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol LSDownloadManagerProtocol <NSObject>
//如果没有指定filePath  默认到存cache中
- (void) DownloadUrl:(NSString *)urlStr filePath:(NSString *)filePath success:(void (^)(NSURL *url))success fail:(void (^)(NSError *error))fail;

- (void)downloadUrl:(NSString *)urlStr filePath:(NSString *)filePath progress:(void (^)(double progress))progress success:(void (^)(NSURL *url))success fail:(void (^)(NSError *error))fail;
@end
