//
//  LSWOTAProgressView.h
//  LSWearable
//
//  Created by ZhangWenzheng on 16/5/12.
//  Copyright © 2016年 lifesense. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LSWOTAProgressView : UIView

/**
 *  进度 0 ～ 100
 */
@property (nonatomic) NSInteger progress;

- (void)startRotation;
- (void)setProgress:(NSInteger)progress animated:(BOOL)animated;
@end
