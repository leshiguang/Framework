//
//  LSBloodPressureSyncDataManager.h
//  LSBluetoothUI_iOS
//
//  Created by tanjian on 2021/3/9.
//

#import <Foundation/Foundation.h>
#import "LSBloodPressureData.h"

NS_ASSUME_NONNULL_BEGIN

@interface LSBloodPressureSyncDataManager : NSObject

+ (instancetype)shareInstance;

- (void)syncBpData:(LSBloodPressureData *)bpData completion:(void(^)(BOOL result, BOOL isNetworkSuccess))completion;

@end

NS_ASSUME_NONNULL_END
