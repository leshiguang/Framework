//
//  LZSwimingViewController.h
//  lzbluetooth-mini-ui-ios
//
//  Created by tanjian on 2021/1/19.
//

#import "LZBaseSettingViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface LZSwimingViewController : LZBaseSettingViewController

@end

NS_ASSUME_NONNULL_END
