//
//  LZWechatService.h
//  Pods
//
//  Created by tanjian on 2021/5/20.
//

#ifndef LZWechatService_h
#define LZWechatService_h

NS_ASSUME_NONNULL_BEGIN

typedef void(^LZWechatCallback)(int code, NSString *msg, id _Nullable data);

@protocol LZWechat <NSObject>

+ (instancetype)sharedInstance;

/// 注册微信
/// @param appid 微信appid
/// @param universalLink universalLink
- (BOOL)registerApp:(NSString *)appid universalLink:(NSString *)universalLink;

/// 处理回调
- (BOOL)handleUrl:(NSURL *)url;

/// 处理UniversalLink回调
- (BOOL)handleOpenUniversalLink:(NSUserActivity *)userActivity;

/// 微信是否安装
- (BOOL)wxInstall;

/// 当前微信的版本是否支持OpenApi
- (BOOL)isWXAppSupportApi;

/// 打开微信客户端
- (void)openWXApp;
/// 授权请求
/// @param scope 第三方程序要向微信申请认证，并请求某些权限，需要调用WXApi的sendReq成员函数，向微信终端发送一个SendAuthReq消息结构。微信终端处理完后会向第三方程序发送一个处理结果。
/// @param state 第三方程序本身用来标识其请求的唯一性，最后跳转回第三方程序时，由微信终端回传。 state字符串长度不能超过1K
- (BOOL)authWithScope:(NSString *)scope
                state:(NSString *)state
                callback:(LZWechatCallback)callback;

/// 发送微信支付请求
/// @param partnerId 商家向财付通申请的商家id
/// @param prepayId 预支付订单
/// @param nonceStr 随机串，防重发
/// @param timeStamp 时间戳，防重发
/// @param package 商家根据财付通文档填写的数据和签名
/// @param sign 商家根据微信开放平台文档对数据做的签名
- (BOOL)payWithPartnerId:(NSString *)partnerId
                prepayId:(NSString *)prepayId
                nonceStr:(NSString *)nonceStr
               timeStamp:(UInt32)timeStamp
                 package:(NSString *)package
                    sign:(NSString *)sign
                callback:(LZWechatCallback)callback;

/// 分享图片或者url
/// @param image 目标图片
/// @param thumbImage 缩略图
/// @param title 标题
/// @param description 描述
/// @param url 分享的链接
/// @param scene 0: 微信好友 1:朋友圈 2:收藏
- (BOOL)shareToWxWithImage:(UIImage *)image
                thumbImage:(UIImage *)thumbImage
                     title:(nullable NSString *)title
               description:(nullable NSString *)description
                       url:(nullable NSURL *)url
                     scene:(int)scene
                callback:(LZWechatCallback)callback;

/// 分享文件
/// @param path 文件路径
/// @param thumbImage 缩略图
/// @param title 标题
/// @param description 描述
/// @param scene 0: 微信好友 1:朋友圈 2:收藏
- (BOOL)shareToWxWithFile:(NSString *)path
               thumbImage:(nullable UIImage *)thumbImage
                    title:(nullable NSString *)title
              description:(nullable NSString *)description
                    scene:(int)scene
                    callback:(LZWechatCallback)callback;

/// 微信分享小程序
/// @param webpageUrl 兼容低版本的网页链接
/// @param userName 小程序的userName
/// @param path 小程序的页面路径
/// @param haImageDate 小程序新版本的预览图二进制数据，6.5.9及以上版本微信客户端支持
/// @param withShareTicket 是否使用带shareTicket的分享
/// @param miniprogramType 小程序的类型，默认正式版，1.8.1及以上版本开发者工具包支持分享开发版和体验版小程序
/// @param title 小程序标题
/// @param description 小程序描述
/// @param thumbData 兼容旧版本节点的图片，小于32KB，新版本优先，使用WXMiniProgramObject的hdImageData属性
- (BOOL)shareToWXMiniProgramObjectWithWebpageUrl:(NSString *)webpageUrl
                                        userName:(NSString *)userName
                                            path:(NSString *)path
                                     haImageData:(NSData * _Nullable)haImageDate
                                 withShareTicket:(BOOL)withShareTicket
                                 miniprogramType:(NSInteger)miniprogramType
                                           title:(NSString *)title
                                     description:(NSString *)description
                                       thumbData:(NSData * _Nullable)thumbData
                                        callback:(LZWechatCallback)callback;

@end

NS_ASSUME_NONNULL_END

#endif /* LZWechatService_h */
