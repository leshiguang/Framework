//
//  LSReceiveData.h
//  LSBluetoothUI_iOS
//
//  Created by tanjian on 2021/2/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LSReceiveData : NSObject

/// 数据唯一id UUID
@property (nonatomic, copy) NSString *dataId;

/// 用户id
@property (nonatomic, copy) NSNumber *userId;

/// 设备id 必传
@property (nonatomic, copy) NSString *deviceId;

/// 软件版本
@property (nonatomic, copy) NSString *softVer;

/// 设备型号
@property (nonatomic, copy) NSString *model;

@end

NS_ASSUME_NONNULL_END
