//
//  LSSetWeightScaleUnitRequest.h
//  LSWearable
//
//  Created by wenzhengzhang on 2017/7/31.
//  Copyright © 2017年 lifesense. All rights reserved.
//

#import "LSDMBaseRequest.h"

@interface LSSetWeightScaleUnitRequest : LSDMBaseRequest

/**
 deviceId
 */
@property (nonatomic, copy) NSString *deviceId;

/**
 unit
 */
@property (nonatomic, copy) NSString *unit;

@end
