////
////  LSWAlphaChangingFlowLayout.h
////  LSWearable
////
////  Created by wenZheng Zhang on 16/1/19.
////  Copyright © 2016年 lifesense. All rights reserved.
////
//
//#import <UIKit/UIKit.h>
//#import "LSWValuePickerViewCell.h"
//@class LSWAlphaChangingFlowLayout;
//
//@protocol LSWAlphaChangingFlowLayoutDataSource <NSObject>
//@required
//- (LSWValuePickerViewCellValueType)collectionView:(UICollectionView *)collectionView layout:(LSWAlphaChangingFlowLayout *)alphaChangingFlowLayout valueTypeForItemAtIndexPath:(NSIndexPath *)indexPath;
//@end
//
//@interface LSWAlphaChangingFlowLayout : UICollectionViewFlowLayout
//@property (nonatomic, weak) id <LSWAlphaChangingFlowLayoutDataSource> dataSource;
//@end
