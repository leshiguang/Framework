//
//  NSObject+LZMultiDelegate.h
//  LZBluetooth
//
//  Created by tanjian on 2020/11/19.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/// 执行某个服务的方法，这里有个问题，就是如果params 是@[xxx, xxx]; 则必须要括号包住(@[xxx, xxx])
#define LZPerform(service_protocol, selector, params) [self performSelector:selector withArgv:params forService:@protocol(service_protocol)];

/// 在主线程执行某个服务的方法
#define LZPerformOnMainThread(service_protocol, selector, params) [self lz_performSelector:selector withArgv:params forService:@protocol(service_protocol) onMainThread:YES];

#define LZActorPerformOnMainThread(actor, service_protocol, selector, params) [actor lz_performSelector:selector withArgv:params forService:@protocol(service_protocol) onMainThread:YES];

@protocol LZMultiDelegate <NSObject>

- (void)lz_addDelegate:(id)delegate forProtocol:(Protocol *)protocol;
- (void)lz_removeDelegate:(id)delegate forProtocol:(Protocol *)protocol;
- (void)lz_removeAllDelegatesForProtocol:(Protocol *)protocol;
- (void)lz_removeAllDegatesForAllProtocols;

- (void)lz_performforProtocol:(Protocol *)protocol selector:(SEL)selector, ...;

@end

@interface NSObject (LZMultiDelegate) <LZMultiDelegate>

@end

NS_ASSUME_NONNULL_END
