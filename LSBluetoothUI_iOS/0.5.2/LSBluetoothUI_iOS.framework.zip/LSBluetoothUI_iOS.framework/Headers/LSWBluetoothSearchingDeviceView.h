//
//  LSWBluetoothSearchingDeviceView.h
//  LSWearable
//
//  Created by Wenzheng Zhang on 2017/2/27.
//  Copyright © 2017年 lifesense. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LSWBluetoothSearchingDeviceView : UIView

- (void)startWaveAnimation;
- (void)stopWaveAnimation;

@end
