//
//  UIImage+LSWMostColor.h
//  LSWearable
//
//  Created by malai on 16/9/14.
//  Copyright © 2016年 lifesense. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (LSWMostColor)

- (UIColor *)lsw_mostColor;

@end
