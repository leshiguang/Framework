
function imageSourceFromPoint(x, y) {
    
    var element = document.elementFromPoint(x, y);
    
    
    if (element.tagName == 'IMG' && element.src) {
        
        return element.src;
        
    }else if (element.tagName == 'IFRAME') {


        var obj = element.contentWindow.document.elementFromPoint(x, y);
        
        if (obj.tagName == 'IMG' && obj.src) {
            
            return obj.src;
            
        }
        
    }
    
    return null;
    
}

