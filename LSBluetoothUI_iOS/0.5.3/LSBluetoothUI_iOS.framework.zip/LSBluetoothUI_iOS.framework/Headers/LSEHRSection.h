//
//  LSEHRSection.h
//  LSWearable
//
//  Created by lifesense－mac on 17/4/5.
//  Copyright © 2017年 lifesense. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LSEHRSection : NSObject

/**
 最小
 */
@property (nonatomic, assign) NSUInteger min;

/**
 最大
 */
@property (nonatomic, assign) NSUInteger max;

@end
