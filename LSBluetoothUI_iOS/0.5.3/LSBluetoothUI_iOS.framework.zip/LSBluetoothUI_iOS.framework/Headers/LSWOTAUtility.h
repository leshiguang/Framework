//
//  LSWOTAUtility.h
//  LSWearable
//
//  Created by ZhangWenzheng on 16/5/12.
//  Copyright © 2016年 lifesense. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LSDeviceManager+Bind.h"
#import "LSDeviceManager+OTA.h"

extern NSString *const kLSWOTADataSoftwareVersionKey ;
extern NSString *const kLSWOTADataDescribeKey ;
extern NSString *const kLSWOTADataDescribeStringSeparator;
extern NSString *const kLSWOTADataFileUrlkey;

/**
 *  升级设备条件检查结果
 */
typedef NS_ENUM(NSUInteger, LSWUpgradeDeviceConditionResult) {
    /**
     *  条件检查成功
     */
    LSWUpgradeDeviceConditionResultSuccess = 1,
    /**
     *  网络错误
     */
    LSWUpgradeDeviceConditionResultNetworkNoAvailableError,
    /**
     *  蓝牙未打开
     */
    LSWUpgradeDeviceConditionResultBluetoothNotOpenError,
    /**
     *  设备未连接
     */
    LSWUpgradeDeviceConditionResultDeviceDisconnectedError,
};

@interface LSWOTAUtility : NSObject
+ (void)canUpgradeDevice:(LSDevice *)deviceInfo completion:(void (^)(LSWUpgradeDeviceConditionResult result))completion;
+ (BOOL)isDeviceMamboButNotMamboPlusAndFirmwareLowerThanA045:(LSDevice *)deviceInfo;
+ (BOOL)isDeviceMamboPlus:(LSDevice *)deviceInfo;
+ (BOOL)isDeviceOTAMamboPlusFamily:(LSDevice *)deviceInfo;

+ (BOOL)isDeviceMamboButNotMamboPlus:(LSDevice *)deviceInfo;

+ (void)ignoreFirtPageDeviceUpdateWithDeviceId:(NSString *)deviceId sofewareVersion:(NSString *)sofewareVersion;
+ (BOOL)isIgnoredFirtPageDeviceUpdateWithDeviceId:(NSString *)deviceId sofewareVersion:(NSString *)sofewareVersion;

+ (void)storeOTADataDict:(NSDictionary *)otaDataDict forDeviceId:(NSString *)deviceId sofewareVersionBeforeUpdate:(NSString *)sofewareVersionBeforeUpdate;
+ (NSDictionary *)OTADataDictForDeviceIdDeviceId:(NSString *)deviceId sofewareVersionBeforeUpdate:(NSString *)sofewareVersionBeforeUpdate;
+ (void)clearOTADataDictForDeviceIdDeviceId:(NSString *)deviceId sofewareVersionBeforeUpdate:(NSString *)sofewareVersionBeforeUpdate;

@end
