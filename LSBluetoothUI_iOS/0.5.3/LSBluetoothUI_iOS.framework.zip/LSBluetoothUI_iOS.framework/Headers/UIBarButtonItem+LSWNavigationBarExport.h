//
//  UIBarButtonItem+LSWNavigationBarExport.h
//  LSWearable
//
//  Created by Wenzheng Zhang on 2017/3/23.
//  Copyright © 2017年 lifesense. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LSWJSContextExportObjects.h"
#import "LSWCustomBarButtonView.h"
@class LSWNavigationBarButtonCfgV2;
typedef void(^LSWNavigationBarButtonCompletion)(LSWNavigationBarButtonCfgV2 *buttonConfig);

@interface LSWNavigationBarButtonCfgV2 : NSObject
@property (nonatomic, strong) NSString *buttonId;
@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) NSString *imageUrl;
@property (nonatomic, strong) NSString *callbackHandlerName;
@property (nonatomic, strong) LSWNavigationBarButtonCompletion completion;
- (instancetype)initWithDict:(NSDictionary *)dict completion:(LSWNavigationBarButtonCompletion )completion;
@end

@interface UIBarButtonItem (LSWNavigationBarExport)
+ (instancetype)LSWNBE_barButtonItemWithButtonCfg:(LSWNavigationBarButtonCfg *)buttonCfg target:(id)target action:(SEL)action;
+ (instancetype)LSWNBE_barButtonItemWithButtonCfgV2:(LSWNavigationBarButtonCfgV2 *)buttonCfg;

+ (LSWCustomBarButtonViewItem *)LSWNBE_BarButtonViewItemWithButtonCfgV2:(LSWNavigationBarButtonCfgV2 *)buttonCfg;

- (LSWNavigationBarButtonCfg *)LSWNBE_associatedButtonCfg;
@end
