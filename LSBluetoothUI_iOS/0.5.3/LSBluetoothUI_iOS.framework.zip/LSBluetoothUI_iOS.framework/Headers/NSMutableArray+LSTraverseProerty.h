//
//  NSMutableArray+LSTraverseProerty.h
//  LS_Doctor_Primany_UI
//
//  Created by Dylan on 15/12/10.
//  Copyright © 2015年 cweihan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSMutableArray (LSTraverseProerty)
+(NSArray *)getAllProperty:(Class)className;
@end
