////
////  LSWJSContextExportObjects.h
////  LSWearable
////
////  Created by Wenzheng Zhang on 2017/3/22.
////  Copyright © 2017年 lifesense. All rights reserved.
////
//
//#import <Foundation/Foundation.h>
//#import <JavaScriptCore/JavaScriptCore.h>
//
#pragma mark - LSWNavigationBarButtonCfg
@interface LSWNavigationBarButtonCfg : NSObject

/**
 按钮标题
 */
@property (nonatomic, strong) NSString *title;

/**
 按钮图标地址，imageUrl存在的情况下，buttonTitle无效
 */
@property (nonatomic, strong) NSString *imageUrl;

/**
 按钮唯一Id
 */
@property (nonatomic, strong) NSString *buttonId;

/**
 回调的函数名，接收单个参数，参数值为发起callback的button的buttonId
 */
@property (nonatomic, strong) NSString *callbackFunctionName;
@end

#pragma mark - LSWNavigationBarMenuItemCfg
@interface LSWNavigationBarMenuItemCfg : NSObject

/**
 图片地址
 */
@property (nonatomic, strong) NSString *imageUrl;


/**
 title
 */
@property (nonatomic, strong) NSString *title;

- (instancetype)initWithDict:(NSDictionary *)dict;
@end
//
//#pragma mark - LSWNavigationBarMenuCfg
//@interface LSWNavigationBarMenuCfg : NSObject
//
///**
// menuItem 数组
// */
//@property (nonatomic, strong) NSArray<LSWNavigationBarMenuItemCfg *> *itemCfgs;
//
//
///**
// 回调的函数名，接收单个参数，参数值为选中的menuItem索引，从0开始
// */
//@property (nonatomic, strong) NSString *callbackFunctionName;
//@end
//
//
@interface LSWBackButtonExportObject : NSObject

//@property (nonatomic, weak) id<LSWBackButtonExportObjectDelegate> delegate;

@property (nonatomic, strong) NSString *callback;

- (BOOL)shouldCallBack;

@end

