//
//  LSSettingUtil.h
//  LSDeviceManager
//
//  Created by tanjian on 2021/1/8.
//

#import <Foundation/Foundation.h>
#import <LZBluetooth/LZBluetooth.h>
#import "LSDevice.h"

NS_ASSUME_NONNULL_BEGIN

@interface LSSettingUtil : NSObject

/// 设备类型映射类名
/// @param type 设置类型
+ (NSString *)settingClassNameWithType:(LZDeviceSettingType)type;

/// 获取设置信息
/// @param type 设置类型
/// @param json 类型
/// @param device 设备
+ (id)settingDataWithType:(LZDeviceSettingType)type json:(NSString *)json device:(LSDevice *)device;


/// 存储设置信息
/// @param deviceId 设备id
/// @param settingData 设置信息
+ (void)saveSettingData:(id<LZDeviceSettingProtocol>)settingData
               deviceId:(NSString *)deviceId;


/// 删除事件提醒
/// @param data 消息事件
/// @param deviceId 设备id
+ (void)deleteEventReminder:(LZA5SettingEventRemindData *)data deviceId:(NSString *)deviceId;

/// 获取存储的设置信息
/// @param deviceId 设备id
/// @param settingType 设置类型
+ (id)settingDataWithDeviceId:(NSString *)deviceId
                  settingType:(LZDeviceSettingType)settingType;

+ (NSArray<NSNumber *> *)allScreenTypes;
+ (NSArray <NSNumber *> *)msgRemindTypes;

@end

NS_ASSUME_NONNULL_END
