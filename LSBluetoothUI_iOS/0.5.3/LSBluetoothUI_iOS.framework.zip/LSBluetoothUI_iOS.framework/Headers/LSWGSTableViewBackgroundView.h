//
//  LSWGSTableViewBackgroundView.h
//  LSWearable
//
//  Created by wenZheng Zhang on 16/3/1.
//  Copyright © 2016年 lifesense. All rights reserved.
//

#import <UIKit/UIKit.h>
@class LSWGSTableViewBackgroundView;

typedef NS_ENUM(NSUInteger, LSWGSTableViewBackgroundViewState) {
    LSWGSTableViewBackgroundViewStateLoding,
    LSWGSTableViewBackgroundViewStateFailed,
    LSWGSTableViewBackgroundViewStateNoData,
    LSWGSTableViewBackgroundViewStateFinished
};

@protocol LSWGSTableViewBackgroundViewDelegate <NSObject>
@optional
- (void)gsBackgroundViewDidTriggerReload:(LSWGSTableViewBackgroundView *)gsBackgroundView;
- (void)gsBackgroundViewDidTappedBackground:(LSWGSTableViewBackgroundView *)gsBackgroundView;
@end

@interface LSWGSTableViewBackgroundView : UIView
@property (nonatomic, assign) UIEdgeInsets edgeInsets;
@property (nonatomic, weak) id <LSWGSTableViewBackgroundViewDelegate> delegate;

- (void)showMessage:(NSString *)message withState:(LSWGSTableViewBackgroundViewState)state;
- (void)setIconImageForNoDataView:(UIImage *)image;
@end
