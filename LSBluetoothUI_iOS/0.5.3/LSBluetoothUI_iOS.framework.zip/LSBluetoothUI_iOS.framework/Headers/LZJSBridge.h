//
//  LZJSBridge.h
//  LSBluetoothUI_iOS
//
//  Created by tanjian on 2021/5/12.
//  这个对象是为了缓存外部注册的jsbridge的方法

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef void (^LSJBResponseCallback)(id responseData);
typedef void (^LSJBHandler)(id data, LSJBResponseCallback responseCallback);

@interface LZJSBridge : NSObject

+ (instancetype)sharedInstance;

/// 获取注册的操作
/// @param handlerName 名称
- (LSJBHandler _Nullable)handlerWithName:(NSString *)handlerName;


/// 注册jsbridge 操作
/// @param handlerName 操作名称
/// @param handler 操作
- (void)registerHandler:(NSString *)handlerName handler:(LSJBHandler)handler;

@end

NS_ASSUME_NONNULL_END
