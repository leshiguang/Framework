//
//  LSWMamboA045HintViewController.h
//  LSWearable
//
//  Created by ZhangWenzheng on 16/5/12.
//  Copyright © 2016年 lifesense. All rights reserved.
//

#import "LSWBaseViewController.h"

#import "LSDeviceManager+Bind.h"
#import <UIKit/UIKit.h>

@class LSWMamboA045HintViewController;
@protocol LSWMamboA045HintViewControllerDelegate <NSObject>
@optional

- (void)a045ControllerDidProceedToUpgrade:(LSWMamboA045HintViewController *)a045Controller;
- (void)a045ControllerCancleUpgrade:(LSWMamboA045HintViewController *)a045Controller;

@end

@interface LSWMamboA045HintViewController : LSWBaseViewController
+ (UINavigationController *)wrappInUINavigationControllerWithDelegate:(id <LSWMamboA045HintViewControllerDelegate>)delegate deviceInfo:(LSDevice *)deviceInfo;

@property (nonatomic, strong) LSDevice *deviceInfo;
@property (nonatomic, weak) id <LSWMamboA045HintViewControllerDelegate> delegate;
@end
