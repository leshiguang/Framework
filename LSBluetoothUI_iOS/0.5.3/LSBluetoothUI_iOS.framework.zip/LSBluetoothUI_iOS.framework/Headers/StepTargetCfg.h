//
//  StepTargetCfg.h
//  LSBluetooth-Library
//
//  Created by Dylan on 16/1/19.
//  Copyright © 2016年 Lifesense. All rights reserved.
//  步数目标模型

#import <Foundation/Foundation.h>

@interface StepTargetCfg : NSObject

/// 步数
@property(nonatomic,assign)int step;

@end
