//
//  WiFiCfg.h
//  设备
//
//  Created by Dylan on 16/1/29.
//  Copyright © 2016年 Lifesense. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WiFiCfg : NSObject
@property (nonatomic, copy) NSString *ssid;

@end
