//
//  DateUtilities.h
//  LSPedometer
//
//  Created by Qinmei on 14-7-24.
//  Copyright (c) 2014年 LS. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NSDate+LSFoundationAdditions.h"
#import <UIKit/UIKit.h>


typedef NS_ENUM(NSInteger, LSDateUtilitiesFormatType) {
    /**
     *  12/11
     */
    LSDateUtilitiesFormatTypeLine,
    /**
     *  12月11日
     */
    LSDateUtilitiesFormatTypeWord,
    /**
     *  xx月xx日
     */
    LSDateUtilitiesFormatTypeWordKeepTwo
};
@interface LSDateUtilities : NSObject

/**
 *  返回时间UTC，秒为单位
 *
 *  @param date 日期
 *
 *  @return NSTimeInterval
 */
+ (NSTimeInterval)utcWithDate:(NSDate *)date;

/**
 返回小时和分钟

 @param date 日期

 @return 小时和分钟 11:20
 */
+(NSString *)hourAndMinuteWithDate:(NSDate *)date;

//返回毫秒
+(NSNumber *)longUTCWithDate:(NSString *)dateString;

+(NSString *)dateWithUTC:(NSNumber *)utc;
/**
 *  返回时间UTC日期，日期
 *
 *  @param utc utc时间秒为单位
 *
 *  @return NSDate
 */
+(NSDate *)dateWithUtc:(NSTimeInterval )utc;


/**
 *  返回时间差值，秒为单位
 *
 *  @param dateString1 格式yyyy-MM-dd HH:mm:ss
 *  @param dateString2 格式yyyy-MM-dd HH:mm:ss
 *
 *  @return NSTimeInterval
 */
+(NSTimeInterval)timeintervalFromLastDate: (NSString *) dateString1  toTheDate:(NSString *) dateString2;

/**
 *  返回时间差，字符串
 *  HH:mm:ss
 *
 *  @param dateString1 格式yyyy-MM-dd HH:mm:ss
 *  @param dateString2 格式yyyy-MM-dd HH:mm:ss
 *
 *  @return HH:mm:ss
 */
+ (NSString *)intervalFromLastDate: (NSString *) dateString1  toTheDate:(NSString *) dateString2;

/**
 *  返回BOOL
 *  @param date 格式yyyy-MM-dd HH:mm:ss
 *  @param thisWeekDate 格式NSDate
 *  @return 判断date是否在thisWeekDate这一周里
 */
+(BOOL)isThisWeek:(NSString *)date withDate:(NSDate *)thisWeekDate;


+(BOOL)isThisWeekWithDate:(NSDate *)date withDate:(NSDate *)thisWeekDate;


/**
 *  返回BOOL
 *
 *  @param date 格式yyyy-MM-dd HH:mm:ss
 *  @param thisMonthDate 格式NSDate
 *  @return 判断date是否在thisWeekDate这一月里
 */
+(BOOL)isThisMonth:(NSString *)date withDate:(NSDate *)thisMonthDate;


/**
 
 *  返回时
 *
 *  @param date date
 *
 *  @return hour
 */
+(int)hourWithDate:(NSString *)date;

+(int)minWithDate:(NSString *)date;
/**
 
 *  返回时间 小数
 *
 *  @param date date HH:mm
 *
 *  @return time  时间包含数据（小时数）
 */
+(float)timeWithDate:(NSString *)date;


//+(NSArray *)dateArrayWithDate:(NSString *)date;  

/**
 *  添加中文月日
 *
 *  @param date 2014-11-11 23:33:11
 *
 *  @return 11/11
 */
//+ (NSString *)dateWithLineMonthDay:(NSString *)date;

/**
 *  添加中文月日
 *
 *  @param date 2014-11-11 23:33:11
 *
 *  @return 2014/11/11
 */
+ (NSString *)dateWithLineYearMonthDay:(NSString *)date;
/**
 *  添加中文月日
 *
 *  @param date 2014-11-11 23:33:11
 *
 *  @return 11月11日
 */
+ (NSString *)dateWithZnMonthDay:(NSString *)date;

/**
 *  添加中文月日
 *
 *  @param date 2014-11-11 23:33:11
 *
 *  @return 2014年11月11日
 */
+ (NSString *)dateWithZnYearMonthDay:(NSString *)date;

/**
 *  输入一个日期，返回这一个月的第一天
 *
 *  @param date 日期
 *
 *  @return 一个月的第一天
 */
+(NSString *)firstDateOfMonthStringWithDate:(NSString *)date;

/**
 *  输入一个日期，返回这一个月的最后一天
 *
 *  @param date 日期
 *
 *  @return 一个月的最后一天
 */
+(NSString *)lastDateOfMonthStringWithDate:(NSString *)date;

/**
 *  输入一个日期，返回这一星期的星期一
 *
 *  @param date 日期
 *
 *  @return 星期一的日期
 */
+(NSString *)mondayStringWithDate:(NSString *)date;

/**
 *  输入一个日期，返回这一星期的星期一
 *
 *  @param date 日期
 *
 *  @return 星期一的日期
 */
+(NSDate *)mondayWithDate:(NSString *)date;

/**
 *  输入一个日期，返回这一星期的星期日
 *
 *  @param date 日期
 *
 *  @return 星期日的日期
 */
+(NSString *)sundayStringWithDate:(NSString *)date;
+(NSDate *)sundayWithDate:(NSString *)date;
/**
 *  输入一个日期，返回00点
 *
 *  @param date 日期
 *
 *  @return 最早一刻
 */
+ (NSString *)firstTimeWithDate:(NSString *)date;

/**
 *  输入一个日期，返回小时第一刻
 *
 *  @param date 日期
 *
 *  @return 小时最早一刻
 */
//+ (NSString *)firstHourTimeWithDate:(NSString *)date;

/**
 *  输入一个日期
 *
 *  @param date 日期
 *
 *  @return 最晚一刻
 */
+ (NSString *)lastTimeWithDate:(NSString *)date;

+ (NSString *)stringWithDate:(NSDate *)date;

/**
 *  返回本周，上周， 或 2014-11-21 至 2014-11-28 (05月01日-05月07日)
 *
 *  @param date 日期
 *
 *  @return 如题
 */
+ (NSString *)weekFormatChineseNameCompareToday:(NSDate *)date;

/**
 *  Weekday according to the date
 *  7:周日、1:周一、2:周二
 *
 *  @param theDate the date
 *
 *  @return weekday
 */
+(NSInteger)weekdayWithNSDate:(NSDate *)theDate isMondayFirst:(BOOL)isMondayFirst;

/**
 *  Days according date in database
 *
 *  @param date measurementDate
 *
 *  @return days
 */
+(int)daysWithDate:(NSString *)date;


/**
 *  将NSTimeInterval转换成时分秒的格式
 *
 *  @param timeInterval timeInterval
 *
 *  @return HH:mm:ss
 */
+(NSString *)timeStringWithTimeInterval:(NSTimeInterval)timeInterval;




//返回当前时区
+ (int)systemTimeZone;

/**
 *  获取当前时区的日期
 *
 *  @param date date description
 *
 *  @return NSDate
 */
+(NSDate *)currentTimeZoneDate:(NSDate *)date;


+(int)ageWithBirthday:(NSString *)birthday;

/**
 *  返回时长的时和分
 *
 *  @param minTime  时长
 *
 *  @return @"12时32分"
 */
+ (NSString *)timeToHourAndMin:(float)minTime;


//返回富文本...
//+ (NSMutableAttributedString *)attributedTimeToHourAndMin:(float)minTime numberFont:(UIFont *)numberFont numberColor:(UIColor *)numberColor unitFont:(UIFont *)unitFont unitColor:(UIColor *)unitColor hideZeroHour:(BOOL)hideZeroHour;


/**
 *  判断是否在时间区域内
 *
 *
 *  @return YES　or NO
 */
+(BOOL)isDate:(NSString *)date betweenDate:(NSString *)fromDate withDate:(NSString *)toDate;


+(BOOL)isDate:(NSString *)date before:(NSString *)toDate;


+(BOOL)isSameDate:(NSString *)date as:(NSString *)toDate;


/**
 求两日期是否同一年
 
 @param date 日期1
 @param aDate 日期2
 @return 是否同年
 */
+(BOOL)isSameYear:(NSDate *)date as:(NSDate *)aDate;

/// 求两天的时间差
/// @param day1 格式 yyyy-MM-dd HH:mm:ss
/// @param day2 格式 yyyy-MM-dd HH:mm:ss
+ (int)dayIntervalSinceDate:(NSString *)day1 fromDate:(NSString *)day2;

/**
 *  将时间转换成“23h59m”格式
 *
 *  @param minTime 时长，单位：分钟
 *
 *  @return 返回“23h59m”
 */
+ (NSString *)timeStrToHourAndMin:(float)minTime;

+ (NSString *)stringWithData:(NSData *)data;

+ (NSData *)dataWithString:(NSString *)sendString;

/**
 *  校验日期格式是否是 yyyy-MM-dd HH:mm:ss
 *
 *  @param date 日期时间
 *
 *  @return 布尔值
 */
+(BOOL)validDateTimeFormat:(NSString *)date;

/**
 *  返回某天距离今天的周数 周一是星期的第一天
 *
 *  @param date 某天
 *
 *  @return 周数
 */
+(int)weekCountFrom:(NSDate *)date;

+(int)dayCountFrom:(NSDate *)date;

+ (int)weekDayOfDate:(NSDate *)date;




/**
 *  判断数据的时间是否有效([2013,Now])
 *
 *  @param date 时间
 *
 *  @return YES有效
 */
+ (BOOL)isDateValid:(NSString *)date ;

/**
 *  判断数据的时间是否有效([2013,Now])
 *
 *  @param utc utc时间戳
 *
 *  @return YES有效
 */
+ (BOOL)isUTCValid:(long long)utc;

///**
// *  获取两个date之间时间差的描述语
// *
// *  @param fromDate fromDate
// *  @param toDate   toDate
// *
// *  @return 描述语
// */
//+ (NSString *)timeDescriptionTextFromDate:(NSDate *)fromDate toDate:(NSDate *)toDate;

/**
 *  输入秒返回分'秒“
 *
 *  @param second 秒
 *
 *  @return 配速
 */
+ (NSString *)speedWithSecond:(int)second;

+ (int)hourWithNSDate:(NSDate *)date;


/**
 返回时：分：秒

 @param second 秒
 @return 时：分：秒
 */
+ (NSString *)hourMinSecondWithSecond:(int)second;
/**
 返回5点为界限的日期

 @param date 日期
 @return 用于今夜安睡
 */
+ (NSDate *)getDateIsAfterFiveByDate:(NSDate *)date;
@end
