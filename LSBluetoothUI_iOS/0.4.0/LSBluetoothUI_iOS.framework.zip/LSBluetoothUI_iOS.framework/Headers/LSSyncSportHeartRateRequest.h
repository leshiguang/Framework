//
//  LSSyncSportHeartRate.h
//  LSDeviceManagerTests
//
//  Created by wm on 2020/9/17.
//  Copyright © 2020 Wenzheng Zhang. All rights reserved.
//

#import "LSBaseRequest.h"
#import "HeartRateData.h"

NS_ASSUME_NONNULL_BEGIN

@interface LSSyncSportHeartRateRequest : LSBaseRequest

- (void)setRequestParameters:(NSArray<HeartRateData *> *)SportHeartRateDataAry;

@end

NS_ASSUME_NONNULL_END
