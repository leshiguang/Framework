//
//  LZDownConfigJsonRequest.h
//  Pods
//
//  Created by wm on 2020/12/18.
//

#import "LSBaseRequest.h"

NS_ASSUME_NONNULL_BEGIN

@interface LZDownConfigJsonRequest : LSBaseRequest

@end

NS_ASSUME_NONNULL_END
