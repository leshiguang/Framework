//
//  lzReceiveDataSqliteModel.h
//  LSDeviceManagerTests
//
//  Created by wm on 2020/10/19.
//  Copyright © 2020 Wenzheng Zhang. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface lzReceiveDataSqliteModel : NSObject

@property (nonatomic, strong) NSString *dataId;

@property (nonatomic, strong) NSString *userId;

@property (nonatomic, strong) NSString *data;

/// 同步状态 0未同步，1已同步
@property (nonatomic, assign) NSInteger sync;

/// 参考 LSMeasurementDataType
@property (nonatomic, assign) NSInteger dataType;

@end

NS_ASSUME_NONNULL_END
