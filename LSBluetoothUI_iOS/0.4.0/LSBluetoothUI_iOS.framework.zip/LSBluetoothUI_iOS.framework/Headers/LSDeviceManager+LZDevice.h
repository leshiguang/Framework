//
//  LSDeviceManager+LZDevice.h
//  LSDeviceManager
//
//  Created by tanjian on 2020/12/24.
//

#import "LSDeviceManager.h"

NS_ASSUME_NONNULL_BEGIN


@interface LSDeviceManager (LZDevice)

@end

NS_ASSUME_NONNULL_END
