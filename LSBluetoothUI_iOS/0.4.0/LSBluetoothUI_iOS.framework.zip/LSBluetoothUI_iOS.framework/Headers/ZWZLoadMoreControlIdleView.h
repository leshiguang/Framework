//
//  ZWZLoadMoreControlIdleView.h
//  LSWearable
//
//  Created by ZhangWenzheng on 16/3/22.
//  Copyright © 2016年 lifesense. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZWZLoadMoreControlIdleView : UIView

@end
