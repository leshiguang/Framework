//
//  ZWZLoadMoreControlFailedView.h
//  ZWZLoadMoreControlDemo
//
//  Created by wenZheng Zhang on 16/1/5.
//  Copyright © 2016年 ZWZ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZWZLoadMoreControlFailedViewProtocol.h"
#import "ZWZLoadMoreControlFailedViewDelegate.h"
@interface ZWZLoadMoreControlFailedView : UIView <ZWZLoadMoreControlFailedViewProtocol>
@property (nonatomic, weak) id <ZWZLoadMoreControlFailedViewDelegate> delegate;
@end
