//
//  LSWDataSourcePageLoading.h
//  LSWearable
//
//  Created by ZhangWenzheng on 16/8/18.
//  Copyright © 2016年 lifesense. All rights reserved.
//

#import <Foundation/Foundation.h>
/*!
 *  分页加载的protocol
 */
@protocol LSWDataSourcePageLoading <NSObject>
@required
- (void)loadDataWithPage:(id)page completion:(void (^)(id page))completion;
@end
