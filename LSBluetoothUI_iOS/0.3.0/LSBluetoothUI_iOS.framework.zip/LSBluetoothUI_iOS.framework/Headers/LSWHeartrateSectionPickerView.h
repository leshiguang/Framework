//
//  LSWHeartrateSectionPickerView.h
//  LSWearable
//
//  Created by Wenzheng Zhang on 2017/11/2.
//  Copyright © 2017年 lifesense. All rights reserved.
//

#import "LSWFullScreenHUDBackgroundView.h"

@class LSWHeartrateSectionPickerView;

typedef void(^LLSWHeartrateSectionPickerViewDidSelectValueBlock)(NSInteger minHeartrate, NSInteger maxHeartrate);


/**
 心率区间选择器
 */
@interface LSWHeartrateSectionPickerView : LSWFullScreenHUDBackgroundView


/**
 回调一次即被清除，请在使用前重新设置一次
 */
@property (nonatomic, strong) LLSWHeartrateSectionPickerViewDidSelectValueBlock didSelectValueBlock;

/**
 心率区间上下限最小心率值
 */
@property (nonatomic, assign, readonly) NSInteger minHeartrate;

/**
 心率区间上下限最大心率值
 */
@property (nonatomic, assign, readonly) NSInteger maxHeartrate;

/**
 设置心率区间上下限最大，最小心率值
 
 @param minHeight 最小心率
 @param maxHeight 最大心率
 */
- (void)setMinHeartrate:(NSInteger)minHeartrate maxHeartrate:(NSInteger)maxHeartrate;


/**
 设置选择器title和选中值，目前有小bug，需要先show再设置选中值


 @param title title
 @param selectedMinHeartrate 选中的心率区间下限
 @param selectedMaxHeartrate 选中的心率区间上限
 */
- (void)setUpWithTitle:(NSString *)title selectedMinHeartrate:(NSInteger)selectedMinHeartrate selectedMaxHeartrate:(NSInteger)selectedMaxHeartrate;

@end
