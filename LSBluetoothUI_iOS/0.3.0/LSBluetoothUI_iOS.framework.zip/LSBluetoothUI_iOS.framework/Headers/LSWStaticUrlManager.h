//
//  LSWStaticUrlManager.h
//  LSWearable
//
//  Created by ZhangWenzheng on 16/3/14.
//  Copyright © 2016年 lifesense. All rights reserved.
//


#import <Foundation/Foundation.h>


@interface LSWStaticUrlManager : NSObject

+ (instancetype)shareInstance;

/// 体重页
- (NSString *)weightPageUrlStr;

/// 血压页
- (NSString *)bloodpressurePageUrlStr;

/// 心率
- (NSString *)heartRatePageUrlStr;

/// 有氧能力
- (NSString *)aerobicPageUrlStr;

/// 睡眠
- (NSString *)sleepPageUrlStr;

/// 步数
- (NSString *)stepDetailPageUrlStr;

/// H5页面加载兜底页
- (NSURL *)emptyPageUrl;


/// H5页面调试状态，默认关闭
- (void)openVConsole;

@end
