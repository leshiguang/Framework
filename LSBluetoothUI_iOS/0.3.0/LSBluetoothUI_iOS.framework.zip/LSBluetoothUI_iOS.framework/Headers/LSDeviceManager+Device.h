//
//  LSDeviceManager+Device.h
//  LSDeviceManager
//
//  Created by tanjian on 2020/12/23.
//

#import "LSDeviceManager.h"

NS_ASSUME_NONNULL_BEGIN

@class LSDeviceUser;
@class LSEManufacturerInfo;
@class LSDevice;

typedef void(^LSEManufacturerInfoBlock)(LSEManufacturerInfo * _Nullable manufacturerInfo, NSInteger code, NSString *msg );

@interface LSDeviceManager (Device)

/// 获取厂商信息
/// @param manufacturerId 厂商id
/// @param completion 回调
- (void)getManufacturerInformationForManufacturerId:(NSString *)manufacturerId completion:(LSEManufacturerInfoBlock)completion;

/// 根据二维码获取设备信息
/// @param qrcode 二维码信息
/// @param completion 回调
- (void)getDeviceInfo:(NSString *)qrcode Completion:(void(^)(int code,NSString *msg,Device *deviceInfo))completion;

/// 通过sn获取设备信息
/// @param sn sn
/// @param completion 回调
- (void)getDeviceInfoWithSN:(NSString *)sn Completion:(void (^)(int, NSString *, Device *))completion;


/// 设置活跃设备
/// @param deviceId 设备id
/// @param completion 回调
- (void)setActiveDevice:(NSString *)deviceId completion:(void(^)(int code, NSString *msg))completion;

/// 获取指定设备的所有绑定关系
/// @param deviceId 设备id
/// @param completion 回调
- (void)getDeviceUsersWithDeviceId:(NSString *)deviceId  Completion:(void(^)(int code,NSString *msg,NSArray <LSDeviceUser *>*deviceList))completion;


- (void)getHistoryDevices:(NSString *)userId Completion:(void(^)(int code,NSString *msg,NSArray <LSDevice *>*deviceList))completion;


- (void)unBindingDevice:(NSString *)deviceId userId:(NSString *)userId Completion:(void(^)(int code,NSString *msg))completion;




/// 从服务端更新数据
- (void)refreshDevices;



/// 获取设备信息
/// @param deviceId 设备id
- (LSDevice *)getDeviceInfo:(NSString *)deviceId;

/// 获取所有的已绑定的设备
/// @param userId 用户id
//- (NSArray <Device *> *)getBoundDevices:(NSString *)userId;

/// 获取电量
- (void)readBatteryWithDeviceId:(NSString *)deviceId;

- (void)dealActiveDeviceData:(NSArray *)data;



/// 判断是否活跃设备有发生改变
- (void)resetActiveDevice;


@end

NS_ASSUME_NONNULL_END
