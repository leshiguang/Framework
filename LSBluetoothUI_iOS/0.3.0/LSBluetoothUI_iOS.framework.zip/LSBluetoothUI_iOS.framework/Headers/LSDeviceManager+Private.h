//
//  LSDeviceManager+Private.h
//  LSDeviceManager
//
//  Created by tanjian on 2020/12/25.
//

#import "LSDeviceManager.h"
#import <LZBluetooth/LZBluetooth.h>
#import "LSLocalDataHelperHeader.h"
#import "HFSmartLink.h"

NS_ASSUME_NONNULL_BEGIN

typedef void(^CallBackBlock)(AirKissCode code, LSEWifiConfigType type, NSUInteger time);

@interface LSDeviceManager ()

@property (nonatomic, strong) dispatch_queue_t isolationQueue;

@property (nonatomic, strong) id<LZDeviceManagerProtocol> lzDeviceManager;

@property (nonatomic, strong) NSMutableDictionary <NSString *, LSDevice *> *devices;
@property (nonatomic, strong) NSArray<NSNumber *> * wifiConfigOrders;
@property (nonatomic, strong) NSTimer* configWifiTimer;
@property (nonatomic, assign) NSUInteger configWifiTime;
@property (nonatomic, assign) LSEWifiConfigType wifiConfigType;
@property (nonatomic, assign) AirKissCode airCode;
@property (nonatomic, assign) NSUInteger startWifiTime;
@property (nonatomic, strong) HFSmartLink *smtlk;
@property (nonatomic, strong) NSMutableDictionary *wifiDic;
@property (nonatomic, copy) CallBackBlock callBack;

@property (nonatomic, assign) int bindState;

@property (nonatomic, strong) LSLocalDataHelper *localDataHelper;

@end

@interface LSDeviceManager (Private)

- (void)runBlockInIsolationQueue:(dispatch_block_t)block;

- (void)runMainBlock:(dispatch_block_t)block;

- (void)saveDataBase;

- (nullable LSDevice *)getLSDeviceWithBlueDevice:(id<LZDeviceProtocol>)device;
- (nullable LSDevice *)getLSDeviceWithDevice:(Device *)device;

@end

NS_ASSUME_NONNULL_END
