//
//  LSWFullScreenHUDBackgroundView.h
//  LSWearable
//
//  Created by wenZheng Zhang on 16/1/21.
//  Copyright © 2016年 lifesense. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSUInteger, LSWFullScreenHUDBackgroundViewBlurStyle) {
    LSWFullScreenHUDBackgroundViewBlurStyleDark,
    LSWFullScreenHUDBackgroundViewBlurStyleLight,
};

@interface LSWFullScreenHUDBackgroundView : UIView

@property (nonatomic, assign, readonly) LSWFullScreenHUDBackgroundViewBlurStyle blurStyle;
@property (nonatomic, strong, readonly) UIView *contentView;
@property (nonatomic, strong, readonly) UIButton *backgroundCancleButton;
@property (nonatomic, assign, getter=isShowing, readonly) BOOL showing;

/*!
 *  是否对contentView加入alpha渐变动画，默认为YES
 */
@property (nonatomic, assign) BOOL animateContentView;

- (void)showInView:(UIView *)view animated:(BOOL)animated;
- (void)hideAnimated:(BOOL)animated;

- (instancetype)initWithBlurStyle:(LSWFullScreenHUDBackgroundViewBlurStyle)blurStyle;
@end
