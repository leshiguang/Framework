//
//  UIView+Screenshot.h
//  Video Blurring
//
//  Created by xcalloc on 4/8/14.
//  Copyright (c) 2014 Mike Jaoudi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (Screenshot)

- (UIImage *)convertViewToImage;

- (UIImage *)ls_screenshots;

- (UIImage *)ls_screenshotsWithRect:(CGRect)rect;

- (UIImage *)ls_nomalSnapshotImage;

@end
