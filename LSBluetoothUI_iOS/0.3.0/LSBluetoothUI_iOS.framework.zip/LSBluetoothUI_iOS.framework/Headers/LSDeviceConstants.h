//
//  LSDeviceConstants.h
//  AFNetworking
//
//  Created by malai on 2018/9/19.
//

#import <Foundation/Foundation.h>
#import "Device+CoreDataProperties.h"

typedef NS_ENUM(NSUInteger, LSDeviceModel) {
    /// 未知
    LSDeviceModelUnknow,
    
#pragma mark - 手环
        /// Bonbon
    LSDeviceModelBraceletBonbon,
    
        /// BonbonC
    LSDeviceModelBraceletBonbonC,
    
        /// Mambo 只含步数
    LSDeviceModelBraceletMambo,
    
        /// Mambo 来电版，含步数，来电提醒，闹钟提醒
    LSDeviceModelBraceletMamboWithCallRemind,
    
        /// Mambo HR，含步数，来电提醒，闹钟提醒，心率
    LSDeviceModelBraceletMamboHR,
    
        /// Mambo Plus，含步数，来电提醒，闹钟提醒，心率，跑步模式
    LSDeviceModelBraceletMamboPlus,
    
        /// Mambo Plus，含步数，来电提醒，闹钟提醒，心率，跑步模式，血氧
    LSDeviceModelBraceletMamboPlusWithBloodO2,
    
        /// MamboGold，MamboMT，含步数，来电提醒，闹钟提醒，心率，扩展设置选项
    LSDeviceModelBraceletMamboGold,
    LSDeviceModelBraceletMamboMT,
    
        /// ziva plus
    LSDeviceModelBraceletMid,
    
        /// LSWDeviceTypeBraceletDD，含步数，来电提醒，闹钟提醒，扩展设置选项
    LSDeviceModelBraceletDD,
    
    /*!
     *   1. 扫码或输入SN绑定设备，不支持蓝牙搜索绑定；
     *   2. 计步、睡眠监测，不支持心率监测；
     *   3. 来电提醒、闹钟提醒、久坐提醒、活动目标完成提醒（距离、步数、消耗）；
     *   4. OTA 中途失败后可继续使用，不会变砖；
     */
    LSDeviceModelBraceletEASY,
    
    /*!
     * 针对新品手环M3，APP需要新增功能包括：
     * 1. 展示并保持M3手环新增的运动类型的记录，包括：骑行/健身/瑜伽/篮球/足球/羽毛球/排球/乒乓球；
     * 2. 手环设置中，新增“运动项设置”，选择3种运动类型，并同步到手环，手环在屏幕上显示这3种运动的入口；
     
     * M3手环信息：
     * 名称：乐心手环M3
     * 工厂型号：LS428-B
     */
    LSDeviceModelBraceletM3,
    
    LSDeviceModelBraceletM5,
    
#pragma mark - Watch
        /// MIO手表
    LSDeviceModelWatchMIO,
    
    /**
     健康手表（附带ECG功能）
     */
    LSDeviceModelWatchHealth,
    
    
    /*!
     *  A3 (LCD)版，蓝牙
     */
    LSDeviceModelWeightScaleA3WithLCD,
    
    /*!
     *  A3，蓝牙
     */
    LSDeviceModelWeightScaleA3,
    
    /*!
     *  Q3，WIFI
     */
    LSDeviceModelWeightScaleQ3,
    
    /*!
     *  S3，WIFI
     */
    LSDeviceModelWeightScaleS3,
    
    /*!
     *  S1/S3，WIFI
     */
    LSDeviceModelWeightScaleS1S3,
    
    /*!
     *  S1，蓝牙
     */
    LSDeviceModelWeightScaleS1,
    
    /*!
     *  A4，蓝牙
     */
    LSDeviceModelWeightScaleA4WithBluetooth,
    
    /*!
     *  A4，WIFI
     */
    LSDeviceModelWeightScaleA4WithWIFI,
    
    /*!
     *  X1，蓝牙
     */
    LSDeviceModelWeightScaleX1,
    
#pragma mark - 体脂秤
    
        /// S7，WIFI
    LSDeviceModelFatScaleS7,
    
        /// S5，WIFI
    LSDeviceModelWeightScaleS5,
    
        /// Melody，蓝牙
    LSDeviceModelWeightScaleMelodyWithBluetooth,
    
        /// Melody， WIFI
    LSDeviceModelWeightScaleMelodyWithWIFI,
    
        /// A3-F，蓝压
    LSDeviceModelWeightScaleA3_F,
    
    LSDeviceModelWeightScaleLS202,
    
    LSDeviceModelWeightScaleLS206,
    
        /// S5 mini，蓝牙
    LSDeviceModelFatScaleNANA,
    
        /// 蓝牙
    LSDeviceModelFatScaleFIT,
    
    
    /// 支付宝 智能支付卡
    LSDeviceModelPayCard,
    
    /// 血压计
    LSDeviceModelBloodPressureLS805H,

};

/*
 设备支持的功能
 */
typedef NS_ENUM(NSUInteger, LSDeviceFunction) {
    /// 闹钟设置
    LSDeviceFunctionAlarm,
    
    /// 混合消息设置
    LSDeviceFunctionMixedMessageRemind,
    
    /// 分开的消息设置
    LSDeviceFunctionSplitedMessageRemind,
    
    /// 来电提醒
    LSDeviceFunctionCallRemind,
    
    /// 久坐提醒
    LSDeviceFunctionLongSitRemind,
    
    /// 夜间模式
    LSDeviceFunctionNightMode,
    
    /// 勿扰模式
    LSDeviceFunctionNoDisturbMode,
    
    /// 12 || 24 小时模式
    LSDeviceFunction1224Mode,
    
    /// 佩戴方式
    LSDeviceFunctionWearStateMode,
    
    /// 屏幕方向
    LSDeviceFunctionScreenDirection,
    
    /// 屏幕内容
    LSDeviceFunctionScreenContent,
    
    /// 表盘设置
    LSDeviceFunctionDialMode,
    
    /// 天气设置
    LSDeviceFunctionWeatherData,
    
    /// 活动目标
    LSDeviceFunctionActivityTarget,
    
    /// 心率测量模式
    LSDeviceFunctionHeartrateMode,
    
    /// 心率预警
    LSDeviceFunctionHeartrateAlarm,
    
    /// 运动项设置
    LSDeviceFunctionSportItem,
    
    /// ecg
    LSDeviceFunctionEcg,
    
    /// 散点图心率监控
    LSDeviceHMSplashes,
};

/**
 设备数据传输协议
 */
typedef NS_ENUM(NSUInteger, LSDeviceTransform) {
    /// 蓝牙
    LSDeviceTransformBle,
    /// wifi
    LSDeviceTransformWifi,
};

/// 蓝牙传输协议
typedef NS_ENUM(NSUInteger, LSDeviceBleProtocol) {
    /// 不支持蓝牙，这个是wifi秤的时候
    LSDeviceBleProtocolNotSupport,
    
    /// a5协议
    LSDeviceBleProtocolA5,
    
    /// 体重a6协议
    LSDeviceBleProtocolWeightA6,
    
    /// OAS协议
    LSDeviceBleProtocolOAS,
};

@interface LSDeviceConstants : NSObject

/**
 根据GTMOoffset转化成乐心手环 GTM对照表
 
 @param gtmOffset 单位秒
 @return GTM对照表上的值
 */
+ (uint32_t)timezoneWithGTMOffset:(NSInteger)gtmOffset;

/**
 设备型号枚举 这个是旧方法，是为了兼容有个设备 Mambo

 @param model 工厂型号
 @param salesModel 销售型号
 @param softwareVersion 版本
 @return 设备型号枚举
 */
+ (LSDeviceModel)deviceModelWithModel:(NSString *)model salesModel:(NSString *)salesModel softwareVersion:(NSString *)softwareVersion;


/**
 设备型号 新方法

 @param model 工厂型号
 @return 设备型号
 */
+ (LSDeviceModel)deviceModelWithModel:(NSString *)model;


/**
 设备功能

 @param deviceModel 设备型号
 @return 功能集合
 */
+ (NSSet <NSNumber *> *)functionsByDeviceModel:(LSDeviceModel)deviceModel;


/**
 设置功能

 @param deviceModel 设备型号
 @return 功能集合
 */
+ (NSSet <NSNumber *> *)settingFunctionsByDeviceModel:(LSDeviceModel)deviceModel;


/**
 是否支持某项功能

 @param deviceModel 设备型号
 @param function 功能
 @return 是否支持
 */
+ (BOOL)deviceModel:(LSDeviceModel)deviceModel shouldSupportFunction:(LSDeviceFunction)function;

@end

@interface Device(Fuction)
    
/// 设备型号
- (LSDeviceModel)ls_deviceModel;
    
/// 设备传输
- (LSDeviceTransform)ls_deviceTransform ;
    
/// 设备蓝牙协议
- (LSDeviceBleProtocol)ls_deviceBleProtocol;
    
/// 设备的支持的功能
- (NSSet *)ls_deviceFunctions;

/// 设备的设置页面功能
- (NSSet *)ls_deviceSettingFuctions;
    
/// 设备是否支持某项功能
- (BOOL)ls_supportFunction:(LSDeviceFunction)function;

@end

