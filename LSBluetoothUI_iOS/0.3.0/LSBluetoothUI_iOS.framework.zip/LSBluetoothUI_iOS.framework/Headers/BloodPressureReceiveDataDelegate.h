//
//  BloodRreasureReceiveDataDelegate.h
//  LSDeviceManagerTests
//
//  Created by wm on 2020/9/17.
//  Copyright © 2020 Wenzheng Zhang. All rights reserved.
//

#import <Foundation/Foundation.h>

#ifdef LZBluetoothWithA5
#import <LZBluetooth/LZA6BpMeasurementData.h>
#endif

NS_ASSUME_NONNULL_BEGIN

@protocol BloodPressureReceiveDataDelegate <NSObject>

#ifdef LZBluetoothWithA5
- (void)onReceiveBloodPressureMeasureData:(LZA6BpMeasurementData *)bloodPressureData;
#endif

@end


NS_ASSUME_NONNULL_END


