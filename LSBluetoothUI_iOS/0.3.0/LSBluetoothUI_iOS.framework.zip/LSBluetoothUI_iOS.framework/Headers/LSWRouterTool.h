//
//  LSWRouterTool.h
//  LSWearable
//
//  Created by wm on 2019/10/10.
//  Copyright © 2019年 lifesense. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LSWRouterTool : NSObject


+ (NSString *)routerForSportsRecordViewController; //swift
+ (NSString *)routerForExerciseProgramViewController;

/**
 跳转到对应的viewController

 */
+ (void)pushToViewControllerWithRouterParameters:(NSDictionary *)routerParameters viewController:(__kindof UIViewController *)viewController;

+ (void)presentToViewControllerWithRouterParameters:(NSDictionary *)routerParameters viewController:(__kindof UIViewController *)viewController;

+ (UINavigationController *)getNavi;

+ (UINavigationController *)currentNC;


/// tabBarItem跳转
/// @param tabBarController tabBarController
/// @param index tabBarItem index
+ (void)tabBarController:(__kindof UITabBarController * _Nullable)tabBarController
             selectIndex:(NSInteger)index;


+ (NSDictionary *) parameterWithURL:(NSURL *) url;

@end

NS_ASSUME_NONNULL_END
