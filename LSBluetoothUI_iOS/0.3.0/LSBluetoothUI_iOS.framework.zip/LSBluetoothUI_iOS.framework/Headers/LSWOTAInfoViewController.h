//
//  LSWOTAInfoViewController.h
//  LSWearable
//
//  Created by ZhangWenzheng on 16/5/12.
//  Copyright © 2016年 lifesense. All rights reserved.
//

#import "LSWBaseViewController.h"

#import "LSDeviceManager+Bind.h"
#import "LSDeviceManager+Connect.h"
#import "LSDeviceManager+OTA.h"


/**
 *  OTA，固件信息页VC
 */
@interface LSWOTAInfoViewController : LSWBaseViewController
@property (nonatomic, strong) LSDevice *deviceInfo;
@property (nonatomic, copy) NSDictionary *otaDict;
@end
