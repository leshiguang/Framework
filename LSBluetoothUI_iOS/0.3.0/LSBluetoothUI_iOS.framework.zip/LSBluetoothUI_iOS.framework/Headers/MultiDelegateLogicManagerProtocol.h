//
//  MultiDelegateLogicManagerProtocol.h
//  WDGroup
//
//  Created by rolandxu on 12/21/15.
//  Copyright © 2015 WDG. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol MultiDelegateLogicManagerProtocol <NSObject>

- (void)addDelegate:(id)delegate;
- (void)removeDlegate:(id)delegate;
- (NSArray*)getDelegates;
- (id)deleageAtIndex:(NSInteger)index;
- (void)removeAllDelegates;

@end
