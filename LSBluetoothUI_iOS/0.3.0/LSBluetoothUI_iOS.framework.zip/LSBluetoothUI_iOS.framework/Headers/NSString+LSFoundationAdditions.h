//
//  NSString+LSFoundationAdditions.h
//  LSFoundationKit
//
//  Created by Wenzheng Zhang on 2017/10/6.
//  Copyright © 2017年 lifesense. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface NSString (LSFoundationAdditions)
+ (NSString *)ls_UUIDString;
+ (NSString *)ls_floatValueWithFloat:(CGFloat)floatValue;
+ (NSString *)ls_floatValueWithFloat:(CGFloat)floatValue precisionNum:(NSInteger)precisionNum;
+ (NSString *)ls_formatFloat:(CGFloat)floatValue;
- (NSString *)ls_MD5;
- (NSString*)ls_SHA1;
@end
