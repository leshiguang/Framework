//
//  LSLocalDataHelperHeader.h
//  Pods
//
//  Created by tanjian on 2020/12/24.
//

#ifndef LSLocalDataHelperHeader_h
#define LSLocalDataHelperHeader_h

#import "LSLocalDataHelper.h"
#import "LSLocalDataHelper+AlarmData.h"
#import "LSLocalDataHelper+Device.h"
#import "LSLocalDataHelper+DeviceSetting.h"
#import "LSLocalDataHelper+DeviceStatus.h"
#import "LSLocalDataHelper+DeviceUser.h"

#import "DeviceUser+CoreDataClass.h"
#import "AlarmData+CoreDataClass.h"
#import "Device+CoreDataClass.h"
#import "DeviceSetting+CoreDataClass.h"
#import "DeviceStatus+CoreDataClass.h"

#endif /* LSLocalDataHelperHeader_h */
