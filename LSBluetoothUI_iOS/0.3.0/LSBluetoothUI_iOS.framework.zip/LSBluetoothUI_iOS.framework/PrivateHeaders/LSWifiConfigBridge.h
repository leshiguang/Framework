//
//  LSWifiConfigBridge.h
//  LSWifiConfig
//
//  Created by 陈俊铭 on 16/3/10.
//  Copyright © 2016年 陈俊铭. All rights reserved.
//

#ifndef LSWifiConfigBridge_h
#define LSWifiConfigBridge_h

#include <string>
#include <thread>
#include <vector>
//#if defined(TARGET_OS_IPHONE)
#include <cstdio>
#include <cstdlib>
//#elif defined(ANDROID) || defined(__ANDROID__)
//#include "jni.h"
//#include "stdlib.h"
//#else
//#error "UnSpport platform"
//#endif


#include <unistd.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/poll.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <net/if.h>
#include <arpa/inet.h>

class LSWifiConfigBridge;

typedef enum _LSWifiConfigBridgeFlow {
    LSWifiConfigBridgeFlow_None = 0,   // 还没开始
    LSWifiConfigBridgeFlow_Guide,      // 发送前导域
    LSWifiConfigBridgeFlow_Magic,      // 发送Magic Code
    LSWifiConfigBridgeFlow_Prefix,     // 发送Prefix Code
    LSWifiConfigBridgeFlow_Sequence,   // 发送Sequence Code
}LSWifiConfigBridgeFlow;


typedef enum _LSWifiConfigBridgeCode {
    LSWifiConfigBridgeCodeCreateSocketError,
    LSWifiConfigBridgeCodeSetOptError,
    LSWifiConfigBridgeCodeBindError,
    LSWifiConfigBridgeCodeParamError,
    LSWifiConfigBridgeCodeTimeout,
    LSWifiConfigBridgeCodeSuccess,
}LSWifiConfigBridgeCode;

class LSWifiConfigBridge
{
public:
    
    static void reset();
    
    static void start(void *pObj, const char *ssid, const char *password);
    
    static void stop();
    
    static void setTimeoutTime(int timeout);
    
    static int getTimeoutTime();
    
    static int send(int);
    static bool isRecvRnd();
    
    
    
    static const char *version();
public:
    static void callDelegate(LSWifiConfigBridgeCode errCode);
    static void generate();
    
    static void thread_recv_task();
    static void thread_send_task();
};
#endif /* LSWifiConfigBridge_h */
