//
//  LSTools.hpp
//  LSAirKiss
//
//  Created by 陈俊铭 on 16/3/10.
//  Copyright © 2016年 陈俊铭. All rights reserved.
//

#ifndef LSTools_hpp
#define LSTools_hpp

#include <stdio.h>

class LSTools
{
public:
    /**
     * crc8计算
     * @param data 欲计算的数据
     * @param size 数据的大小
     */
    static int crc8(const char *data, int size);
};


#endif /* LSTools_hpp */
