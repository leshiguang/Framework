//
//  LZHrSectionViewController.h
//  lzbluetooth-mini-ui-ios
//
//  Created by tanjian on 2021/1/27.
//  心率区间， 有三个区间，会影响到心率区间统计

#import "LZBaseSettingViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface LZHrSectionViewController : LZBaseSettingViewController

@end

NS_ASSUME_NONNULL_END
