//
//  SleepMacro.h
//  LSWearable
//
//  Created by May on 16/1/28.
//  Copyright © 2016年 lifesense. All rights reserved.
//

#ifndef SleepMacro_h
#define SleepMacro_h

#define IS_IPHONE (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)

typedef enum SleepChartYAxisFormatterSleepStatus
{
    StatusDeep = -2, //深睡的坐标刻度
    StatusShallow = -1,//浅睡的坐标刻度
    StatusWake = 1,//清醒的坐标刻度
    StatusZero = 0
}SleepStatus;


#define colorDeep UIColorFromHex(0x0067FF);
#define colorShallow UIColorFromHex(0x4EACFF);
#define colorWake UIColorFromHex(0xDD53AC);


#endif /* SleepMacro_h */
