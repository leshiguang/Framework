//
//  LSJavascriptBatchBridge.h
//  LSWearable
//
//  Created by Wenzheng Zhang on 2017/5/3.
//  Copyright © 2017年 lifesense. All rights reserved.
//

#import <Foundation/Foundation.h>

//借鉴WebViewJavascriptBridge框架的实现原理

extern NSString *const kLSJavascriptBatchBridgeProtocolScheme;
extern NSString *const kLSQueueHasMessage;


typedef void (^LSJBResponseCallback)(id responseData);
typedef void (^LSJBHandler)(id data, LSJBResponseCallback responseCallback);
typedef NSDictionary* (^LSJBSyncMessageHandler)(id data);
typedef NSDictionary LSJBMessage;

@protocol LSJavascriptBatchBridgeDelegate <NSObject>
- (NSString*) _evaluateJavascript:(NSString*)javascriptCommand;
@end

@interface LSJavascriptBatchBridge : NSObject

@property (weak, nonatomic) id <LSJavascriptBatchBridgeDelegate> delegate;
@property (strong, nonatomic) NSMutableArray* startupMessageQueue;
@property (strong, nonatomic) NSMutableDictionary* responseCallbacks;
@property (strong, nonatomic) NSMutableDictionary* messageHandlers;
@property (strong, nonatomic) NSMutableDictionary* syncMessageHandlers;
@property (strong, nonatomic) LSJBHandler messageHandler;

+ (void)enableLogging;
+ (void)setLogMaxLength:(int)length;
- (void)reset;
- (void)sendData:(id)data responseCallback:(LSJBResponseCallback)responseCallback handlerName:(NSString*)handlerName;
- (void)flushMessageQueue:(NSString *)messageQueueString;
- (void)injectJavascriptFile;
- (void)nativeDidSetUp;
- (BOOL)isLSJavascriptBridgeURL:(NSURL*)url;
- (BOOL)isQueueMessageURL:(NSURL*)url;
- (void)logUnkownMessage:(NSURL*)url;
- (NSString *)LSJavascriptCheckCommand;
- (NSString *)LSJavascriptFetchQueyCommand;
- (void)disableJavscriptAlertBoxSafetyTimeout;

@end
