////
////  LSSFirstPageRefreshControl.h
////  LSSport
////
////  Created by wenZheng Zhang on 16/1/11.
////  Copyright © 2016年 Lifesense. All rights reserved.
////
//
//#import <UIKit/UIKit.h>
//@class LSWFirstPageRefreshControl;
//
//typedef NS_ENUM(NSUInteger, LSWFPRCFailureType) {
//    LSWFPRCFailureTypeConnectionFailed,
//    LSWFPRCFailureTypeBluetoothNotAvailable,
//    LSWFPRCFailureTypeLowPower,
//    LSWFPRCFailureTypeHRLowPower,
//    LSWFPRCFailureTypeNetworkDown,
//    LSWFPRCFailureTypeServerDown,
//    LSWFPRCFailureTypeUploadDataFailed,
//};
//
//typedef NS_ENUM(NSUInteger, LSSFirstPageRefreshControlState) {
//    LSSFirstPageRefreshControlStateIdle,
//    LSSFirstPageRefreshControlStateRefreshing,
//    LSSFirstPageRefreshControlStateFailed,
//    LSSFirstPageRefreshControlStateCompleted,
//};
//
//@protocol LSSFirstPageRefreshControlDelegate <NSObject>
//@optional
//- (void)firstPageRefreshControlDidTriggerLoading:(LSWFirstPageRefreshControl *)firstPageRefreshControl;
//@end
//
//@interface LSWFirstPageRefreshControl : UIView
//@property (nonatomic, weak) id <LSSFirstPageRefreshControlDelegate> delegate;
//@property (nonatomic, readonly) LSSFirstPageRefreshControlState currentState;
//@property (nonatomic, assign) BOOL shouldDoDelayedAnimation;
//
//- (void)showRefreshingStateInScrollView:(UIScrollView *)scrollView;
//
//- (void)scrollViewDidScroll:(UIScrollView *)scrollView;
//- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate;
//- (void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView;
//
//- (void)updateMessageWithMessage:(NSString *)message forState:(LSSFirstPageRefreshControlState)state;
//- (void)scrollViewDataSourceDidFinishedLoading:(UIScrollView *)scrollView message:(NSString *)message stayDuration:(NSTimeInterval)stayDuration;
//- (void)scrollViewDataSourceDidFailedLoading:(UIScrollView *)scrollView failureType:(LSWFPRCFailureType)failureType stayDuration:(NSTimeInterval)stayDuration;
//@end
