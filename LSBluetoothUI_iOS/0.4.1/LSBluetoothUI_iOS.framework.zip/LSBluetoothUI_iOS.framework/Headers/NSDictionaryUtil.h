//
//  NSDictionaryUtil.h
//  Utility
//
//  Created by rolandxu on 15/12/16.
//  Copyright (c) 2015年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

#define LSGetDictionaryStringDefaultNil(dict,key) [NSDictionaryUtil getDictionaryString:dict forKey:key defaultValue:nil]
#define LSGetDictionaryString(dict,key,default) [NSDictionaryUtil getDictionaryString:dict forKey:key defaultValue:default]
#define LSGetDictionaryNumberDefaultNil(dict,key) [NSDictionaryUtil getDictionaryNumber:dict forKey:key defaultValue:nil]
#define LSGetDictionaryNumber(dict,key,default) [NSDictionaryUtil getDictionaryNumber:dict forKey:key defaultValue:default]
#define LSGetDictionaryIntDefaultZero(dict,key) [NSDictionaryUtil getDictionaryInt:dict forKey:key defaultValue:0]
#define LSGetDictionaryInt(dict,key,default) [NSDictionaryUtil getDictionaryInt:dict forKey:key defaultValue:default]
#define LSGetDictionaryLongDefaultZero(dict,key) [NSDictionaryUtil getDictionaryLong:dict forKey:key defaultValue:0]
#define LSGetDictionaryLong(dict,key,default) [NSDictionaryUtil getDictionaryLong:dict forKey:key defaultValue:default]
#define LSGetDictionaryBoolDefaultFalse(dict,key) [NSDictionaryUtil getDictionaryLong:dict forKey:key defaultValue:false]
#define LSGetDictionaryBool(dict,key,default) [NSDictionaryUtil getDictionaryLong:dict forKey:key defaultValue:default]
#define LSGetDictionaryArrayDefaultNil(dict,key) [NSDictionaryUtil getDictionaryArray:dict forKey:key defaultValue:nil]
#define LSGetDictionaryArrayDefaultNilWithItemClass(dict,key,itemClass) [NSDictionaryUtil getDictionaryArrayWithItemClass:dict forKey:key defaultValue:nil itemclass:itemClass]

#define LSGetDictionaryDate(dict,key,default) [NSDictionaryUtil getDictionaryDate:dict forKey:key defaultValue:default]
#define LSGetDictionaryDateDefaultNil(dict,key) [NSDictionaryUtil getDictionaryDate:dict forKey:key defaultValue:nil]

#define LSGetDictionaryArray(dict,key) [NSDictionaryUtil getDictionaryArray:dict forKey:key defaultValue:[NSMutableArray arrayWithCapacity:0]]
#define LSGetDictionaryArrayWithItemClass(dict,key,itemClass) [NSDictionaryUtil getDictionaryArrayWithItemClass:dict forKey:key defaultValue:[NSMutableArray arrayWithCapacity:0] itemClass:itemClass]

#define LSGetDictionaryDictionaryDefaultNil(dict,key) [NSDictionaryUtil getDictionaryDictionary:dict forKey:key defaultValue:nil]
#define LSGetDictionaryDictionary(dict,key) [NSDictionaryUtil getDictionaryDictionary:dict forKey:key defaultValue:[NSMutableDictionary dictionaryWithCapacity:0]]


@interface NSDictionaryUtil : NSObject

#pragma get object from dictionary
//解析字符串
+ (NSString *)getDictionaryString:(NSDictionary *)dict forKey:(id)key defaultValue:(NSString*)fallback;
//解析int整数
+ (int)getDictionaryInt:(NSDictionary *)dict forKey:(id)key defaultValue:(int)fallback;
//解析long整数
+ (long)getDictionaryLong:(NSDictionary *)dict forKey:(id)key defaultValue:(long)fallback;
//解析bool变量
+ (bool)getDictionaryBool:(NSDictionary *)dict forKey:(id)key defaultValue:(bool)fallback;
//解析nsnumber
+ (NSNumber *)getDictionaryNumber:(NSDictionary *)dict forKey:(id)key defaultValue:(NSNumber*)fallback;
//解析nsdictionary
+ (NSDictionary *)getDictionaryDictionary:(NSDictionary *)dict forKey:(id)key defaultValue:(NSDictionary*)fallback;
//解析NSDate
+(NSDate *)getDictionaryDate:(NSDictionary *)dict forKey:(id)key defaultValue:(NSDate *)fallback;
//解析nsarray
+ (NSArray *)getDictionaryArray:(NSDictionary *)dict forKey:(id)key defaultValue:(NSArray*)fallback;
//解析nsarray，强制检查itemclass，如果不匹配，会用一个对应类型的空初始实例填充
+ (NSArray *)getDictionaryArrayWithItemClass:(NSDictionary *)dict forKey:(id)key defaultValue:(NSArray*)fallback itemclass:(Class)itemClass;
@end

@interface NSDictionary(TCAddition)
//解析字符串
- (NSString *)objectStringForKey:(id)key;
- (NSString *)objectStringForKey:(id)key defaultValue:(NSString*)fallback;

//解析int整数
- (int)objectIntForKey:(id)key;
- (int)objectIntForKey:(id)key defaultValue:(int)fallback;

//解析long整数
- (long)objectLongForKey:(id)key;
- (long)objectLongForKey:(id)key defaultValue:(long)fallback;

//解析nsnumber
- (NSNumber *)objectNumberForKey:(id)key;
- (NSNumber *)objectNumberForKey:(id)key defaultValue:(NSNumber*)fallback;

//解析NSDate
-(NSDate *)objectDateForKey:(id)key;
-(NSDate *)objectDateForKey:(id)key defaultValue:(NSDate*)fallback;

//解析nsdictionary
- (NSDictionary *)objectDictionaryForKey:(id)key;
- (NSDictionary *)objectDictionaryForKey:(id)key defaultValue:(NSDictionary*)fallback;

//解析nsarray
- (NSArray*)objectArrayForKey:(id)key;
- (NSArray *)objectArrayForKey:(id)key defaultValue:(NSArray*)fallback;
@end
