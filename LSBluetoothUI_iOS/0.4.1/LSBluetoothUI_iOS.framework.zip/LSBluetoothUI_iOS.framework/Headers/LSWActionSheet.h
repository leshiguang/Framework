//
//  LSWActionSheet.h
//  LSWearable
//
//  Created by wenZheng Zhang on 16/1/25.
//  Copyright © 2016年 lifesense. All rights reserved.
//

#import "LSWFullScreenHUDBackgroundView.h"

@class LSWActionSheet;

@protocol LSWActionSheetDeleagte <NSObject>
@optional
- (void)actionSheet:(LSWActionSheet *)actionSheet didTapButtonAtIndex:(NSInteger)index;
@end

@interface LSWActionSheet : LSWFullScreenHUDBackgroundView
@property (nonatomic, weak) id <LSWActionSheetDeleagte> delegate;
- (instancetype)initWithCancleButtonTitle:(NSAttributedString *)cancleButtonTitle otherButtonTitles:(NSArray <NSAttributedString *> *)otherButtonTitles;
@end
