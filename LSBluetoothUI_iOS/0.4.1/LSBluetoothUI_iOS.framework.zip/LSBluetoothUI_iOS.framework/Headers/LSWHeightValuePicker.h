//
//  LSWHeightValuePicker.h
//  LSWearable
//
//  Created by Wenzheng Zhang on 2016/10/19.
//  Copyright © 2016年 lifesense. All rights reserved.
//

#import "LSWFullScreenHUDBackgroundView.h"

@class LSWHeightValuePicker;

@protocol LSWHeightValuePickerDelegate <NSObject>
@optional
- (void)heightValuePicker:(LSWHeightValuePicker *)heightValuePicker didSelectHeight:(NSInteger)height;
@end

typedef void(^LSWHeightValuePickerDidSelectValueBlock)(NSInteger height);

/**
 身高选择器，以CM为单位
 */
@interface LSWHeightValuePicker : LSWFullScreenHUDBackgroundView


@property (nonatomic, weak) id <LSWHeightValuePickerDelegate> delegate;

@property (nonatomic, strong) LSWHeightValuePickerDidSelectValueBlock didSelectValueBlock;

@property (nonatomic, strong) NSString *unit;

/**
 最小身高，以CM为单位
 */
@property (nonatomic, assign, readonly) NSInteger minHeight;


/**
 最大身高，以CM为单位
 */
@property (nonatomic, assign, readonly) NSInteger maxHeight;


/**
 设置最大，最小身高，以CM为单位

 @param minHeight 最小身高
 @param maxHeight 最大身高
 */
- (void)setMinHeight:(NSInteger)minHeight maxHeight:(NSInteger)maxHeight;

/**
 设置选择器title和选中值
 
 @param title  title
 @param height 选中的身高
 */
- (void)setUpWithTitle:(NSString *)title selectedHeight:(NSInteger)height;

@end
