//
//  ErrorObject.h
//  LSWearable
//
//  Created by rolandxu on 12/18/15.
//  Copyright © 2015 lifesense. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ErrorObjectProtocol.h"

@interface ErrorObject : NSObject <ErrorObjectProtocol>

@end
