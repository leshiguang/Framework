//
//  NSCalendar+LSCalendar.h
//  LSWearable
//
//  Created by malai on 2017/9/27.
//  Copyright © 2017年 lifesense. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSCalendar (LSCalendar)

+ (NSCalendar *)ls_GregorianCalendar;

@end
