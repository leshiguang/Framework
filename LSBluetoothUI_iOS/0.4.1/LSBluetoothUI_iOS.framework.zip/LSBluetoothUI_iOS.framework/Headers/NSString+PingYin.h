//
//  NSString+PingYin.h
//  LSWearable
//
//  Created by boluobill on 2018/7/19.
//  Copyright © 2018 lifesense. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (PingYin)
- (NSString *)transformPingyin;
- (NSString *)transformPingyinNoBracket;
@end
