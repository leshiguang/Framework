//
//  LSDMRequestAndReponses.h
//  LSDeviceManager
//
//  Created by Wenzheng Zhang on 2017/9/12.
//  Copyright © 2017年 Wenzheng Zhang. All rights reserved.
//

#ifndef LSDMRequestAndReponses_h
#define LSDMRequestAndReponses_h
#import "LSGetDeviceInfoBySNRequest.h"
#import "LSSyncDataFromServerRequest.h"
#import "LSBindDeviceByDeviceIdRequest.h"
#import "LSUploadAlarmDataRequest.h"
#import "LSBindDeviceRequest.h"
#import "LSSetActiveDeviceRequest.h"
#import "LSGetLastFirmwareRequest.h"
#import "LSUnBindingDeviceByDeviceIdRequest.h"

#import "LSApplyDeviceIdRequest.h"
#import "LSApplyThirdDeviceIdRequest.h"
#import "LSGetHistoryDevicesRequest.h"
#import "LSGetDeviceInfoByQRCodeRequest.h"
#import "LSMatchingWifiRequest.h"
#import "LSGetManufacturerInformationRequest.h"
#import "LSSyncDataToServerRequest.h"
#import "LSSetWeightScaleUnitRequest.h"
#import "LSGetMatchingWifiInfoRequest.h"
#import "LSGetDeviceLastUploadTimeRequest.h"
#import "LSGetProductInfoListRequest.h"
#import "LSDMBaseRequest.h"


#import "LSDMJsonResponse.h"

#endif /* LSDMRequestAndReponses_h */
