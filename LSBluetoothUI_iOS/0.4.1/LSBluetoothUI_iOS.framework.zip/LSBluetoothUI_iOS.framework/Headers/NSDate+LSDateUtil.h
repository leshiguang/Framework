//
//  NSDate+LSDateUtil.h
//  LSWearable
//
//  Created by malai on 2017/9/26.
//  Copyright © 2017年 lifesense. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDate (LSDateUtil)


/**
 这个日期所在周的第一天 （默认星期日）

 @return 时间
 */
- (NSDate *)ls_firstWeekDay;
- (NSDate *)ls_lastWeekDay;
- (NSDate *)ls_zeroDay;

- (NSDate *)ls_firstMonthDay;

- (NSDate *)ls_firstYearDay;


- (BOOL)ls_isToday;

- (BOOL)ls_isYestoday;

- (BOOL)ls_isSameWeekWithDate:(NSDate *)date;

- (BOOL)ls_isSameDayWithDate:(NSDate *)date;

- (NSString *)ls_stringWithFormat:(NSString *)format;

- (NSString *)ls_stringWithFormat:(NSString *)format localId:(NSString *)localId;

/// 超过这天0点多少秒
- (NSTimeInterval)ls_daySecond;

+ (NSDate *)ls_dateWithString:(NSString *)string format:(NSString *)format;

- (NSInteger)ls_day;

- (NSInteger)ls_hour;

- (NSInteger)ls_minute;

- (NSInteger)ls_month;

- (NSInteger)ls_year;


- (NSDate *)ls_dateForZeroMinute;


/**
 距离date有多少天

 @param date date
 @return 天数
 */
- (NSInteger)ls_dayCountFromDate:(NSDate *)date;


/**
 距离date多少分钟

 @param date date
 @return 分钟数
 */
- (NSInteger)ls_minuteCountFromDate:(NSDate *)date;

- (NSInteger)ls_weekCountFromDate:(NSDate *)date;

+ (NSDateFormatter *)ls_formatter;

+ (NSDate *)ls_dateByYear:(NSInteger)year;

+ (NSDate *)ls_dateByYear:(NSInteger)year month:(NSInteger)month day:(NSInteger)day;




@end
