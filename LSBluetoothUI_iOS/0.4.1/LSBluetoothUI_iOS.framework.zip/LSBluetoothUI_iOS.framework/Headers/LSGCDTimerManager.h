//
//  LSWGCDTimer.h
//  LSWearable
//
//  Created by ZhangWenzheng on 16/3/31.
//  Copyright © 2016年 lifesense. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LSGCDTimerManager : NSObject
+ (instancetype)sharedInstance;

/**
 *  创建GCD Timer
 *
 *  @param timerName    timer名称，不能为nil
 *  @param timeInterval timeInterval
 *  @param queue        action block的执行queue，为nil时使用globle queue
 *  @param repeats      是否重复
 *  @param action       action block
 */
- (void)scheduleDispatchTimerWithTimerName:(NSString *)timerName timeInterval:(NSTimeInterval)timeInterval queue:(dispatch_queue_t)queue repeats:(BOOL)repeats action:(dispatch_block_t)action;

/**
 *  取消timer
 *
 *  @param timerName timer名称，不能为nil
 */
- (void)cancleTimerWithTimerName:(NSString *)timerName;
@end
