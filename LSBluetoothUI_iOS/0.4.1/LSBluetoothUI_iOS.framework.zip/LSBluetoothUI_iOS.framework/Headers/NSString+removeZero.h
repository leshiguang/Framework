//
//  NSString+TCAddition.h
//  HKWeibo
//
//  Created by Vincentc Lin on 12-9-7.
//  Copyright (c) 2012年 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString(removeZero)

- (NSString *)removeZero;

@end




