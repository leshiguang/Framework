//
//  LSWMineTableViewCell.h
//  LSWearable
//
//  Created by malai on 2016/12/8.
//  Copyright © 2016年 lifesense. All rights reserved.
//

#import "LSWSeparateLineTableViewCell.h"

@interface LSWMineTableViewCell : LSWSeparateLineTableViewCell

@property (nonatomic, readonly) UIImageView *rightArrowImageView;

@property (nonatomic, readonly) UILabel *detailLabel;

@property (nonatomic, readonly) UILabel *titleLabel;

@property (nonatomic, readonly) UIImageView *iconImageView;


/**
 是否隐藏又箭头
 
 @param isHidden default NO
 */
- (void)setRightArrowImageViewHidden:(BOOL)isHidden;

- (void)setTitleLabelHidden:(BOOL)isHidden;
@end
