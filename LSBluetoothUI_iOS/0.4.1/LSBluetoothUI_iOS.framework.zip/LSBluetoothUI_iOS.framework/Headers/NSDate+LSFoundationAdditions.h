//
//  NSDate+LSAdditions.h
//  LSDemo
//
//  Created by 1 on 14-3-12.
//  Copyright (c) 2014年 Lifesense. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LSDateFormatter.h"
#define LS_DAY_FORMAT @"yyyyMMdd"
#define LS_DAYHOUR_FORMAT @"yyyy-MM-dd HH:mm:ss"
#define LS__DAY__FORMAT @"yyyy-MM-dd"

#define LSMakeDate(date,format) \
[NSDate ls_dateWithString:date withFormat:format]


@interface NSDate (LSFoundationAdditions)

+ (LSDateFormatter *)ls_dateFormatterForDateFormat:(NSString *)dateFormat;
- (NSString *)ls_nsdateStringWithFormat:(NSString *)format;
+ (NSDate *)ls_dateWithString:(NSString *)string withFormat:(NSString *)format;
- (BOOL)ls_sameMonthWithDate:(NSDate *)date;
- (BOOL)ls_isSameDay:(NSDate *)date;
- (BOOL)ls_isLaterDayThanDate:(NSDate *)date;
- (BOOL)ls_isEarlierDayThanDate:(NSDate *)date;
- (BOOL)ls_isSameMonth:(NSDate *)date;
- (BOOL)ls_isSameYear:(NSDate *)date;


@end
