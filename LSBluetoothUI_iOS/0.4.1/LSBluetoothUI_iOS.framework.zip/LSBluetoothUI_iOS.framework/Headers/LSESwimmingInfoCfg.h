//
//  LSESwimmingInfoCfg.h
//  LSWearable
//
//  Created by lifesense－mac on 17/6/23.
//  Copyright © 2017年 lifesense. All rights reserved.
//  游泳设置模型

#import <Foundation/Foundation.h>

@interface LSESwimmingInfoCfg : NSObject

/// 泳池长度
@property(nonatomic, assign) NSUInteger poolLength;

@end
