//
//  LSWValuePicker.h
//  LSWearable
//
//  Created by ZhangWenzheng on 16/8/23.
//  Copyright © 2016年 lifesense. All rights reserved.
//

#import <UIKit/UIKit.h>

@class LSWValuePicker;


@protocol LSWValuePickerDataSource <NSObject>
@required

- (NSInteger)numOfColumnInValuePicker:(LSWValuePicker *)valuePicker;
- (NSInteger)valuePicker:(LSWValuePicker *)valuePicker numOfRowInColumn:(NSInteger)column;
- (NSString *)valuePicker:(LSWValuePicker *)valuePicker valueStringForRow:(NSInteger)row inColumn:(NSInteger)column;
- (NSString *)valuePicker:(LSWValuePicker *)valuePicker titleForColumn:(NSInteger)column;
- (CGSize)valuePicker:(LSWValuePicker *)valuePicker offsetForTitleAtColumn:(NSInteger)column;

@optional
- (CGPoint)valuePicker:(LSWValuePicker *)valuePicker offsetForValueStringAtColumn:(NSInteger)column;
@end


@protocol LSWValuePickerDelegate <NSObject>
@optional
- (void)valuePicker:(LSWValuePicker *)valuePicker didSelectRow:(NSInteger)row inColumn:(NSInteger)column;
@end

@interface LSWValuePicker : UIView
@property (nonatomic, weak) id <LSWValuePickerDataSource> dataSource;
@property (nonatomic, weak) id <LSWValuePickerDelegate> delegate;

@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong, readonly) UIButton *cancleButton;
@property (nonatomic, strong, readonly) UIButton *confirmButton;
@property (nonatomic, assign, readonly) CGFloat controlContainerHeight;


- (void)reloadAllData;
- (void)reloadDataInColumn:(NSInteger)column;
- (NSInteger)selectedRowInColumn:(NSInteger)column;
- (void)setSelectedRow:(NSInteger)row inColumn:(NSInteger)column animated:(BOOL)animated;
@end
