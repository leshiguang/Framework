//
//  LSWGenderPickerView.h
//  LSWearable
//
//  Created by Wenzheng Zhang on 2017/9/26.
//  Copyright © 2017年 lifesense. All rights reserved.
//

#import "LSWFullScreenHUDBackgroundView.h"

typedef NS_ENUM(NSUInteger, LSWGenderPickerViewGenderType) {
    LSWGenderPickerViewGenderTypeFemale = 0,
    LSWGenderPickerViewGenderTypeMale = 1,
};

typedef void(^LSWGenderPickerViewDidSelectValueBlock)(LSWGenderPickerViewGenderType genderType);

@interface LSWGenderPickerView : LSWFullScreenHUDBackgroundView
@property (nonatomic, strong) LSWGenderPickerViewDidSelectValueBlock didSelectValueBlock;

/**
 设置选择器title和选中值
 
 @param title  title
 @param genderType 选中的性别类型
 */
- (void)setUpWithTitle:(NSString *)title selectedGenderType:(LSWGenderPickerViewGenderType)genderType;
@end
