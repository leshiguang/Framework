//
//  LSWMineBraceletTableViewCell.h
//  LSWearable
//
//  Created by malai on 2016/12/10.
//  Copyright © 2016年 lifesense. All rights reserved.
//

#import <UIKit/UIKit.h>

@class LSDevice;
@class LSWMineBraceletTableViewCell;

@protocol LSWMineBraceletTableViewCellDelegate <NSObject>

- (void)braceletCelldidClickActivtyButton:(LSWMineBraceletTableViewCell *)cell;

@end

@interface LSWMineBraceletTableViewCell : UITableViewCell

@property (nonatomic, weak) id<LSWMineBraceletTableViewCellDelegate> delegate;

@property (nonatomic, strong) LSDevice *device;

- (void)updateUIWithDevice:(LSDevice *)LSDevice isOnlyOne:(BOOL)isOnlyOne bluetoothEnabled:(BOOL)bluetoothEnabled;
@end
