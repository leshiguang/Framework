//
//  LSTransformToBluetoothProtocol.h
//  LSDeviceManager
//
//  Created by tanjian on 2021/1/7.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@protocol LSTransformToBluetoothProtocol <NSObject>

- (id)bluetoothData;

@end

NS_ASSUME_NONNULL_END
