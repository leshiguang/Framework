//
//  ZWZWaterFallCollectionViewGlobalViewLayoutAttributes.h
//  ZWZWaterFallCollectionViewLayout
//
//  Created by wenZheng Zhang on 15/10/26.
//  Copyright © 2015年 ZWZ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZWZWaterFallCollectionViewGlobalViewLayoutAttributes : UICollectionViewLayoutAttributes
@property (nonatomic) BOOL expandContent;
@end
