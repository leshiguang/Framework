////
////  LSWWeightPickerView.h
////  LSWearable
////
////  Created by wenZheng Zhang on 16/1/19.
////  Copyright © 2016年 lifesense. All rights reserved.
////
//
//#import <UIKit/UIKit.h>
//@class LSWValuePickerView;
//
//@protocol LSWValuePickerViewDelegate <NSObject>
//@optional
//- (void)valuePickerView:(LSWValuePickerView *)valuePickerView didSelectedValue:(CGFloat)value;
//@end
//
//@interface LSWValuePickerView : UIView
//
///*!
// *  最大值
// */
//@property (nonatomic, assign) CGFloat maxValue;
//
///*!
// *  最小值
// */
//@property (nonatomic, assign) CGFloat minValue;
//
///*!
// *  递增值
// */
//@property (nonatomic, assign) CGFloat stepValue;
//
///*!
// *  递增值拆分为多少个单元格
// */
//@property (nonatomic, assign) NSInteger splitNum;
//
///*!
// *  单元格宽度
// */
//@property (nonatomic, assign) CGFloat cellWidth;
//
//@property (nonatomic, weak) id <LSWValuePickerViewDelegate> delegate;
//
//@property (nonatomic, assign) CGFloat selectedValue;
//- (void)setSelectedValue:(CGFloat)selectedValue animated:(BOOL)animted;
//@end
