//
//  LZSearchDeviceViewController.h
//  LSBluetoothUI_iOS
//
//  Created by wm on 2020/11/26.
//

#import "LSWBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@class LSDevice;

@protocol LZSearchDeviceDelegate <NSObject>

- (void)searchDevice:(NSArray <LSDevice *>*)deviceInfos;

@end

@interface LZSearchDeviceViewController : LSWBaseViewController

@property (nonatomic, weak) id <LZSearchDeviceDelegate> delegate;
 
@end

NS_ASSUME_NONNULL_END
