//
//  TKAlertViewController+Private.h
//  
//
//  Created by binluo on 15/5/28.
//  Copyright (c) 2015年 Baijiahulian. All rights reserved.
//

#import "TKAlertViewController.h"
#import "LSWMacro.h"

#define kAlertViewBorder                35
#define kAlertViewBounce                20

#define kAlertViewTitleBorder           15


//按钮高度
#define kAlertButtonHeight              50

#define kAlertButtonLineWidth           (1.0/[UIScreen mainScreen].scale)

#define kAlertViewDefaultWidth          305//280
#define kAlertViewMinHeigh              150
#define kAlertViewMinWidth              150
#define kAlertViewMaxWidth              [UIScreen mainScreen].fixedBounds.size.width

//标题

#define kAlertViewTitleFont             LSWDefaultBoldFontWithSize(18)
#define kAlertViewTitleTextColor        [UIColor colorWithWhite:34.0/255.0 alpha:1.0]

#define kAlertViewMessageNoTitleFont           [UIFont systemFontOfSize:18]
#define kAlertViewMessageFont           [UIFont systemFontOfSize:16]
#define kAlertViewMessageTextColor      [UIColor colorWithWhite:65.0/255.0 alpha:1.0]

#define kAlertViewLineColor             [UIColor colorWithWhite:182/255.0 alpha:1]//B6B6B6

//确认按钮字体
#define kAlertViewButtonFont            [UIFont systemFontOfSize:18]
//确认按钮颜色
#define kAlertViewButtonTextColor       [UIColor colorWithRed:30/255.0 green:171/255.0 blue:225/255.0 alpha:1]
//取消按钮颜色
#define kAlertViewCancelButtonTextColor [UIColor colorWithWhite:182/255.0 alpha:1]


//背景颜色
#define kAlertViewBackgroundColor       [UIColor colorWithWhite:255/255.0 alpha:1]

//蒙板颜色
#define kAlertViewMaskBackgroundColor   [UIColor colorWithWhite:0/255.0 alpha:0.5]


#define kAnimationCompletionKey         @"AnimationCompletionKey"



@interface TKAlertViewController ()<UIGestureRecognizerDelegate, CAAnimationDelegate>

@property (nonatomic, assign) BOOL isAnimating;
@property (nonatomic, assign) BOOL cancelWhenDoneAnimating;
@property (nonatomic, assign) TKAlertViewAnimation animationType;
@property (nonatomic, assign) UIOffset offset;
@property (nonatomic, assign) UIOffset  landscapeOffset;

@property (nonatomic, strong) UITapGestureRecognizer *tapGestureRecognizer;
@property (nonatomic, copy)  void (^dismissWhenTapWindowHandler)(void) ;
@property (nonatomic, readwrite) BOOL dismissBySwipe;

@property (nonatomic, strong) UIPanGestureRecognizer *panGestureRecognizer;

@property (nonatomic, strong) NSMutableArray *actions;

@property (nonatomic, strong) NSMutableDictionary *titleColorDic;
@property (nonatomic, strong) UIColor *windowBackgroundColor;

@property (nonatomic, strong) UIView *wapperView;
@property (nonatomic, strong) UIScrollView *scrollView;
@property (nonatomic, strong) UIView *customView;
@property (nonatomic, strong) UIView *buttonContainerView;

@property (nonatomic, strong) UIDynamicAnimator *animator;
@property (nonatomic, assign) BOOL enabledParallaxEffect;



@end


@interface TKAlertViewController(Private)

- (void)updateFrameForDisplay;

- (void)popupAlertAnimated:(BOOL)animated animationType:(TKAlertViewAnimation)animationType atOffset:(UIOffset)offset;

- (UIButton *)buttonForIndex:(NSInteger)buttonIndex;
- (void)hiddenAlertAnimatedWithCompletion:(void (^)(BOOL finished))completion;
- (void)showAlertWithAnimationType:(TKAlertViewAnimation)animationType completion:(void (^)(BOOL finished))completion1;
- (void)dismissWithClickedButtonIndex:(NSInteger)buttonIndex animated:(BOOL)animated completion:(void (^)(void))completion noteDelegate:(BOOL)noteDelegate;
- (void)dismissAnimated:(BOOL)animated;
- (void)rePopupAnimated:(BOOL)animated;
- (void)removeAlertWindowOrShowAnOldAlert;
- (void)temporarilyHideAnimated:(BOOL)animated;

- (void)showOverlayWindowAniamted;


- (void)addParallaxEffect;
- (void)removeParallaxEffect;

@end// 版权属于原作者
// http://code4app.com (cn) http://code4app.net (en)
// 发布代码于最专业的源码分享网站: Code4App.com// 版权属于原作者
// http://code4app.com (cn) http://code4app.net (en)
// 发布代码于最专业的源码分享网站: Code4App.com// 版权属于原作者
// http://code4app.com (cn) http://code4app.net (en)
// 发布代码于最专业的源码分享网站: Code4App.com
