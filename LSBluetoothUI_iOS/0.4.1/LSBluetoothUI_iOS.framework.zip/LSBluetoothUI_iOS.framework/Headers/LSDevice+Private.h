//
//  LSDevice+Private.h
//  LSDeviceManager
//
//  Created by tanjian on 2020/12/25.
//

#import "LSLocalDataHelperHeader.h"
#import <LZBluetooth/LZBaseDevice.h>

NS_ASSUME_NONNULL_BEGIN

@interface LSDevice ()


/// 这个主要影响蓝牙底层库所需要使用的manager
@property (nonatomic, assign) LZDeviceType blueDeviceType;

/// 这个是网络数据结构
@property (nonatomic, strong) Device *device;

/// 这个是底层的蓝牙数据结构
@property (nonatomic, strong) id<LZDeviceProtocol> blueDevice;

- (instancetype)initWithDevice:(Device *)device;
- (instancetype)initWithBlueDevice:(id<LZDeviceProtocol>)blueDevice;

@end

NS_ASSUME_NONNULL_END
