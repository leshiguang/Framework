//
//  LSLoadProtocolPlist.h
//  CocoaDebug
//
//  Created by tanjian on 2020/12/24.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LSLoadProtocolPlist : NSObject

+ (void)loadDeviceNetworkPlist;

@end

NS_ASSUME_NONNULL_END
