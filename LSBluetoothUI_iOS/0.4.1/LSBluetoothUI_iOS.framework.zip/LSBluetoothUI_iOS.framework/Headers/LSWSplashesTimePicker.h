//
//  LSWSplashesTimePicker.h
//  LSWearable
//
//  Created by pengpeng on 2019/8/27.
//  Copyright © 2019 lifesense. All rights reserved.
//

#import "LSWFullScreenHUDBackgroundView.h"

typedef enum : NSUInteger {
    LSWSplashesTimePickerTypeTime,
    LSWSplashesTimePickerTypeHourCount,
} LSWSplashesTimePickerType;

@class LSWSplashesTimePicker;

@protocol LSWSplashesTimePickerDelegate <NSObject>
@optional
- (void)lswSplashestimePicker:(LSWSplashesTimePicker *)timePicker didSelect:(NSInteger)index;
@end


@interface LSWSplashesTimePicker : LSWFullScreenHUDBackgroundView

@property (nonatomic, weak) id <LSWSplashesTimePickerDelegate> delegate;

@property (nonatomic, assign) LSWSplashesTimePickerType pickerType;

- (void)setUpWithTitle:(NSString *)title selectedHour:(NSInteger)selectedHour;

@end
