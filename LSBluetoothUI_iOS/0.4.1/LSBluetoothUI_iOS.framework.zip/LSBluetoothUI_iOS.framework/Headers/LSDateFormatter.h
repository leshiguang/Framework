//
//  LSWDateFormatter.h
//  LSWearable
//
//  Created by bill on 16/9/12.
//  Copyright © 2016年 lifesense. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LSDateFormatter : NSDateFormatter

@end
