//
//  LSUploadAlarmDataRequest.h
//  LSWearable
//
//  Created by wenzhengzhang on 2017/7/31.
//  Copyright © 2017年 lifesense. All rights reserved.
//

#import "LSDMBaseRequest.h"

@interface LSUploadAlarmDataRequest : LSDMBaseRequest

/**
 userId
 */
@property (nonatomic, copy) NSString *userId;

/**
 startTime
 */
@property (nonatomic, copy) NSNumber *startTime;

/**
 errorSources
 */
@property (nonatomic, copy) NSNumber *errorSources;

/**
 errorType
 */
@property (nonatomic, copy) NSString *errorType;

/**
 errorCount
 */
@property (nonatomic, copy) NSString *errorCount;

/**
 errorCause
 */
@property (nonatomic, copy) NSString *errorCause;

/**
 remark
 */
@property (nonatomic, copy) NSString *remark;

@end
