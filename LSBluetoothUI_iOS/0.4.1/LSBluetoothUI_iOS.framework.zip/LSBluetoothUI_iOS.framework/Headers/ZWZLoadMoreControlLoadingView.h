//
//  ZWZLoadMoreControlLoadingView.h
//  ZWZLoadMoreControlDemo
//
//  Created by wenZheng Zhang on 16/1/5.
//  Copyright © 2016年 ZWZ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZWZLoadMoreControlLoadingView : UIView
@property (nonatomic) NSString *loadingTitle;
- (void)startLoading;
- (void)stopLoading;
@end
