//
//  LZBaseDeviceInfoViewController.h
//  lzbluetooth-mini-ui-ios
//
//  Created by tanjian on 2021/1/25.
//

#import "LZDeviceManagerViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface LZBaseDeviceInfoViewController : LZDeviceManagerViewController

@end

NS_ASSUME_NONNULL_END
