//
//  LSDeviceManagerDelegate.h
//  LSDeviceManager
//
//  Created by tanjian on 2020/12/24.
//

#import <Foundation/Foundation.h>
#import "LSDeviceManagerDefine.h"

NS_ASSUME_NONNULL_BEGIN

@class LSDevice;
@class LSReceiveData;

@protocol LSDeviceManagerDelegate <NSObject>

@optional

/// 蓝牙是否开关
/// @param state 状态
- (void)onBluetoothStateChange:(NSInteger)state;

/// 连接状态发生改变
/// @param device 设备
- (void)deviceDidUpdateConnectStatus:(LSDevice *)device;

/// 设备的电量状态发生变化
/// @param device 设备
- (void)deviceDidUpdateBatteryStatus:(LSDevice *)device;

/// 设备绑定状态回调
/// @param device 设备
/// @param bindState 绑定状态
/// @param netCode 网络错误码
/// @Param netMsg 网络请求信息
- (void)device:(LSDevice *)device bindStateChanged:(LSBindStatus)bindState netCode:(NSInteger)netCode netMsg:(NSString *)netMsg;

/// 收到测量数据
/// @param measurementDatas 测量数据
/// @param dataType 数据类型
- (void)deviceDidReceiveMeasurementDatas:(NSArray <LSReceiveData *> *)measurementDatas dataType:(LSMeasurementDataType)dataType;

@end

NS_ASSUME_NONNULL_END
