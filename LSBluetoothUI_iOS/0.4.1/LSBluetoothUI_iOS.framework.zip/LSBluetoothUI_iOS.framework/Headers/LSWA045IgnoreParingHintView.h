//
//  LSWA045IgnoreParingHintView.h
//  LSWearable
//
//  Created by ZhangWenzheng on 16/5/14.
//  Copyright © 2016年 lifesense. All rights reserved.
//

#import "LSWFullScreenHUDBackgroundView.h"

@interface LSWA045IgnoreParingHintView : LSWFullScreenHUDBackgroundView
@property (nonatomic, strong, readonly) UIButton *confirmButton;
@end
