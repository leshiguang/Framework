//
//  NSDictionary+LSWMessage.h
//  LSWearable
//
//  Created by sillker on 2016/10/26.
//  Copyright © 2016年 lifesense. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (LSWMessage)

//+ (NSDictionary *)lsw_dictionaryWithJsonString:(NSString *)jsonString;
//- (NSString *)convertToJsonString;
@end
