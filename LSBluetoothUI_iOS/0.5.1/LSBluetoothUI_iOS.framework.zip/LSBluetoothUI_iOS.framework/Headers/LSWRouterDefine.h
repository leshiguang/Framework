//
//  LSWRouterDefine.h
//  LSWearable
//
//  Created by wm on 2019/8/9.
//  Copyright © 2019年 lifesense. All rights reserved.
//

#ifndef LSWRouterDefine_h
#define LSWRouterDefine_h

#define SCHEMES @"lswearable://%@"
#define ROUTERURL(host) [NSString stringWithFormat:SCHEMES,host]

#pragma mark - 首页
#define LSWRouterShowUnknownWeight ROUTERURL(@"showUnknownWeight")                                  //展示未知体重页面
#define LSWRouterShowBloodSugarListView ROUTERURL(@"showBloodSugarListView")                        //血糖详情页
#define LSWRouterShowRecordBloodGlucose ROUTERURL(@"showRecordBloodGlucose")                        //血糖记录页
#define LSWRouterShowBloodPressureMeasurementMsg ROUTERURL(@"showBloodPressureMeasurementMsg")      //血压详情页
#define LSWRouterShowRecordBloodPressure ROUTERURL(@"showRecordBloodPressure")                      //血压记录页
#define LSWRouterShowRecordBloodGlucoseAndBloodPressure ROUTERURL(@"showRecordBloodGlucoseAndBloodPressure")   //血糖血压综合记录页

#pragma mark - 运动

#pragma mark - 发现

#pragma mark - 我的

#define LSWRouterShowUserGrowView ROUTERURL(@"showUserGrowView")                    //我的成长页面
#define LSWRouterShowWechatRankListView ROUTERURL(@"showWechatRankListView")        //微信排行榜页面
#define LSWRouterShowQQSportView ROUTERURL(@"showQQSportView")                      //QQ排行榜页面
#define LSWRouterShowLSProducts ROUTERURL(@"showLSProducts")                        //乐心产品页面
#define LSWRouterShowDeviceInfo ROUTERURL(@"showDeviceInfo")                        //设备详情页面
#define LSWRouterShowWeightDeviceInfo ROUTERURL(@"showWeightDeviceInfo")            //体重设备详情页面
#define LSWRouterShowMyDeviceList ROUTERURL(@"showDeviceList")                      //我的设备列表
#define LSWRouterShowAdNewDevice ROUTERURL(@"addDeviceAction")                     //添加设备页面
#define LSWRouterShowUrlContent ROUTERURL(@"showUrlContent")                        //webView页面
#define LSWRouterShowAddBodyLengthView ROUTERURL(@"showAddBodyLengthView")          //添加体围页面
#define LSWRouterShowFamilyMemberInfo ROUTERURL(@"showFamilyMemberInfo")            //添加、编辑家庭成员页面
#define LSWRouterShowUserInfo ROUTERURL(@"userInfo")                                //个人信息页面


#define LSWRouterShowGroupListView ROUTERURL(@"showGroupListView")                  //群组页面
#define LSWRouterShowFeedbackView ROUTERURL(@"showFeedbackView")                    //意见反馈
#define LSWRouterShowUploadSportRecords ROUTERURL(@"showUploadSportRecords")        //待确认运动数据上传页面
#define LSWRouterShowSportView ROUTERURL(@"showSportView")                          //运动记录页面
#define LSWRouterShowExerciseProgram ROUTERURL(@"showExerciseProgram")              //有氧运动计划页面
#define LSWRouterShowHeartrateResultList ROUTERURL(@"showHeartrateResultList")      //心率页面
#define LSWRouterShowActivityTargetView ROUTERURL(@"showActivityTargetView")        //活动目标页面
#define LSWRouterSelectTabBarItem ROUTERURL(@"selectTabBar") //tabBarItem跳转

#define LSWRouterJumpWXMiniProgram ROUTERURL(@"jumpWXMiniProgram")     //跳转微信小程序

#define LSWRouterHeartRateSetting ROUTERURL(@"heartRateSetting")   //连续心率监测页面

#define LSWRouterProgram_main ROUTERURL(@"program_main")     //有氧能力提升计划页面

#define LSWRouterAdd_aerobic_plan ROUTERURL(@"add_aerobic_plan")     //添加有氧能力提升计划页面

#define LSWRouterGPSPathView ROUTERURL(@"GPSPathView")    //GPS运动页面

#endif /* LSWRouterDefine_h */
