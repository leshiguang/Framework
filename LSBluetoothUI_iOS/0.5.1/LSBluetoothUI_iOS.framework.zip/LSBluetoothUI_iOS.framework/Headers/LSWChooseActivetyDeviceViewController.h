//
//  LSWChooseActivetyDeviceViewController.h
//  LSWearable
//
//  Created by malai on 2017/6/14.
//  Copyright © 2017年 lifesense. All rights reserved.
//

#import "LSWBaseViewController.h"

@class LSWChooseActivetyDeviceViewController;

@protocol LSWChooseActivetyDeviceViewControllerDelegate <NSObject>

- (void)chooseActivetyDeviceViewControllerCertainButtonClicked:(LSWChooseActivetyDeviceViewController *)chooseActivetyDeviceViewController;

- (void)chooseActivetyyDeviceViewControllerLastActiveDeviceButtonClicked:(LSWChooseActivetyDeviceViewController *)chooseActivetyDeviceViewController;

@end

@interface LSWChooseActivetyDeviceViewController : LSWBaseViewController

@property (nonatomic, copy) NSString *iconImageUrlString;

@property (nonatomic, copy) NSString *deviceName;

@property (nonatomic, weak) id<LSWChooseActivetyDeviceViewControllerDelegate> delegate;

@end
