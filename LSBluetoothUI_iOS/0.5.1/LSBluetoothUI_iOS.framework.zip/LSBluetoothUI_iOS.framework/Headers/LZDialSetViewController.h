//
//  LZDialSetViewController.h
//  LSBluetoothUI_iOS
//
//  Created by wm on 2020/12/8.
//

#import "LZDeviceManagerViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface LZDialSetViewController : LZDeviceManagerViewController

@end

NS_ASSUME_NONNULL_END
