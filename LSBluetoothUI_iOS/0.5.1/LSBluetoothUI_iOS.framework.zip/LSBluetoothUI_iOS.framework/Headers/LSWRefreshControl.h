//
//  LSWRefreshControl.h
//  LSSport
//
//  Created by wenZheng Zhang on 16/1/11.
//  Copyright © 2016年 Lifesense. All rights reserved.
//

#import <UIKit/UIKit.h>
@class LSWRefreshControl;

typedef NS_ENUM(NSUInteger, LSWRefreshFailureType) {
    LSWRefreshFailureTypeConnectionFailed,
    LSWRefreshFailureTypeBluetoothNotAvailable,
    LSWRefreshFailureTypeLowPower,
    LSWRefreshFailureTypeHRLowPower,
    LSWRefreshFailureTypeNetworkDown,
    LSWRefreshFailureTypeServerDown,
    LSWRefreshFailureTypeUploadDataFailed,
    LSWRefreshFailureTypeBluetoothUnauthorized
};

typedef NS_ENUM(NSUInteger, LSWRefreshControlState) {
    LSWRefreshControlStatePrepare,
    LSWRefreshControlStateRefreshing,
    LSWRefreshControlStateFailed,
    LSWRefreshControlStateCompleted,
};

@protocol LSWRefreshControlDelegate <NSObject>
@optional
- (void)refreshControlDidTriggerLoading:(LSWRefreshControl *)refreshControl;
@end

@interface LSWRefreshControl : UIView
@property (nonatomic, weak) id <LSWRefreshControlDelegate> delegate;
@property (nonatomic, readonly) LSWRefreshControlState currentState;
@property (nonatomic, assign) BOOL shouldDoDelayedAnimation;

- (void)showRefreshingStateInScrollView:(UIScrollView *)scrollView;

- (void)scrollViewDidScroll:(UIScrollView *)scrollView;
- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate;
- (void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView;

- (void)updateMessageWithMessage:(NSString *)message forState:(LSWRefreshControlState)state;
- (void)scrollViewDataSourceDidFinishedLoading:(UIScrollView *)scrollView message:(NSString *)message stayDuration:(NSTimeInterval)stayDuration;
- (void)scrollViewDataSourceDidFailedLoading:(UIScrollView *)scrollView failureType:(LSWRefreshFailureType)failureType stayDuration:(NSTimeInterval)stayDuration;
@end
