//
//  NSAttributedString+LSAdditions.h
//  LSWearable
//
//  Created by wenZheng Zhang on 16/1/15.
//  Copyright © 2016年 lifesense. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface NSAttributedString (LSAdditions)
+ (NSAttributedString *)ls_attributedStringWithString:(NSString *)string font:(UIFont *)font textColor:(UIColor *)textColor;
+ (NSAttributedString *)ls_attributedStringWithString:(NSString *)string font:(UIFont *)font textColor:(UIColor *)textColor lineSpacing:(CGFloat)lineSpacing;
+ (NSAttributedString *)ls_attributedStringWithString:(NSString *)string font:(UIFont *)font textColor:(UIColor *)textColor lineSpacing:(CGFloat)lineSpacing textAlignment:(NSTextAlignment)textAlignment;
@end
