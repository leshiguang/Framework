//
//  LSWDatePicker.h
//  LSWearable
//
//  Created by Wenzheng Zhang on 2016/10/19.
//  Copyright © 2016年 lifesense. All rights reserved.
//

#import "LSWFullScreenHUDBackgroundView.h"

@class LSWDatePicker;

@protocol LSWDatePickerDelegate <NSObject>
@optional
- (void)lswDatePicker:(LSWDatePicker *)lswDatePicker didSelectDate:(NSDate *)date;
@end

typedef void(^LSWDatePickerDidSelectValueBlock)(NSDate *date);

/**
 年月日选择器
 */
@interface LSWDatePicker : LSWFullScreenHUDBackgroundView

@property (nonatomic, weak) id <LSWDatePickerDelegate> delegate;

@property (nonatomic, strong) LSWDatePickerDidSelectValueBlock didSelectValueBlock;


/**
 最小可选中日期
 */
@property (nonatomic, strong, readonly) NSDate *minDate;


/**
 最大可选中日期
 */
@property (nonatomic, strong, readonly) NSDate *maxDate;


/**
 设置最大最小选中日期

 @param minDate 最小选中日期
 @param maxDate 最大选中日期
 */
- (void)setMinDate:(NSDate *)minDate maxDate:(NSDate *)maxDate;

/**
 设置选择器title和选中值
 
 @param title  title
 @param date   选中的日期
 */
- (void)setUpWithTitle:(NSString *)title selectedDate:(NSDate *)date;
@end
