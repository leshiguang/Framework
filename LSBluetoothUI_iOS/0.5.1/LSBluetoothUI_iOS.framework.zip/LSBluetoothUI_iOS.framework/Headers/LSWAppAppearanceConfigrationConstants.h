//
//  LSWAppAppearanceConfigrationConstants.h
//  LSWearable
//
//  Created by Wenzheng Zhang on 2017/9/22.
//  Copyright © 2017年 lifesense. All rights reserved.
//

#ifndef LSWAppAppearanceConfigrationConstants_h
#define LSWAppAppearanceConfigrationConstants_h

typedef NS_ENUM(NSUInteger, LSWNavigationBarStyle) {
    LSWNavigationBarStyleDefalut, //默认样式
    LSWNavigationBarStyleLight, //白色样式
    LSWNavigationBarStyleDark, // 黑色
};

#endif /* LSWAppAppearanceConfigrationConstants_h */
