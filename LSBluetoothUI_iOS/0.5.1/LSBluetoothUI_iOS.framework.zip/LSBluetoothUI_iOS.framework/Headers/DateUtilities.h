//
//  DateUtilities.h
//  LSPedometer
//
//  Created by Qinmei on 14-7-24.
//  Copyright (c) 2014年 LS. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

typedef NS_ENUM(NSUInteger, LSWYearAndDayFormat) {
    LSWYearAndDayFormatC,  // yyyy年MM月dd日-yyyy年MM月dd日
    LSWYearAndDayFormatP,  // yyyy.MM.dd-yyyy.MM.dd
};

@interface DateUtilities : NSObject

+ (NSString *)monthWithMonthIndex:(NSInteger)monthIndex;

+ (NSString *)dayAndHourFromDate:(NSDate *)fromDate toDate:(NSDate *)date;
+ (NSString *)yearAndDayFromDate:(NSDate *)fromDate toDate:(NSDate *)toDate format:(LSWYearAndDayFormat)format;

+ (NSString *)hourAndMinFromDate:(NSDate *)fromDate toDate:(NSDate *)toDate;

+ (NSInteger)ageFromDate:(NSDate *)date;

//+ (NSInteger)currentAge;

+ (NSString *)ACChartWeekStrFromDate:(NSDate *)date;
/**
 有氧运动图表的格式

 @param date 时间
 @return str
 */
+ (NSString *)ACChartDayAndHourStrFromDate:(NSDate *)date;

+ (NSString *)dayAndHourStrFromDate:(NSDate *)date;
/**
 返回时间 如今天，昨天，或日期，如果是去年的则加上年份
 
 @param date 日期
 @return 时间 (MM月dd日)
 */
+ (NSString *)dayNameFromDate:(NSDate *)date;

+ (NSString *)dayNameFromDate:(NSDate *)date isChart:(BOOL)ischart needYear:(BOOL)needYear;

+ (NSString *)weekStrFromDate:(NSDate *)date isChart:(BOOL)ischart needYear:(BOOL)needYear;

+ (NSString *)weekNameWithYearFromDate:(NSDate *)date;

+ (NSString *)monthDayNameFromDate:(NSDate *)date;

/**
 返回时间
 
 @param date 如本周，上周
 @return 时间 （MM月dd日-MM月dd日）
 */
+ (NSString *)weekNameFromDate:(NSDate *)date;


/**
 返回时间

 @param date 如本周，上周，yyyy年MM月dd日-yyyy年MM月dd日
 @return 时间（yyyy年MM月dd日-yyyy年MM月dd日）
 */
+ (NSString *)weekStrFromDate:(NSDate *)date;

// 判断日期是否是当日
+ (BOOL)timeIntervalIsCurrentDay:(NSDate *)date;


+ (NSString *)weekIgnoreYearNameCompareToday:(NSDate *)date;

+ (NSString *)timeDescriptionTextFromDate:(NSDate *)fromDate toDate:(NSDate *)toDate;

//返回富文本...
+ (NSMutableAttributedString *)attributedTimeToHourAndMin:(float)minTime numberFont:(UIFont *)numberFont numberColor:(UIColor *)numberColor unitFont:(UIFont *)unitFont unitColor:(UIColor *)unitColor hideZeroHour:(BOOL)hideZeroHour;
@end
