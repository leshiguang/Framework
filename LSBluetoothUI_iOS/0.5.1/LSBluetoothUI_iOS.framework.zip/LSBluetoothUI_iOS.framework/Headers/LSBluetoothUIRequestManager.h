//
//  LSWHomePageRequestManager.h
//  LSWearable
//
//  Created by pengpeng on 2019/9/9.
//  Copyright © 2019 lifesense. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void(^LSBluetoothUIRequestBlock)(LSBaseResponse* response);

@interface LSBluetoothUIRequestManager : NSObject

+ (instancetype)shareInstance;

/// 同步用户信息
/// @param userInfo 用户信息
/// @param completeBlock 同步结果回调
- (void)requestUpdateUserInfo:(LSBluetoothUIUserInfo *)userInfo complete:(LSBluetoothUIRequestBlock)completeBlock;

- (void)downConfigJson:(LSBluetoothUIRequestBlock)completeBlock;
@end
