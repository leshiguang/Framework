//
//  LSBluetoothUI.h
//  LSBluetoothUI_iOS
//
//  Created by tanjian on 2021/2/8.
//

#import <Foundation/Foundation.h>
#import <LSBluetoothUI_iOS/LZMediator.h>
#import <LSBluetoothUI_iOS/LSDevice.h>
#import <LSBluetoothUI_iOS/LSDeviceManagerDelegate.h>
#import <LSBluetoothUI_iOS/LSReceiveDataHeader.h>
#import <LZBluetooth/LZBluetooth.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, LSPage) {
    /// 步数页面
    LSPageStep,
    /// 血压页面
    LSPageBloodPressure,
    /// 心率
    LSPageHr,
    /// 体重
    LSPageWeight,
    /// 睡眠
    LSPageSleep,
    /// 设备列表
    LSPageDeviceList,
    /// 血糖
    LSPageBloodSugar,
    /// 顾问中心
    LSPageConsultantCenter,
    
};


typedef void (^LSJBResponseCallback)(id responseData);
typedef void (^LSJBHandler)(id _Nullable data, LSJBResponseCallback responseCallback);

/// js bridge 的乔接名称
typedef NSString *LSJBName;

/// 分享小程序的乔接口名称 { imageUrl: "imageUrl", scene: 0, // 类型number， 0: 微信好友 1:朋友圈 2:收藏 }
extern LSJBName LSJBShareWxminiProgramName;

/// 分享微信图片的乔接口名称
/**
 {
     "title":"",   //小程序标题
     "desc":"",     //小程序描述
     "thumbUrl":"",     //兼容旧版本节点的图片，小于32KB，新版本优先使用WXMiniProgramObject的hdImageData属性
     "webpageUrl":"",    //兼容低版本的网页链接
     "userName":"",     //小程序的userName,备注:小程序原始ID获取方法：登录小程序管理后台-设置-基本设置-帐号信息
     "path":"",   //小程序的页面路径
     "hdImageUrl":"",   //小程序新版本的预览图Url，6.5.9及以上版本微信客户端支持。备注：限制大小不超过128KB，自定义图片建议长宽比是 5:4。
     "withShareTicket":"",   //是否使用带shareTicket的分享
     "miniprogramType":""   //小程序的类型，默认正式版，1.8.1及以上版本开发者工具包支持分享开发版和体验版小程序。 1是正式版，2是测试版，3是体验版
 }
 */
extern LSJBName LSJBShareWxImageName;

/// 保存图片到本地的图片 参数 {imageUrl: "xxx"}
extern LSJBName LSJBSaveLocalImageName;

/// 配置
@interface LSBluetoothUIConfig : NSObject

/// 租户ID，用来隔离数据和服务，公司唯一
@property (nonatomic, strong) NSString *appKey;
/// 订阅ID，标识订阅的服务和隔离数据，应用唯一
@property (nonatomic, strong) NSString *appSecret;
/// 渠道
@property (nonatomic, strong) NSString *tn;
/// app类型，标示app的类型，公司可能有多个
@property (nonatomic, strong) NSString *appType;
/// 是否打印日志，及是否显示vConsole
@property (nonatomic, assign, getter=isDebug) BOOL debug;

/// 如果你使用微信分享，则需要设置， 并且需要引入 LZShareKit
@property (nonatomic, strong, nullable) NSString *wxAppid;

/// 如果你使用微信分享，则需要设置，并且需要引入 LZShareKit
@property (nonatomic, strong, nullable) NSString *wxUniversalLink;

@end

@interface LSBluetoothUI : NSObject

/// 初始化只能调用一次（多次无效）
/// @param config 初始化
+ (void)initWithConfig:(LSBluetoothUIConfig *)config;

/// 登陆用户id（主要作用是标示用户的）
/// @param associatedId 用户id
/// @param completion 回调
+ (void)loginWithAssociatedId:(NSString *)associatedId completion:(void(^)(BOOL result))completion;

/// 用户退出的时候调用
+ (void)logout;

/// 直接跳转某页面，会获取到[UIApplication sharedApplication].delegate.window 上的nav然后push
/// @param page 页面类型
+ (void)openPage:(LSPage)page;

/// 通过页面类型获取到对应的viewController
/// @param page 页面类型
+ (UIViewController *)viewControllerWithPage:(LSPage)page;

/// 只有登陆的情况下才能获取到已绑定设备
+ (nullable NSArray <LSDevice *> *)getBoundDevices;

/// 设置代理
/// @param delegate 代理
+ (void)addDelegate:(id<LSDeviceManagerDelegate>)delegate;

/// 删除代理
/// @param delegate 代理
+ (void)removeDelegate:(id<LSDeviceManagerDelegate>)delegate;


/// 设置到手环
/// @param setting 设置项
/// @param device 设备
/// @param completion 回调
+ (void)setSetting:(id<LZDeviceSettingProtocol>)setting device:(LSDevice *)device completion:(void(^)(LZBluetoothErrorCode code))completion;

/// 如果包含分享，需要在appdelegate
+ (BOOL)handleUrl:(NSURL *)url;

/// 处理UniversalLink回调
+ (BOOL)handleOpenUniversalLink:(NSUserActivity *)userActivity;

/// 注册桥接口
/// @param handlerName 乔接口名称
/// @param handler 回调， 如果你想回调给js， 需要调用responseCallback(data);
+ (void)registerHandler:(LSJBName)handlerName handler:(LSJBHandler)handler;

/// 版本号
+ (NSString *)version;

@end

NS_ASSUME_NONNULL_END
