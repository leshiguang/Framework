//
//  NSString+LSWNavigationBarExport.h
//  LSWearable
//
//  Created by Wenzheng Zhang on 2017/3/23.
//  Copyright © 2017年 lifesense. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (LSWNavigationBarExport)
- (nullable NSString *)LSWNBE_toLocalImageName;
- (nullable NSURL *)LSWNBE_toImageUrl;
@end
