//
//  ZWZLoadMoreControl.h
//  ZWZLoadMoreControlDemo
//
//  Created by wenZheng Zhang on 16/1/5.
//  Copyright © 2016年 ZWZ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZWZLoadMoreControlFailedViewProtocol.h"

@class ZWZLoadMoreControl;

@protocol ZWZLoadMoreControlDataSource <NSObject>
@required
- (UIView *)idelViewForLoadMoreControl:(ZWZLoadMoreControl *)loadMoreControl;
- (UIView *)loadingViewForLoadMoreControl:(ZWZLoadMoreControl *)loadMoreControl;
- (UIView *)loadedViewForLoadMoreControl:(ZWZLoadMoreControl *)loadMoreControl;
- (UIView *)failedViewForLoadMoreControl:(ZWZLoadMoreControl *)loadMoreControl;
@end

@protocol ZWZLoadMoreControlDelegate <NSObject>
@optional
- (void)loadMoreControlDidTriggerLoading:(ZWZLoadMoreControl *)loadMoreControl;
@end

@interface ZWZLoadMoreControl : UIView
@property (nonatomic, weak) id <ZWZLoadMoreControlDataSource> dataSource;
@property (nonatomic, weak) id <ZWZLoadMoreControlDelegate> delegate;
@property (nonatomic) BOOL enabled;
@property (nonatomic) BOOL triggerLoadingWhenContentSizeSmallerThanScrollViewFrameSize;
@property (nonatomic, assign, readonly) BOOL causeByContentInset;


- (instancetype)initWithScrollView:(UIScrollView *)scrollView;
- (instancetype)initWithScrollView:(UIScrollView *)scrollView frame:(CGRect)frame;

- (void)scrollViewDidScroll:(UIScrollView *)scrollView;
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView;
- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate;

/**
 *  成功完成一页加载，但是没有加载完全部数据
 *
 *  @param scrollView scrollView
 */
- (void)scrollViewDataSourceDidFinishedLoading:(UIScrollView *)scrollView;

/**
 *  加载一页数据失败
 *
 *  @param scrollView scrollView
 */
- (void)scrollViewDataSourceDidFailedLoading:(UIScrollView *)scrollView;

/**
 *  成功完成全部数据加载，此view会一直停留在底部，并且不会再触发加载更多数据的回调
 *
 *  @param scrollView scrollView
 */
- (void)scrollViewDataSourceDidLoadAllData:(UIScrollView *)scrollView;


/*!
 *  Must call this method before the related scrollView deallocted
 */
- (void)cleanUp;
@end
