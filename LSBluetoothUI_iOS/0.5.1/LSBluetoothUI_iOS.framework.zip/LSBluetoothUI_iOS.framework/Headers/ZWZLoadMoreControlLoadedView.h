//
//  ZWZLoadMoreControlLoadedView.h
//  ZWZLoadMoreControlDemo
//
//  Created by wenZheng Zhang on 16/1/5.
//  Copyright © 2016年 ZWZ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZWZLoadMoreControlLoadedView : UIView

@end
