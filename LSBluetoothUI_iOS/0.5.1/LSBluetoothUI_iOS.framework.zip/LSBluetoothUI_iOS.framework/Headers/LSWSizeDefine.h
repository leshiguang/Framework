//
//  LSWSizeDefine.h
//  LSWearable
//
//  Created by 彭鹏 on 2019/5/22.
//  Copyright © 2019 lifesense. All rights reserved.
//

#ifndef LSWSizeDefine_h
#define LSWSizeDefine_h


#endif /* LSWSizeDefine_h */
