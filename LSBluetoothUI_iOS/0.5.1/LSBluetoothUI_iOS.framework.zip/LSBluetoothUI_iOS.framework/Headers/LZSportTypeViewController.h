//
//  LZSportTypeViewController.h
//  LSBluetoothUI_iOS
//
//  Created by wm on 2020/12/8.
//

#import "LZDeviceManagerViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface LZSportTypeViewController : LZDeviceManagerViewController

@end

NS_ASSUME_NONNULL_END
