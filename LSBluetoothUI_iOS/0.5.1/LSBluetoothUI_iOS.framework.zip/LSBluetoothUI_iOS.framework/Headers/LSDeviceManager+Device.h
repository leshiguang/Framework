//
//  LSDeviceManager+Device.h
//  LSDeviceManager
//
//  Created by tanjian on 2020/12/23.
//

#import "LSDeviceManager.h"

NS_ASSUME_NONNULL_BEGIN

@class LSDeviceUser;
@class LSEManufacturerInfo;
@class LSDevice;

typedef void(^LSEManufacturerInfoBlock)(LSEManufacturerInfo * _Nullable manufacturerInfo, NSInteger code, NSString *msg );

@interface LSDeviceManager (Device)



/// 设置活跃设备
/// @param deviceId 设备id
/// @param completion 回调
- (void)setActiveDevice:(NSString *)deviceId completion:(void(^)(int code, NSString *msg))completion;



/// 获取设备信息
/// @param deviceId 设备id
- (LSDevice *)getDeviceInfo:(NSString *)deviceId;

- (void)dealActiveDeviceData:(NSArray *)data;


@end

NS_ASSUME_NONNULL_END
