//
//  NSURL+LSAddition.h
//  LSWearable
//
//  Created by ZhangWenzheng on 16/4/13.
//  Copyright © 2016年 lifesense. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSURL (LSAddition)
/**
 *  在图片文件url上拼接上图片裁剪参数，如果已经存在图片裁剪参数，则更新图片裁剪参数
 *
 *  @param height  图片高度
 *  @param width   图片宽度
 *  @param quality 图片质量
 *
 *  @return 如果成功则返回拼接上参数的url，否则返回原url
 */
- (NSURL *)ls_urlByAppendingImageCropingParameterWithHeight:(NSInteger)height width:(NSInteger)width quality:(NSInteger)quality;

/**
 *  在图片文件url上拼接上图片裁剪参数，如果已经存在图片裁剪参数，则更新图片裁剪参数
 *
 *  @note 裁剪的图片质量为100
 *
 *  @param height 图片高度
 *  @param width  图片宽度
 *
 *  @return 如果成功则返回拼接上参数的url，否则返回原url
 */
- (NSURL *)ls_urlByAppendingImageCropingParameterWithHeight:(NSInteger)height width:(NSInteger)width;


/**
 使用string构建NSURL，会对string适当编码

 @param string string
 @return NSURL实例
 */
+ (instancetype)ls_URLWithString:(NSString *)string;
@end
