//
//  ZWZCollectionViewWaterfallLayout.h
//  CollectionViewPlay
//
//  Created by wenZheng Zhang on 4/23/15.
//  Copyright (c) 2015 ZWZ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZWZWaterFallCollectionViewGlobalViewLayoutAttributes.h"

@class ZWZCollectionViewWaterfallLayout;

@protocol ZWZCollectionViewWaterfallLayoutDelegate <NSObject>

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(ZWZCollectionViewWaterfallLayout *)collectionViewLayout sizeForHeaderAtIndexPath:(NSIndexPath *)indexPath;
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(ZWZCollectionViewWaterfallLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath;

@optional
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(ZWZCollectionViewWaterfallLayout *)collectionViewLayout sizeForGlobalHeaderAtIndexPath:(NSIndexPath *)indexPath;

@end

@interface ZWZCollectionViewWaterfallLayout : UICollectionViewLayout

/**
 *  @brief How many columns for this layout.
 *  @discussion Default: 2
 */
@property (nonatomic, assign) NSInteger columnCount;

/**
 *  @brief The minimum spacing to use between successive columns.
 *  @discussion Default: 10.0
 */
@property (nonatomic, assign) CGFloat minimumColumnSpacing;

/**
 *  @brief The minimum spacing to use between items in the same column.
 *  @discussion Default: 10.0
 *  @note This spacing is not applied to the space between header and columns or between columns and footer.
 */
@property (nonatomic, assign) CGFloat minimumInteritemSpacing;

/**
 *  @brief The margins that are used to lay out the header for each section.
 *  @discussion
 *    These insets are applied to the headers in each section.
 *    They represent the distance between the top of the collection view and the top of the content items
 *    They also indicate the spacing on either side of the header. They do not affect the size of the headers or footers themselves.
 *
 *    Default: UIEdgeInsetsZero
 */
@property (nonatomic) UIEdgeInsets globalHeaderInset;

/**
 *  @brief The margins that are used to lay out the header for each section.
 *  @discussion
 *    These insets are applied to the headers in each section.
 *    They represent the distance between the top of the collection view and the top of the content items
 *    They also indicate the spacing on either side of the header. They do not affect the size of the headers or footers themselves.
 *
 *    Default: UIEdgeInsetsZero
 */
@property (nonatomic, assign) UIEdgeInsets sectionHeaderInset;


@property (nonatomic) CGFloat itemLeadingSpace;
@property (nonatomic) CGFloat itemTrailingSpace;


@property (nonatomic, getter=isEnableStickySectionHeaders) BOOL enableStickySectionHeaders;
@property (nonatomic, getter=isEnablePinGlobalHeader)     BOOL enablePinGlobalHeader;
@property (nonatomic, getter=isEnableGlobalHeader)  BOOL enableGlobalHeader;
@property (nonatomic, getter=isEnableStrechyHeader) BOOL enableStrechyGlobalHeader;
@property (nonatomic, getter=isAllowScrollingWhenContentSizeSmallerThanScreenSize) BOOL allowScrollingWhenContentSizeSmallerThanScreenSize;


@property (nonatomic, weak) id <ZWZCollectionViewWaterfallLayoutDelegate> delegate;

@end
