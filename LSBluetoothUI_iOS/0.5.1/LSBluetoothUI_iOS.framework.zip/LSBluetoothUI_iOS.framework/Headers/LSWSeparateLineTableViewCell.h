//
//  LSWSeparateLineTableViewCell.h
//  LSWearable
//
//  Created by malai on 2016/12/8.
//  Copyright © 2016年 lifesense. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LSWTableViewCellSeperateLineProtocol.h"

typedef NS_ENUM(NSUInteger, LSWSeparateLineTableViewCellRoundedCornerDirection) {
    LSWSeparateLineTableViewCellRoundedCornerDirectionNone,
    LSWSeparateLineTableViewCellRoundedCornerDirectionTop,
    LSWSeparateLineTableViewCellRoundedCornerDirectionBottom
};

@interface LSWSeparateLineTableViewCell : UITableViewCell <LSWTableViewCellSeperateLineProtocol>

@property (nonatomic, assign) UIEdgeInsets lsw_edgeInsets;
@property (nonatomic, assign) LSWSeparateLineTableViewCellRoundedCornerDirection roundedCornerDirection;

@end
