//
//  LZA6SettingResultData.h
//  LZBluetooth
//
//  Created by tanjian on 2020/10/12.
//

#import <Foundation/Foundation.h>
#import <LZBluetooth/LZA6Data.h>

NS_ASSUME_NONNULL_BEGIN

@interface LZA6SettingResultData : LZA6Data

@property (nonatomic, assign) UInt16 settingCmd;
@property (nonatomic, assign) BOOL isSuccess;

@end

NS_ASSUME_NONNULL_END
