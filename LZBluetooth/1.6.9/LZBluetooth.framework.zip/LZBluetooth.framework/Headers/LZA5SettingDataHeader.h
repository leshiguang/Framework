//
//  LZA5SettingDataHeader.h
//  LZBluetooth
//
//  Created by tanjian on 2020/11/17.
//  所有的app push到a5的数据模型

#import <LZBluetooth/LZA5SettingMessageReminderData.h>
#import <LZBluetooth/LZA5SettingAutoRecognitionSportData.h>
#import <LZBluetooth/LZA5SettingAlarmClockData.h>
#import <LZBluetooth/LZA5SettingDialTypeData.h>
#import <LZBluetooth/LZA5SettingScreenDirectionData.h>
#import <LZBluetooth/LZA5SettingEventRemindData.h>
#import <LZBluetooth/LZA5SettingGpsData.h>
#import <LZBluetooth/LZA5SettingCustomSportHRSectionReminderData.h>
#import <LZBluetooth/LZA5SettingHRSectionData.h>
#import <LZBluetooth/LZA5SettingSmartHRDetectionData.h>
#import <LZBluetooth/LZA5SettingHeartrateDetectionData.h>
#import <LZBluetooth/LZA5SettingLanguageData.h>
#import <LZBluetooth/LZA5SettingUnitData.h>
#import <LZBluetooth/LZA5SettingSedentaryReminderData.h>
#import <LZBluetooth/LZA5SettingLostData.h>
#import <LZBluetooth/LZA5SettingNightModeData.h>
#import <LZBluetooth/LZA5SettingCustomScreenData.h>
#import <LZBluetooth/LZA5SettingNoDisturbData.h>
#import <LZBluetooth/LZA5SettingSportControlData.h>
#import <LZBluetooth/LZA5SettingSportHRSectionData.h>
#import <LZBluetooth/LZA5SettingPaceAndDistanceData.h>
#import <LZBluetooth/LZA5SettingEncourageData.h>
#import <LZBluetooth/LZA5SettingEncourageTargetData.h>
#import <LZBluetooth/LZA5SettingSwimParamsData.h>
#import <LZBluetooth/LZA5SettingTimeModeData.h>
#import <LZBluetooth/LZA5SettingWristHabitData.h>
#import <LZBluetooth/LZWeatherData.h>
#import <LZBluetooth/LZA5SettingRealTimeHeartRateSwitchData.h>

#import <LZBluetooth/LZA5SettingUserInfoData.h>


