//
//  LZA5SettingCallReminderData.h
//  LZBluetooth
//
//  Created by tanjian on 2020/10/22.
//  APP push 来电提醒设置到蓝牙手环(0x6A)

#import <Foundation/Foundation.h>
#import <LZBluetooth/LZA5SettingData.h>

NS_ASSUME_NONNULL_BEGIN

/// Push来电提醒设置类型
typedef NS_ENUM(NSUInteger, LZA5CallReminderType) {
    /// 来电提醒
    LZA5CallReminderTypeDefault = 1,
    /// 消息提醒
    LZA5CallReminderTypeMsg = 2,
    /// 断连提醒
    LZA5CallReminderTypeLost = 3,
    /// 短信提醒
    LZA5CallReminderTypeSMS = 4,
    /// 微信提醒
    LZA5CallReminderTypeWX = 5,
    /// QQ提醒
    LZA5CallReminderTypeQQ = 6,
    /// Facebook提醒
    LZA5CallReminderTypeFacebook = 7,
    /// Twitter提醒
    LZA5CallReminderTypeTwitter = 8,
    /// Line提醒
    LZA5CallReminderTypeLine = 9,
    /// Gmail提醒
    LZA5CallReminderTypeGmail = 0x0a,
    /// KakaoTalk提醒
    LZA5CallReminderTypeKakaoTalk = 0x0b,
    /// WhatsApp提醒
    LZA5CallReminderTypeWhatsApp = 0x0c,
    
//    LZA5CallReminderTypeSEWellness = 253,
    /// SE Wellness提醒
    LZA5CallReminderTypeSEWellness = 0xfe,
    
};

/// APP push 来电提醒设置到蓝牙手环(0x6A)
@interface LZA5SettingCallReminderData : LZA5SettingData

/// 消息类型
@property (nonatomic, assign) LZA5CallReminderType reminderType;
/// 开关
@property (nonatomic, assign) BOOL enable;
/// 延时时间 (s)
@property (nonatomic, assign) UInt8 delay;
/// 震动类型
@property (nonatomic, assign) LZA5VibrationType vibrationType;
/// 震动时长 (s)
@property (nonatomic, assign) UInt8 vibrationTime;
/// 震动等级1（0～9）
@property (nonatomic, assign) UInt8 vibrationLevel1;
/// 震动等级2（0～9）
@property (nonatomic, assign) UInt8 vibrationLevel2;

@end

NS_ASSUME_NONNULL_END
