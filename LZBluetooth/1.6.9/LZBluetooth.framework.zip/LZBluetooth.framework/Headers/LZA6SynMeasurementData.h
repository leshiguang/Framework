//
//  LZA6SynMeasurementData.h
//  LZBluetooth
//
//  Created by tanjian on 2020/10/12.
//

#import <Foundation/Foundation.h>
#import <LZBluetooth/LZA6Data.h>

NS_ASSUME_NONNULL_BEGIN

@interface LZA6SynMeasurementData : LZA6Data

@property (nonatomic, assign) UInt8 userNumber;
@property (nonatomic, assign) BOOL allow;

@end

NS_ASSUME_NONNULL_END
