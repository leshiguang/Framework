//
//  LZA6BpMeasurementData.h
//  LZBluetooth
//
//  Created by tanjian on 2020/12/8.
//

#import <LZBluetooth/LZA6Data.h>
#import <LZBluetooth/LZA6CommonDefine.h>
#import <LZBluetooth/LZMeasurementDataProtocol.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_OPTIONS(UInt32, LZA6BloodPressureFlag) {
    /// 单位标志位
    LZA6BloodPressureFlagUnit        = 1 << 0,
    /// 数据包中包含心率
    LZA6BloodPressureFlagPulserate      = 1 << 1,
    /// 数据中是否包含用户信息
    LZA6BloodPressureFlagUserid         = 1 << 2,
    /// 用户信息是否有utc
    LZA6BloodPressureFlagUtc            = 1 << 3,
//    LZA6BloodPressureFlagTimezone       = 1 << 4,
//    LZA6BloodPressureFlagTimestamp      = 1 << 5,
    LZA6BloodPressureFlagIrregularPulseDetection = 1 << 6,
};



@interface LZA6BpMeasurementData : LZA6Data <LZMeasurementDataProtocol>

/// 传输完本数据包后设备中的剩余数据条目。
@property (nonatomic, assign) UInt16 remainingCount;

@property (nonatomic, assign) LZA6BloodPressureFlag flags;

@property (nonatomic, assign) LZA6BloodPressureUnit unit;

/// 高压数据，以mmHg上传，根据unit flag的定义进行显示
@property (nonatomic, assign) UInt16 systolic;

/// 低压数据，以mmHg上传，根据unit flag的定义进行显示
@property (nonatomic, assign) UInt16 diastolic;

/// 平均值数据，以mmHg上传，根据unit flag的定义进行显示
@property (nonatomic, assign) UInt16 meanPressure;

/// 脉搏数据
@property (nonatomic, assign) UInt16 pulseRate;

/// 用户编号1表示用户1  2表示用户2
@property (nonatomic, assign) UInt16 userID;

/// 时间戳
@property (nonatomic, assign) UInt32 utc;

//@property (nonatomic, assign) UInt8 timezone;

/// [0]:year低位 [1]:year高位 [2]:month [3]:day [4]:hour [5]:minite [6]:second
//@property (nonatomic, strong) NSData *timestamp;

///// 0:未检测到体动信号 1:检测到体动信号
//@property (nonatomic, assign) BOOL bodyMovementDetection;
//
///// 0:未检测袖带绑的不理想 1:检测到袖带绑的不理想
//@property (nonatomic, assign) BOOL cuffFitDetection;

/// 0:未检测到心率不齐 1:检测到心率不齐
@property (nonatomic, assign) BOOL irregularPulseDetection;

/// 0:手势位置正确 1:手势位置不正确
//@property (nonatomic, assign) UInt8 measurementPositionDetection;


@end

NS_ASSUME_NONNULL_END
