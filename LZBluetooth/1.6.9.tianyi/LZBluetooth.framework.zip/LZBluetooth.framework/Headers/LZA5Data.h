//
//  LZA5Data.h
//  LZBluetooth
//
//  Created by tanjian on 2020/10/21.
//

#import <Foundation/Foundation.h>


NS_ASSUME_NONNULL_BEGIN

@interface LZA5Data : NSObject

@end

NS_ASSUME_NONNULL_END
