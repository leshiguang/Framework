//
//  LZA5SettingWeatherData.h
//  LZBluetooth
//
//  Created by tanjian on 2020/10/22.
//  天气信息到手环(0xA6)

#import <Foundation/Foundation.h>
#import <LZBluetooth/LZA5SettingData.h>

NS_ASSUME_NONNULL_BEGIN

//0x00 晴(白天);
//0x01 晴(夜晚);
//0x02 多云;
//0x03 晴间多云(白天);
//0x04 晴间多云(夜晚);
//0x05 大部多云(白天);
//0x06 大部多云(夜晚);
//0x07 阴;
//0x08 阵雨;
//0x09 雷阵雨;
//0x0A 冰雹或雷阵雨伴有冰雹;
//0x0B 小雨;
//0x0C 中雨;
//0x0D 大雨;
//0x0E 暴雨;
//0x0F 大暴雨;
//0x10 特大暴雨;
//0x11 冻雨;
//0x12 雨夹雪;
//0x13 阵雪;
//0x14 小雪;
//0x15 中雪;
//0x16 大雪;
//0x17 暴雪;
//0x18 浮尘;
//0x19 扬沙;
//0x1A 沙尘暴;
//0x1B 强沙尘暴;
//0x1C 雾;
//0x1D 霾;
//0x1E 风;
//0x1F 大风;
//0x20 飓风;
//0x21 热带风暴;
//0x22 龙卷风;

/// 天气详情
@interface LZA5SettingWeatherContentData : NSObject
/// 天气气象代码
@property (nonatomic, assign) UInt8 weatherCode;
/// 温度范围1 °C
@property (nonatomic, assign) int8_t temperature1;
/// 温度范围2 °C
@property (nonatomic, assign) int8_t temperature2;
/// AQI
@property (nonatomic, assign) UInt16 aqi;

@end

/// 天气信息
@interface LZA5SettingWeatherData : LZA5SettingData
/// 天气更新的时间戳
@property (nonatomic, assign) UInt32 utc;
/// 天气列表（每天的天气预报）
@property (nonatomic, strong) NSArray <LZA5SettingWeatherContentData *> *contentDatas;

@end

NS_ASSUME_NONNULL_END
