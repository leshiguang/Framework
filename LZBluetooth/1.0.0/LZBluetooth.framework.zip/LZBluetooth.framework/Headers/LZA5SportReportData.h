//
//  LZA5SportModeData.h
//  LZBluetooth
//
//  Created by tanjian on 2020/10/22.
//  手环发送运动报告数据到 APP(0xE2)

#import <Foundation/Foundation.h>
#import <LZBluetooth/LZA5CommonDefine.h>
#import <LZBluetooth/LZBraceletMeasurementData.h>
#import <LZBluetooth/LZA5TimeStateData.h>

NS_ASSUME_NONNULL_BEGIN

@interface LZA5SportReportData : LZBraceletMeasurementData
/// 运动模式
@property (nonatomic, assign) LZA5SportMode mode;
/// 是否手动发起
@property (nonatomic, assign) LZA5SportSubMode subMode;
/// bit0 为1是 表示有最大步频 平均步频
@property (nonatomic, assign) UInt32 flags;
/// 暂停次数
@property (nonatomic, assign) UInt8 numberOfPause;
/// 开始时间
@property (nonatomic, assign) UInt32 startUtc;
/// 时间中间暂停次数
@property (nonatomic, strong, nullable) NSArray <LZA5TimeStateData *> *timeStates;
/// 结束时间
@property (nonatomic, assign) UInt32 endUtc;
/// 单位秒
@property (nonatomic, assign) UInt16 duration;
/// 总步数，在游泳运动里面总步数代表 躺数 laps
@property (nonatomic, strong, nullable) NSNumber *totalStep;
/// 单位 Kcal
@property (nonatomic, strong, nullable) NSNumber *totalCalories;
/// 最大心率
@property (nonatomic, strong, nullable) NSNumber *maxHr;
/// 平均心率
@property (nonatomic, strong, nullable) NSNumber *avgHr;
/// 最大步频
@property (nonatomic, strong, nullable) NSNumber *maxStepFreq;
/// 平均步频
@property (nonatomic, strong, nullable) NSNumber *avgStepFreq;
/// 最大速度 单位 Km/h
@property (nonatomic, strong, nullable) NSNumber *maxSpeed;
/// 平均速度 单位 Km/h
@property (nonatomic, strong, nullable) NSNumber *avgSpeed;
/// 单位米
@property (nonatomic, strong, nullable) NSNumber *distance;

@end

NS_ASSUME_NONNULL_END
