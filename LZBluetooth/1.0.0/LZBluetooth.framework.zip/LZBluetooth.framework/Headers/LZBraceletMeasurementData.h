//
//  LZBraceletMeasurementData.h
//  LZBluetooth
//
//  Created by tanjian on 2020/12/10.
//

#import <LZBluetooth/LZA5Data.h>
#import <LZBluetooth/LZMeasurementDataProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface LZBraceletMeasurementData : LZA5Data <LZMeasurementDataProtocol>

@end

NS_ASSUME_NONNULL_END
