//
//  LZA5SettingHRSectionData.h
//  LZBluetooth
//
//  Created by tanjian on 2020/10/22.
//  心率区间到蓝牙手环(0x74)

#import <Foundation/Foundation.h>
#import <LZBluetooth/LZA5SettingData.h>

NS_ASSUME_NONNULL_BEGIN

/// 心率区间
@interface LZA5SettingHRSectionData : LZA5SettingData
/// 年龄
@property (nonatomic, assign) UInt8 age;
/// 心率区间1下限
@property (nonatomic, assign) UInt8 section1Min;
/// 心率区间1上限
@property (nonatomic, assign) UInt8 section1Max;
/// 心率区间2下限
@property (nonatomic, assign) UInt8 section2Min;
/// 心率区间2上限
@property (nonatomic, assign) UInt8 section2Max;
/// 心率区间3下限
@property (nonatomic, assign) UInt8 section3Min;
/// 心率区间3上限
@property (nonatomic, assign) UInt8 section3Max;
@end

NS_ASSUME_NONNULL_END
