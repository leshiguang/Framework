//
//  LZA5RunStateData.h
//  LZBluetooth
//
//  Created by tanjian on 2020/10/22.
//  4.3.13 手环发送跑步状态数据(0x72)

#import <Foundation/Foundation.h>
#import <LZBluetooth/LZBraceletMeasurementData.h>
#import <LZBluetooth/LZA5TimeStateData.h>

NS_ASSUME_NONNULL_BEGIN
/// 跑步状态
@interface LZA5RunStateData : LZBraceletMeasurementData
/// 暂停次数
@property (nonatomic, assign) UInt8 numberOfPause;
/// 开始时间
@property (nonatomic, assign) UInt32 startUtc;
/// 结束时间
@property (nonatomic, assign) UInt32 endUtc;
/// 总时长
@property (nonatomic, assign) UInt16 duration;
/// 总步数
@property (nonatomic, assign) UInt32 totalStep;
/// 总卡路里
@property (nonatomic, assign) UInt32 totalCalories;
/// 最大心率
@property (nonatomic, assign) UInt8 maxHr;
/// 平均心率
@property (nonatomic, assign) UInt8 avgHr;
/// 最大步频
@property (nonatomic, assign) UInt8 maxStepFreq;
/// 平均步频
@property (nonatomic, assign) UInt8 avgStepFreq;
/// 跑步过程暂停 重启的情况
@property (nonatomic, strong) NSArray <LZA5TimeStateData *> *contentDatas;

@end

NS_ASSUME_NONNULL_END
