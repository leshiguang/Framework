//
//  LZA5TimeStateData.h
//  LZBluetooth
//
//  Created by tanjian on 2020/10/27.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LZA5TimeStateData : NSObject
/// 暂停
@property (nonatomic, assign) UInt32 pauseUtc;
/// 重新开始时间戳
@property (nonatomic, assign) UInt32 reStartUtc;

+ (id)instanceWithData:(NSData *)data;

@end

NS_ASSUME_NONNULL_END
