//
//  LZA5MeasurementDataHeader.h
//  Pods
//
//  Created by tanjian on 2020/12/10.
//

#ifndef LZA5MeasurementDataHeader_h
#define LZA5MeasurementDataHeader_h

#pragma mark - 测量数据
#import <LZBluetooth/LZA5DayData.h>
#import <LZBluetooth/LZA5HeartRateData.h>
#import <LZBluetooth/LZA5HeatrateSectionData.h>
#import <LZBluetooth/LZA5NewMeasurementData.h>
#import <LZBluetooth/LZA5SleepData.h>

#pragma mark - Run
#import <LZBluetooth/LZA5RunCaloriesData.h>
#import <LZBluetooth/LZA5RunHeartrateData.h>
#import <LZBluetooth/LZA5RunStateData.h>

#pragma mark - Sport
#import <LZBluetooth/LZA5SportStatusData.h>
#import <LZBluetooth/LZA5SportReportData.h>
#import <LZBluetooth/LZA5SportPaceData.h>

#import <LZBluetooth/LZA5SportHeartrateData.h>
#import <LZBluetooth/LZA5SportCaloriesData.h>

#endif /* LZA5MeasurementDataHeader_h */
