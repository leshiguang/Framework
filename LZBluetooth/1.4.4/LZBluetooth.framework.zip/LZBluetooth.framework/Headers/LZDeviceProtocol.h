//
//  LZDeviceProtocol.h
//  LZBluetooth
//
//  Created by tanjian on 2020/9/27.
//  设备的协议

#import <LZBluetooth/LZBluetoothDefine.h>

NS_ASSUME_NONNULL_BEGIN

@class LZBatteryInfo;
@protocol LZDeviceSettingProtocol;

@protocol LZDeviceProtocol <NSObject>
/// 设备唯一id
@property (nonatomic, readonly) NSString *mac;
/// 设备id
@property (nonatomic, readonly, nullable) NSString *deviceId;
/// sn号
@property (nonatomic, readonly, nullable) NSString *sn;
/// 设备名称
@property (nonatomic, readonly) NSString *name;
/// 设备类型
@property (nonatomic, readonly) LZDeviceType deviceType;
/// 电量状态
@property (nonatomic, readonly, nullable) LZBatteryInfo *batteryInfo;
/// 设备连接状态
@property (nonatomic, readonly) LZDeviceConnectStatus connectStatus;
/// 协议
@property (nonatomic, readonly) LZProtocolType protocolType;
/// 设备信息（主要是180A服务的信息）
@property (nonatomic, readonly, nullable) NSDictionary <kLZBluetoothDeviceInfoKey, NSString *> *deviceInfo;
/// 蓝牙强度
@property (nonatomic, readonly, nullable) NSNumber *rssi;
/// 设备标识码
@property (nonatomic, readonly) NSString *identifier;

/// 像手环发送数据，必须是支持的数据
/// @param dataModel 数据模型
/// @param completion 回调
- (void)sendDataModel:(id<LZDeviceSettingProtocol>)dataModel completion:(LZSendDataCompletion)completion;

@end




NS_ASSUME_NONNULL_END
