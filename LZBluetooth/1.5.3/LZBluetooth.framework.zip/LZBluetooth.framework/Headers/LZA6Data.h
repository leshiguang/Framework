//
//  LZA6Data.h
//  LZBluetooth
//
//  Created by tanjian on 2020/10/10.
//

#import <Foundation/Foundation.h>
#import <LZBluetooth/LZA6CommonDefine.h>
#import <LZBluetooth/LZDeviceSettingProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface LZA6Data : NSObject <LZDeviceSettingProtocol>



@end

NS_ASSUME_NONNULL_END
