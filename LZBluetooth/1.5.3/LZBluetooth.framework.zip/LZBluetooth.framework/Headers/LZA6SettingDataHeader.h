//
//  LZA6SettingDataHeader.h
//  LZBluetooth
//
//  Created by tanjian on 2020/11/17.
//

#ifndef LZA6SettingDataHeader_h
#define LZA6SettingDataHeader_h

#pragma mark - Setting
#import <LZBluetooth/LZA6UserInfoSettingData.h>
#import <LZBluetooth/LZA6UnitSettingData.h>
#import <LZBluetooth/LZA6TimeSettingData.h>
#import <LZBluetooth/LZA6TargetInfoSettingData.h>
#import <LZBluetooth/LZA6DataCleanSettingData.h>
#import <LZBluetooth/LZA6FormulaSettingData.h>
#import <LZBluetooth/LZA6HearRateSwitchSettingData.h>
#import <LZBluetooth/LZWifiData.h>
#import <LZBluetooth/LZWifiScanData.h>
#import <LZBluetooth/LZWifiReset.h>
#import <LZBluetooth/LZWifiStatus.h>

#pragma mark - 测量数据
#import <LZBluetooth/LZA6MeasurementData.h>
#import <LZBluetooth/LZA6BpMeasurementData.h>

#endif /* LZA6SettingDataHeader_h */
