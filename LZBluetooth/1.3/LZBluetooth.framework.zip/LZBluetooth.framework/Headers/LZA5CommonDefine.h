//
//  LZA5CommonDefine.h
//  LZBluetooth
//
//  Created by tanjian on 2020/10/21.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/// 运动模式类型
typedef NS_ENUM(NSUInteger, LZA5SportMode) {
    /// 未指定
    LZA5SportModeUnknow = 0,
    /// 跑步
    LZA5SportModeRun = 0x01,
    /// 健走
    LZA5SportModeWalk = 0x02,
    /// 骑行
    LZA5SportModeCycling = 0x03,
    /// 游泳
    LZA5SportModeSwim = 0x04,
    /// 力量训练 （旧称 健身）
    LZA5SportModeKeepfit = 0x05,
    /// 新版跑步
    LZA5SportModeNewRun = 0x06,
    /// 室内跑（旧称 跑步机）
    LZA5SportModeRunInDoor = 0x07,
    /// 椭圆机
    LZA5SportModeElliptical = 0x08,
    /// 有氧运动
    LZA5SportModeAerobicWorkout = 0x09,
    /// 篮球
    LZA5SportModeBasketball = 0x0a,
    /// 足球
    LZA5SportModeFootball = 0x0b,
    /// 羽毛球
    LZA5SportModeBadminton = 0x0c,
    /// 排球
    LZA5SportModeVolleyball = 0x0d,
    /// 乒乓球
    LZA5SportModeTableTennis = 0x0e,
    /// 瑜伽
    LZA5SportModeYoga = 0x0f,
    /// 电竞
    LZA5SportModeGame = 0x10,
    /// 有氧能力测试12分钟跑
    LZA5SportMode12MinutesRun = 0x11,
    /// 有氧能力测试6分钟走
    LZA5SportMode6MinutesWalk = 0x12,
    /// 健身舞
    LZA5SportModeGymDance = 0x13,
    /// 太极拳
    LZA5SportModeTaiji = 0x14,
};

/// 设备信息列表
typedef NS_ENUM(NSUInteger, LZA5SettingInfoType) {
    /// 读取flash信息
    LZA5SettingInfoTypeFlash,
    /// 用户信息
    LZA5SettingInfoTypeUser,
    /// 闹钟设置信息
    LZA5SettingInfoTypeClock,
    /// 来电提醒设置信息
    LZA5SettingInfoTypeReminderCall,
    /// 心率检测设置信息
    LZA5SettingInfoTypeHrDetection,
    /// 久不动提醒设置信息
    LZA5SettingInfoTypeSedentaryRemindder,
    /// 防丢设置信息
    LZA5SettingInfoTypeLost,
};

/// 运动子模块
typedef NS_ENUM(NSUInteger, LZA5SportSubMode) {
    /// 手动进入
    LZA5SportSubModeManual = 0,
    /// 自动进入
    LZA5SportSubModeAutomatic = 1,
    /// 轨迹跑，有gps确认通知
    LZA5SportSubModeTrailrunHasGpsNotify = 2,
    /// 轨迹跑，无gps确认通知
    LZA5SportSubModeTrailrunNoGpsNotify = 3
};

/// 目标类型
typedef NS_ENUM(UInt8, LZA5TargetType) {
    /// 步数类型
    LZA5TargetTypeStep = 1,
    /// 卡路里
    LZA5TargetTypeCalories = 2,
    /// 路程
    LZA5TargetTypeDistance = 3,
    /// 运动量
    LZA5TargetTypeExerciseAmount = 4
};

/// 震动类型
typedef NS_ENUM(NSUInteger, LZA5VibrationType) {
    /// 持续震动
    LZA5VibrationTypeAlways = 0x00,
    /// 间歇震动，震动强度不变
    LZA5VibrationTypeInterval,
    /// 间歇震动，震动强度由小变大
    LZA5VibrationTypeIntervalS2L,
    /// 间歇震动，震动强度由大变小
    LZA5VibrationTypeIntervalL2S,
    /// 间歇震动，震动强度大小循环
    LZA5VibrationTypeIntervalLoop,
};

/// 重复时间
typedef NS_ENUM(UInt32, LZA5RepeatTimeFlag) {
    /// 无
    LZA5RepeatTimeFlagNon = 0,
    
    /// 星期一
    LZA5RepeatTimeFlagMon = 1 << 0,
    /// 星期二
    LZA5RepeatTimeFlagTue = 1 << 1,
    /// 星期三
    LZA5RepeatTimeFlagWed = 1 << 2,
    /// 星期四
    LZA5RepeatTimeFlagThu = 1 << 3,
    /// 星期五
    LZA5RepeatTimeFlagFri = 1 << 4,
    /// 星期六
    LZA5RepeatTimeFlagSat = 1 << 5,
    /// 星期日
    LZA5RepeatTimeFlagSun = 1 << 6,
    
    /// 全部
    LZA5RepeatTimeFlagAll = 0b1111111,
};

/// 手环测量数据类型
typedef NS_ENUM(NSUInteger, LZBraceletMeasurementDataType) {
    /// 每天测量数据 参考 LZA5DayData
    LZBraceletMeasurementDataTypeDay = 0x51,
    /// 睡眠压缩数据 参考 LZA5SleepData
    LZBraceletMeasurementDataTypeSleep = 0x52,
    /// 心率数据 参考 LZA5HeartRateData
    LZBraceletMeasurementDataTypeHeartRate = 0x53,
    /// 每小时数据 参考 LZA5DayData
    LZBraceletMeasurementDataTypeHour = 0x57,
    /// 跑步状态数据 参考 LZA5RunStateData
    LZBraceletMeasurementDataTypeRunState = 0x72,
    /// 跑步心率数据 参考 LZA5HeartRateData
    LZBraceletMeasurementDataTypeRunHeartRate = 0x73,
    /// 心率统计 参考 LZA5HeatrateSectionData
    LZBraceletMeasurementDataTypeHrSection = 0x75,
    /// 跑步卡路里数据 参考 LZA5SportCaloriesData
    LZBraceletMeasurementDataTypeRunCalories = 0x7f,
    /// 运动模式状态 参考 LZA5SportStatusData
    LZBraceletMeasurementDataTypeSportStatus = 0xe1,
    /// 运动报告 参考 LZA5SportReportData
    LZBraceletMeasurementDataTypeSportReport = 0xe2,
    /// 运动配速 参考 LZA5SportPaceData
    LZBraceletMeasurementDataTypeSportPace = 0xe4,
    /// 运动心率 参考 LZA5HeartRateData
    LZBraceletMeasurementDataTypeSportHeartRate = 0xe5,
    /// 运动卡路里 参考 LZA5SportCaloriesData
    LZBraceletMeasurementDataTypeSportCalories = 0xe6,
};

/// 手环设置数据类型
typedef NS_ENUM(NSUInteger, LZBraceletSettingType) {
    /// 消息提醒 
    LZBraceletSettingTypeMsgReminder = 0xb6,
    /// 自动识别
    LZBraceletSettingTypeAutoRecognitionSport = 0xA2,
    /// 闹钟
    LZBraceletSettingTypeAlarmClock = 0x69,
    /// 表盘
    LZBraceletSettingTypeDial = 0xa1,
    /// 佩戴方式
    LZBraceletSettingTypeScreenDirection = 0x7d,
    /// 事件提醒（带标签的闹钟提醒）
    LZBraceletSettingTypeEventReminder = 0xa3,
    /// 自定义运动心率区间提醒（心率预警）
    LZBraceletSettingTypeCustomSportHrReminder = 0xa8,
    /// 心率区间
    LZBraceletSettingTypeHrSection = 0x74,
    /// 智能心率检测开关设置
    LZBraceletSettingTypeSmartHrDetection = 0x76,
    /// 心率开关
    LZBraceletSettingTypeHrDetection = 0x6d,
    /// 语言
    LZBraceletSettingTypeLanguage = 0xaa,
    /// 久坐提醒
    LZBraceletSettingTypeSedentaryRemainder = 0x6e,
    /// 防丢
    LZBraceletSettingTypeLost = 0x6f,
    /// 夜间模式
    LZBraceletSettingTypeNightMode = 0x77,
    /// 自定义屏幕
    LZBraceletSettingTypeCustomScreen = 0x7e,
    /// 勿扰模式
    LZBraceletSettingTypeNoDisturb = 0xb3,
    /// 运动控制
    LZBraceletSettingTypeSportControl = 0xaf,
    /// 运动心率区间
    LZBraceletSettingTypeSportHrSection = 0x71,
    /// 运动设置（配速与距离设置）
    LZBraceletSettingTypePaceAndDistance = 0xab,
    /// 步数目标
    LZBraceletSettingTypeStepEncourage = 0x70,
    /// 游泳
    LZBraceletSettingTypeSwiming = 0xac,
    /// 目标设置
    LZBraceletSettingTypeTargetEncourage = 0xa5,
    /// 时间模式
    LZBraceletSettingTypeTimeMode = 0x79,
    /// 佩戴方式
    LZBraceletSettingTypeWristHabit = 0x7a,
    /// 天气
    LZBraceletSettingTypeWeather = 0xa6,
    /// 单位
    LZBraceletSettingTypeUnit = 0x78,
};

/// 获取setting类名
extern NSString *lz_braceletSettingClass(LZBraceletSettingType settingType);
NS_ASSUME_NONNULL_END
