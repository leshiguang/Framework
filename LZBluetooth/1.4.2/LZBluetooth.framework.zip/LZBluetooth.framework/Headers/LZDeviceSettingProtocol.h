//
//  LZDeviceSettingProtocol.h
//  LZBluetooth
//
//  Created by tanjian on 2021/1/15.
//

#import <Foundation/Foundation.h>
#import <LZBluetooth/LZBluetoothDefine.h>
NS_ASSUME_NONNULL_BEGIN

/// 设置项类型的协议
@protocol LZDeviceSettingProtocol <NSObject>

@property (nonatomic, readonly) LZDeviceSettingType settingType;

@end

NS_ASSUME_NONNULL_END
