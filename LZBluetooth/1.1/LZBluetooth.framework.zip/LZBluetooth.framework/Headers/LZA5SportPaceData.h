//
//  LZA5SportPaceData.h
//  LZBluetooth
//
//  Created by tanjian on 2020/10/22.
//  手环发送运动配速数据(0xE4)

#import <Foundation/Foundation.h>
#import <LZBluetooth/LZBraceletMeasurementData.h>

NS_ASSUME_NONNULL_BEGIN

/// 配速
@interface LZA5SportPaceData : LZBraceletMeasurementData
///  UTC
@property (nonatomic, assign) UInt32 utc;
/// UTC偏移量
@property (nonatomic, assign) UInt8 utcOffset;
/// 手环中 剩余条数
@property (nonatomic, assign) UInt16 reside;
/// 当前上传起始条数
@property (nonatomic, assign) UInt16 startOffset;
/// 配速数据 单位s
@property (nonatomic, strong) NSArray <NSNumber *> *contentDatas;
/// 原始数据
@property (nonatomic, strong) NSData *srcData;

@end

NS_ASSUME_NONNULL_END
