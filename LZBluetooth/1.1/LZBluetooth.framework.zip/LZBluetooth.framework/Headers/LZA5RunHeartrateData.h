//
//  LZA5RunHeartrateData.h
//  LZBluetooth
//
//  Created by tanjian on 2020/10/22.
//  手环发送跑步心率数据(0x73)

#import <LZBluetooth/LZBraceletMeasurementData.h>

NS_ASSUME_NONNULL_BEGIN
/// 跑步心率
@interface LZA5RunHeartrateData : LZBraceletMeasurementData
///  UTC
@property (nonatomic, assign) UInt32 utc;
/// 每个单位值代表5s，如:12表示心率数据 是60s 间隔采样一次
@property (nonatomic, assign) UInt8 utcOffset;
/// 数据剩余条数
@property (nonatomic, assign) UInt16 reside;
/// 当前上传数据起始条数
@property (nonatomic, assign) UInt16 startOffset;
/// 心率数据  偏移 UTC n*(UTC 偏移量)*5秒
@property (nonatomic, strong) NSArray <NSNumber *> *contentDatas;
/// 原始数据
@property (nonatomic, strong) NSData *srcData;

@end

NS_ASSUME_NONNULL_END
