//
//  LZA5HeatrateSectionData.h
//  LZBluetooth
//
//  Created by tanjian on 2020/10/22.
//  0x75 手环发送心率区间统计数据

#import <LZBluetooth/LZBraceletMeasurementData.h>

NS_ASSUME_NONNULL_BEGIN

@interface LZA5HeatrateSectionData : LZBraceletMeasurementData

@property (nonatomic, assign) UInt32 utc;
@property (nonatomic, assign) UInt16 section1Time;
@property (nonatomic, assign) UInt16 section2Time;
@property (nonatomic, assign) UInt16 section3Time;


@end

NS_ASSUME_NONNULL_END
