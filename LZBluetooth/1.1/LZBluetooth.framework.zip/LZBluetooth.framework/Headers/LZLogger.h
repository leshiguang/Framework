//
//  LZLogger.h
//  LZBluetooth
//
//  Created by tanjian on 2020/12/22.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, LZLoggerLevel) {
    /// 错误
    LZLoggerLevelError,
    /// 警告
    LZLoggerLevelWarning,
    /// 蓝牙回调
    LZLoggerLevelBluetooth,
    /// 传输层
    LZLoggerLevelTransform,
    /// 应用层
    LZLoggerLevelApplication,
    /// debug
    LZLoggerLevelDebug,
    
};

#define LZString(fmt, ...) [NSString stringWithFormat:fmt, ##__VA_ARGS__]
#define LZLog(level, msg) [LZLogger logWithLevel:level message:msg]
#define LZWarningLog(fmt, ...) LZLog(LZLoggerLevelWarning, LZString(fmt, ##__VA_ARGS__))
#define LZTransformLog(fmt, ...) LZLog(LZLoggerLevelTransform, LZString(fmt, ##__VA_ARGS__))
#define LZApplicationLog(fmt, ...) LZLog(LZLoggerLevelApplication, LZString(fmt, ##__VA_ARGS__))
#define LZBleLog(fmt, ...) LZLog(LZLoggerLevelBluetooth, LZString(fmt, ##__VA_ARGS__))

#define LZDebugLog(fmt, ...) LZLog(LZLoggerLevelDebug, LZString(fmt, ##__VA_ARGS__))


typedef void(^LZLoggerHander)(LZLoggerLevel level, NSString *msg);

@interface LZLogger : NSObject

+ (instancetype)shareInstance;

@property (nonatomic, strong, null_resettable) LZLoggerHander loggerHandler;

+ (void)logWithLevel:(LZLoggerLevel)level message:(NSString *)message;

@end

NS_ASSUME_NONNULL_END
