//
//  LZA5SportHeartrateData.h
//  LZBluetooth
//
//  Created by tanjian on 2020/10/22.
//  手环发送运动心率数据(0xE5)

#import <LZBluetooth/LZBraceletMeasurementData.h>
#import <LZBluetooth/LZA5RunHeartrateData.h>

NS_ASSUME_NONNULL_BEGIN
/// 运动心率
@interface LZA5SportHeartrateData : LZBraceletMeasurementData
/// 运动模式
@property (nonatomic, assign) LZA5SportMode mode;
/// 进入模式
@property (nonatomic, assign) LZA5SportSubMode subMode;
/// 心率数据
@property (nonatomic, strong) LZA5RunHeartrateData *hrData;

@end

NS_ASSUME_NONNULL_END
