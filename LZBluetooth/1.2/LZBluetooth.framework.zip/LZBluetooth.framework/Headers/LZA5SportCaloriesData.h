//
//  LZA5SportCaloriesData.h
//  LZBluetooth
//
//  Created by tanjian on 2020/10/22.
//  手环发送运动卡路里数据(0xE6)

#import <LZBluetooth/LZA5RunCaloriesData.h>

NS_ASSUME_NONNULL_BEGIN

/// 运动卡路里
@interface LZA5SportCaloriesData : LZBraceletMeasurementData
/// 运动模式
@property (nonatomic, assign) LZA5SportMode mode;
/// 是否自动进入
@property (nonatomic, assign) LZA5SportSubMode subMode;
/// 卡路里数据
@property (nonatomic, strong) LZA5RunCaloriesData *caloriesData;

@end

NS_ASSUME_NONNULL_END
