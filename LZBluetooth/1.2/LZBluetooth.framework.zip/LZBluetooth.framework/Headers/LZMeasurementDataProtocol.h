//
//  LZMeasurementDataProtocol.h
//  LZBluetooth
//
//  Created by tanjian on 2021/1/13.
//

#import <Foundation/Foundation.h>
#import <LZBluetooth/LZA5CommonDefine.h>

NS_ASSUME_NONNULL_BEGIN

typedef NSUInteger LZMeasurementDataType;

@protocol LZMeasurementDataProtocol <NSObject>

@property (nonatomic, readonly) LZMeasurementDataType measurementDataType;

@end

NS_ASSUME_NONNULL_END
