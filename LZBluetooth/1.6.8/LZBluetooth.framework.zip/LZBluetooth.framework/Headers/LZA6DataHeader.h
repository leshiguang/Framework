//
//  LZDataHeader.h
//  Pods
//
//  Created by tanjian on 2020/9/27.
//  数据头文件的集合

#ifndef LZDataHeader_h
#define LZDataHeader_h

#pragma mark - 特征值
#import <LZBLuetooth/LZA6FeatureData.h>

#pragma mark - 注册/绑定/登陆
#import <LZBLuetooth/LZA6BindData.h>
#import <LZBluetooth/LZA6UnbindData.h>
#import <LZBLuetooth/LZA6RegisterData.h>
#import <LZBluetooth/LZA6LoginRequestData.h>
#import <LZBluetooth/LZA6InitializeRequestData.h>

#pragma mark - Setting
#import <LZBluetooth/LZA6SettingResultData.h>
#import <LZBluetooth/LZA6UserInfoSettingData.h>
#import <LZBluetooth/LZA6UnitSettingData.h>
#import <LZBluetooth/LZA6TimeSettingData.h>
#import <LZBluetooth/LZA6TargetInfoSettingData.h>
#import <LZBluetooth/LZA6DataCleanSettingData.h>
#import <LZBluetooth/LZA6FormulaSettingData.h>
#import <LZBluetooth/LZA6HearRateSwitchSettingData.h>

#pragma mark - 测量数据
#import <LZBluetooth/LZA6SynMeasurementData.h>
#import <LZBluetooth/LZA6MeasurementData.h>
#import <LZBluetooth/LZA6BpMeasurementData.h>

#endif /* LZDataHeader_h */
