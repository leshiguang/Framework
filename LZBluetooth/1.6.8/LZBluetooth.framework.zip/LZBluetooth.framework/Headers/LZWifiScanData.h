//
//  LZA6WifiScanSettingData.h
//  LZBluetooth
//
//  Created by tanjian on 2021/1/29.
//

#import <LZBluetooth/LZDataProtocol.h>
#import <LZBluetooth/LZDeviceSettingProtocol.h>

NS_ASSUME_NONNULL_BEGIN

/// 扫描服务wifi热点
@interface LZWifiScanData : NSObject <LZDeviceSettingProtocol, LZEncodeDataProtocol>
/// Enable to scan AP whose SSID is hidden; enable (1), disable (0）
@property (nonatomic, assign) BOOL showHidden;
/// Scan type, active or passive; active (0), passive (1)
@property (nonatomic, assign) BOOL scanType;

@end


NS_ASSUME_NONNULL_END
