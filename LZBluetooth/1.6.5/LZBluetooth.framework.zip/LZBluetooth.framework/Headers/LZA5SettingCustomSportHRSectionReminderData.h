//
//  LZA5SettingCustomSportHRSectionReminderData.h
//  LZBluetooth
//
//  Created by tanjian on 2020/10/22.
//  自定义运动心率区间提醒到手环(0xA8)

#import <Foundation/Foundation.h>
#import <LZBluetooth/LZA5SettingData.h>

NS_ASSUME_NONNULL_BEGIN
/// 自定义运动心率区间
@interface LZA5SettingCustomSportHRSectionReminderData : LZA5SettingData
/// 运动心率上限
@property (nonatomic, assign) UInt8 maxHr;
/// 运动心率下限
@property (nonatomic, assign) UInt8 minHr;
/// 运动心率 提醒开关
@property (nonatomic, assign) BOOL enable;

@end

NS_ASSUME_NONNULL_END
