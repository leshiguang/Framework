//
//  LZBluetoothDefine.h
//  LZBluetooth
//
//  Created by tanjian on 2020/9/27.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/// 蓝牙状态
typedef NS_ENUM(NSUInteger, LZBluetoothState) {
    LZBluetoothStateUnknown = 0,
    /// 正在重置
    LZBluetoothStateResetting,
    /// 不支持
    LZBluetoothStateUnsupported,
    /// 未授权
    LZBluetoothStateUnauthorized,
    /// 关闭
    LZBluetoothStatePoweredOff,
    /// 打开
    LZBluetoothStatePoweredOn,
};

/// 设置数据类型
typedef NS_ENUM(NSUInteger, LZDeviceSettingType) {
    /// 消息提醒
    LZDeviceSettingTypeMsgReminder = 0xb6,
    /// 自动识别
    LZDeviceSettingTypeAutoRecognitionSport = 0xA2,
    /// 闹钟
    LZDeviceSettingTypeAlarmClock = 0x69,
    /// 表盘
    LZDeviceSettingTypeDial = 0xa1,
    /// 佩戴方式
    LZDeviceSettingTypeScreenDirection = 0x7d,
    /// 事件提醒（带标签的闹钟提醒）
    LZDeviceSettingTypeEventReminder = 0xa3,
    /// 自定义运动心率区间提醒（心率预警）
    LZDeviceSettingTypeCustomSportHrReminder = 0xa8,
    /// 心率区间
    LZDeviceSettingTypeHrSection = 0x74,
    /// 智能心率检测开关设置
    LZDeviceSettingTypeSmartHrDetection = 0x76,
    /// 心率开关
    LZDeviceSettingTypeHrDetection = 0x6d,
    /// 语言
    LZDeviceSettingTypeLanguage = 0xaa,
    /// 久坐提醒
    LZDeviceSettingTypeSedentaryRemainder = 0x6e,
    /// 防丢
    LZDeviceSettingTypeLost = 0x6f,
    /// 夜间模式
    LZDeviceSettingTypeNightMode = 0x77,
    /// 自定义屏幕
    LZDeviceSettingTypeCustomScreen = 0x7e,
    /// 勿扰模式
    LZDeviceSettingTypeNoDisturb = 0xb3,
    /// 运动控制
    LZDeviceSettingTypeSportControl = 0xaf,
    /// 运动心率区间
    LZDeviceSettingTypeSportHrSection = 0x71,
    /// 运动设置（配速与距离设置）
    LZDeviceSettingTypePaceAndDistance = 0xab,
    /// 步数目标
    LZDeviceSettingTypeStepEncourage = 0x70,
    /// 游泳
    LZDeviceSettingTypeSwiming = 0xac,
    /// 目标设置
    LZDeviceSettingTypeTargetEncourage = 0xa5,
    /// 时间模式
    LZDeviceSettingTypeTimeMode = 0x79,
    /// 佩戴方式
    LZDeviceSettingTypeWristHabit = 0x7a,
    /// 天气
    LZDeviceSettingTypeWeather = 0xa6,
    /// 单位
    LZDeviceSettingTypeUnit = 0x78,
};

/// 测量数据类型
typedef NS_ENUM(NSUInteger, LZMeasurementDataType) {
    /// 每天测量数据 参考 LZA5DayData
    LZBraceletMeasurementDataTypeDay = 0x51,
    /// 睡眠压缩数据 参考 LZA5SleepData
    LZBraceletMeasurementDataTypeSleep = 0x52,
    /// 心率数据 参考 LZA5HeartRateData
    LZBraceletMeasurementDataTypeHeartRate = 0x53,
    /// 每小时数据 参考 LZA5DayData
    LZBraceletMeasurementDataTypeHour = 0x57,
    /// 跑步状态数据 参考 LZA5RunStateData
    LZBraceletMeasurementDataTypeRunState = 0x72,
    /// 跑步心率数据 参考 LZA5HeartRateData
    LZBraceletMeasurementDataTypeRunHeartRate = 0x73,
    /// 心率统计 参考 LZA5HeatrateSectionData
    LZBraceletMeasurementDataTypeHrSection = 0x75,
    /// 跑步卡路里数据 参考 LZA5SportCaloriesData
    LZBraceletMeasurementDataTypeRunCalories = 0x7f,
    /// 运动模式状态 参考 LZA5SportStatusData
    LZBraceletMeasurementDataTypeSportStatus = 0xe1,
    /// 运动报告 参考 LZA5SportReportData
    LZBraceletMeasurementDataTypeSportReport = 0xe2,
    /// 运动配速 参考 LZA5SportPaceData
    LZBraceletMeasurementDataTypeSportPace = 0xe4,
    /// 运动心率 参考 LZA5HeartRateData
    LZBraceletMeasurementDataTypeSportHeartRate = 0xe5,
    /// 运动卡路里 参考 LZA5SportCaloriesData
    LZBraceletMeasurementDataTypeSportCalories = 0xe6,
};

/// 蓝牙协议
typedef NS_OPTIONS(NSUInteger, LZProtocolType) {
    /// 未知
    LZProtocolTypeUnknow = 0,
    /// a5协议
    LZProtocolTypeA5 = 1 << 1,
    /// a6协议
    LZProtocolTypeA6 = 1 << 2,
    /// oas协议
    LZProtocolTypeOAS = 1 << 3,
    /// 所有的协议
    LZProtocolTypeAll = LZProtocolTypeA5 | LZProtocolTypeA6 | LZProtocolTypeOAS,
};

/// 设备类型
typedef NS_ENUM(NSUInteger, LZDeviceType) {
    /// 未知
    LZDeviceUnknow,
    /// 手环
    LZDeviceTypeBracelet,
    /// 体脂秤
    LZDeviceTypeScale,
    /// 血压计
    LZDeviceTypeBloodPressure,
    /// 手表
    LZDeviceTypeWatch,
    /// alice 手环
    LZDeviceTypeAlice,
};

/// 连接状态
typedef NS_ENUM(NSUInteger, LZDeviceConnectStatus) {
    /// 未连接
    LZDeviceConnectStatusDisconnected,
    /// 正在连接中
    LZDeviceConnectStatusConnecting,
    /// 已连接
    LZDeviceConnectStatusConnected,
    /// 正在断开连接中
    LZDeviceConnectStatusDisconnecting,
};

/// 扫描时的工作状态
typedef NS_ENUM(NSUInteger, LZBluetoothScanWorkMode) {
    /// 计时器触发的自动扫描
    LZBluetoothScanWorkModeAuto,
    /// 手动调用扫描的时候
    LZBluetoothScanWorkModeManual,
};

typedef NS_ENUM(NSUInteger, LZBindState) {
    /// 输入随机数 (返回此状态,用户需要调用inputRandomCode:macString:的用户绑定手环校验随机码接口)
    LZBindStateInputRandomNumber,
    /// 确认配对 (返回此状态,用户需要调用confirmSuccess:macString:的用户确认配对接口)
    LZBindStateMatchingConfirmation,
    /// 未注册通知  体重的乐心互联才有
    LZBindStateUnregister,
    /// 请输入用户编号和绑定结果 /A6
    LZBindStateInputUserNumberAndBindResult,
    /// 绑定成功
    LZBindStateSuccessful = 4,
    /// 绑定失败
    LZBindStateFailure = 5,
    /// 鉴权失败
    LZBindStateAuthorizeFailure = 6,

};

/// 工作模式
typedef NS_ENUM(NSUInteger, LZWorkMode) {
    /// 需要断开链接
    LZWorkModeNormal = 0,
    /// 已绑定的流程
    LZWorkModeBinded = 1,
    /// 进入绑定中
    LZWorkModeBinding,
    /// ota模式
    LZWorkModeOta,
};

typedef NS_ENUM(NSUInteger, LZBluetoothErrorCode) {
    /// 没有错误
    LZBluetoothErrorCodeSuccess = 0,
    /// 未连接
    LZBluetoothErrorCodeDisconnect,
    /// 没有服务特征
    LZBluetoothErrorCodeNoCharacteristic,
    /// 设备回ack报错
    LZBluetoothErrorCodeTimeout,
    /// 丢弃或者取消
    LZBluetoothErrorCodeDiscarded,
    /// 协议ack报错
    LZBluetoothErrorCodeACKError,
    /// 蓝牙库报的错误
    LZBluetoothErrorCodeBluetoothError,
    /// 工作繁忙，比如ota升级
    LZBluetoothErrorCodeWorkingBusy,
    /// ota文件不支持
    LZBluetoothErrorCodeFileUnsupported,
    /// 低电量
    LZBluetoothErrorCodeLowBattery,
    /// 不支持类型
    LZBluetoothErrorCodeUnsupported,
    /// 鉴权失败
    LZBluetoothErrorCodeAuthorizeFailure,
    /// 未知错误
    LZBluetoothErrorCodeUnknow = 9999,
};

/// 获取setting类名
extern NSString *lz_braceletSettingClass(LZDeviceSettingType settingType);


@class LZBaseDevice;

/// 发送数据回调
typedef void(^LZSendDataCompletion)(LZBluetoothErrorCode result);
typedef void(^LZDeviceHandlerCompletion)(LZBluetoothErrorCode errorCode);
typedef void(^LZReadMacCompletion)(NSString *_Nullable mac, LZBluetoothErrorCode errorCode);
typedef void(^LZDeviceReadCharValueCompletion)(NSData * _Nullable data, LZBluetoothErrorCode errorCode);
typedef void(^LZOtaCompletion)(LZBluetoothErrorCode result);
typedef void(^LZOtaProgress)(double progress);

typedef void(^LZFindDeviceCompletion)(__kindof LZBaseDevice *_Nullable device, LZBluetoothErrorCode errorCode);
typedef void(^LZSearchResultBlock)(__kindof LZBaseDevice *device);
typedef void(^LZBindDeviceBlock)(LZBaseDevice * _Nullable device, LZBindState bindState);

/// 蓝牙错误Domain
extern NSErrorDomain const LZBluetoothErrorDomain;
extern NSString *lz_errString(LZBluetoothErrorCode errorCode);

/// 设备信息所使用的key
typedef NSString *kLZBluetoothDeviceInfoKey;

/// 设备id
extern kLZBluetoothDeviceInfoKey const kLZBluetoothDeviceInfoKeySystemID;
/// 实际产品型号
extern kLZBluetoothDeviceInfoKey const kLZBluetoothDeviceInfoKeyModelName;
/// MAC 地址
extern kLZBluetoothDeviceInfoKey const kLZBluetoothDeviceInfoKeyMacAddress;
///固件版本“*XXX” 其中第一个“*”代表下面其中的之一 “S”表示正式版， “T”表示测试版， “X”表示内测版， “XXX”是数字，表示版本号
extern kLZBluetoothDeviceInfoKey const kLZBluetoothDeviceInfoKeyFirmwareVersion;
/// 硬件版本
extern kLZBluetoothDeviceInfoKey const kLZBluetoothDeviceInfoKeyHardwareVersion;
/// 固件版本
extern kLZBluetoothDeviceInfoKey const kLZBluetoothDeviceInfoKeySoftwareVersion;
/// 制造商
extern kLZBluetoothDeviceInfoKey const kLZBluetoothDeviceInfoKeyManufacturerName;
/// 厂商id 只有a6设备 才有
extern kLZBluetoothDeviceInfoKey const kLZBluetoothDeviceInfoKeyManufactureId;
/// 算法版本
extern kLZBluetoothDeviceInfoKey const kLZBluetoothDeviceInfoKeyAlgorithmVersion;
/// 设备信息服务id
extern NSString * const LZDeviceInfoServiceUuid;


NS_ASSUME_NONNULL_END
