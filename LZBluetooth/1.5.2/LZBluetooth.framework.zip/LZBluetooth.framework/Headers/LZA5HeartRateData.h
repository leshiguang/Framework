//
//  LZA5HeartRateData.h
//  LZBluetooth
//
//  Created by tanjian on 2020/12/10.
//  发送手环心率数据(0x53 跑步心率 0x73 运动心率 0xe5)

#import <LZBluetooth/LZBraceletMeasurementData.h>

NS_ASSUME_NONNULL_BEGIN

/// 心率，measurementDataType 有三种类型 （LZBraceletMeasurementDataTypeHeartRate、LZBraceletMeasurementDataTypeRunHeartRate、LZBraceletMeasurementDataTypeSportHeartRate）
@interface LZA5HeartRateData : LZBraceletMeasurementData
/// 运动模式
@property (nonatomic, assign) LZA5SportMode sportMode;
/// 进入模式
@property (nonatomic, assign) LZA5SportSubMode subMode;
/// 时间戳
@property (nonatomic, assign) UInt32 utc;
/// 每笔心率间隔 (s)
@property (nonatomic, assign) UInt32 utcOffset;
/// 手环中 数据剩余条数
@property (nonatomic, assign) UInt16 reside;
/// 心率数据  间隔时间为 utcOffset
@property (nonatomic, strong) NSArray <NSNumber *> *heartRates;
/// 原始数据
@property (nonatomic, strong) NSData *srcData;

@end

NS_ASSUME_NONNULL_END
