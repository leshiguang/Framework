//
//  LZWIfiService.h
//  LZBluetooth
//
//  Created by tanjian on 2021/2/1.
//

#import <Foundation/Foundation.h>
#import <LZBluetooth/LZBaseProtocolManager.h>
#import <LZBluetooth/LZDeviceSettingProtocol.h>
#import <LZBluetooth/LZWifiData.h>
#import <LZBluetooth/LZWifiReset.h>
#import <LZBluetooth/LZWifiScanData.h>

NS_ASSUME_NONNULL_BEGIN

extern LZProtocolChannel const LZA6ChannelWifiResponse;
extern LZProtocolChannel const LZA6ChannelWifiWrite;



@interface LZWIfiService : LZBaseProtocolManager



@end

NS_ASSUME_NONNULL_END
