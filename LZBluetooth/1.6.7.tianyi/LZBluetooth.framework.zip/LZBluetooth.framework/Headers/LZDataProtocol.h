//
//  LZDataProtocol.h
//  LZBluetooth
//
//  Created by tanjian on 2020/9/27.
//  数据的协议

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN


/// 加密数据
@protocol LZEncodeDataProtocol <NSObject>

- (NSData *)data;

@end

/// 解密数据
@protocol LZDecodeDataProtocol <NSObject>

+ (id)instanceWithData:(NSData *)data;

@end

@protocol LZDataProtocol <LZEncodeDataProtocol, LZDecodeDataProtocol>

- (NSData *)data;
+ (id)instanceWithData:(NSData *)data;

@end

NS_ASSUME_NONNULL_END
