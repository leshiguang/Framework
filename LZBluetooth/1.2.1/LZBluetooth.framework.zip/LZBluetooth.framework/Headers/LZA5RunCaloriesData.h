//
//  LZA5RunCaloriesData.h
//  LZBluetooth
//
//  Created by tanjian on 2020/10/22.
//  跑步卡路里数据 0x7f

#import <Foundation/Foundation.h>
#import <LZBluetooth/LZBraceletMeasurementData.h>

NS_ASSUME_NONNULL_BEGIN

/// 跑步卡路里
@interface LZA5RunCaloriesData : LZBraceletMeasurementData
///  UTC
@property (nonatomic, assign) UInt32 utc;
/// UTC 偏移量每个单位值代表5s，如：12表示数据是60s 间隔采样一次
@property (nonatomic, assign) UInt8 utcOffset;
///  数据剩余条数
@property (nonatomic, assign) UInt16 numberOfLeft;
/// 当前上传数据起始条数
@property (nonatomic, assign) UInt16 startOffset;
/// 卡路里列表,每个值标识一个 UTC 偏移量时间内消耗的卡路里， utcOffset时间内消耗的卡路里 unit: cal
@property (nonatomic, strong) NSArray <NSNumber *> *contentDatas;
/// 原始数据
@property (nonatomic, strong) NSData *srcData;

@end

NS_ASSUME_NONNULL_END
