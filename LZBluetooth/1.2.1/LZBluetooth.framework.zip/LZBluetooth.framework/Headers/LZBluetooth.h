//
//  LZBluetooth.h
//  Pods
//
//  Created by tanjian on 2020/9/27.
//

#import <LZBluetooth/LZBluetoothDefine.h>
#import <LZBluetooth/LZBaseDevice.h>
#import <LZBluetooth/LZLogger.h>
#import <LZBluetooth/LZDeviceManagerProtocol.h>
#import <LZBluetooth/LZDeviceManagerDelegate.h>
#import <LZBluetooth/LZDeviceDelegate.h>
#import <LZBluetooth/LZDeviceBindDelegate.h>
#import <LZBluetooth/LZUserInfoConfig.h>
#import <LZBluetooth/LZBracelet.h>

NS_ASSUME_NONNULL_BEGIN

/// 接入步骤
/// 1、先调用initWithAppId: 方法给个apppid
/// 2、获取设备管理者getDeviceManagerWithDeviceType: 如果没有appid，你是获取不到管理者
/// 3、通过设备管理者扫描设备 绑定设备
/// 4、通过LZBaseDevice 可以发送 设置信息 可发送的数据参考 LZA5SettingDataHeader
/// 4、回调LZDeviceDelegate 可以监听设备测量数据 数据类型参考 LZBraceletMeasurementDataHeader
/// 5、如果你想打印日志可以 使用[LZLogger shareInstance].loggerHandler = ^(LZLoggerLevel level, NSString * _Nonnull msg) { NSLog(@"[%@]%@", @(level), msg); };
@interface LZBluetooth : NSObject

/// 获取多个类型设备管理器  ！！！该方法永远只会返回第一次初始化的实例
/// @param deviceTypes 设备参考 LZDeviceType
+ (id<LZDeviceManagerProtocol>)getDeviceManagerWithDeviceTypes:(NSArray <NSNumber *> * _Nullable)deviceTypes;

/// 获取单个设备管理器，获取的实例与上面的方法获取的实例一致
/// @param deviceType 设备参考 LZDeviceType
+ (id<LZDeviceManagerProtocol>)getDeviceManagerWithDeviceType:(LZDeviceType)deviceType;

/// 摧毁上述方法产生的实例
+ (void)destroy;

/// 初始化Appid
/// @param appid appid
+ (void)initWithAppId:(NSString *)appid;

/// 版本号
+ (NSString *)version;

@end

NS_ASSUME_NONNULL_END

