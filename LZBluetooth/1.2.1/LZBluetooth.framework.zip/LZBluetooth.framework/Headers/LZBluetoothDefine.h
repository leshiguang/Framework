//
//  LZBluetoothDefine.h
//  LZBluetooth
//
//  Created by tanjian on 2020/9/27.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/// 蓝牙状态
typedef NS_ENUM(NSUInteger, LZBluetoothState) {
    LZBluetoothStateUnknown = 0,
    /// 正在重置
    LZBluetoothStateResetting,
    /// 不支持
    LZBluetoothStateUnsupported,
    /// 未授权
    LZBluetoothStateUnauthorized,
    /// 关闭
    LZBluetoothStatePoweredOff,
    /// 打开
    LZBluetoothStatePoweredOn,
};

/// 蓝牙协议
typedef NS_OPTIONS(NSUInteger, LZProtocolType) {
    /// 未知
    LZProtocolTypeUnknow = 0,
    /// a5协议
    LZProtocolTypeA5 = 1 << 1,
    /// a6协议
    LZProtocolTypeA6 = 1 << 2,
    /// oas协议
    LZProtocolTypeOAS = 1 << 3,
    /// 所有的协议
    LZProtocolTypeAll = LZProtocolTypeA5 | LZProtocolTypeA6 | LZProtocolTypeOAS,
};

/// 设备类型
typedef NS_ENUM(NSUInteger, LZDeviceType) {
    /// 未知
    LZDeviceUnknow,
    /// 手环
    LZDeviceTypeBracelet,
    /// 体脂秤
    LZDeviceTypeScale,
    /// 血压计
    LZDeviceTypeBloodPressure,
    /// 手表
    LZDeviceTypeWatch,
    /// alice 手环
    LZDeviceTypeAlice,
};

/// 连接状态
typedef NS_ENUM(NSUInteger, LZDeviceConnectStatus) {
    /// 未连接
    LZDeviceConnectStatusDisconnected,
    /// 正在连接中
    LZDeviceConnectStatusConnecting,
    /// 已连接
    LZDeviceConnectStatusConnected,
    /// 正在断开连接中
    LZDeviceConnectStatusDisconnecting,
};

/// 扫描时的工作状态
typedef NS_ENUM(NSUInteger, LZBluetoothScanWorkMode) {
    /// 计时器触发的自动扫描
    LZBluetoothScanWorkModeAuto,
    /// 手动调用扫描的时候
    LZBluetoothScanWorkModeManual,
};

typedef NS_ENUM(NSUInteger, LZBindState) {
    /// 输入随机数 (返回此状态,用户需要调用inputRandomCode:macString:的用户绑定手环校验随机码接口)
    LZBindStateInputRandomNumber,
    /// 确认配对 (返回此状态,用户需要调用confirmSuccess:macString:的用户确认配对接口)
    LZBindStateMatchingConfirmation,
    /// 未注册通知  体重的乐心互联才有
    LZBindStateUnregister,
    /// 请输入用户编号和绑定结果 /A6
    LZBindStateInputUserNumberAndBindResult,
    /// 绑定成功
    LZBindStateSuccessful = 4,
    /// 绑定失败
    LZBindStateFailure = 5,
    /// 鉴权失败
    LZBindStateAuthorizeFailure = 6,

};

/// 工作模式
typedef NS_ENUM(NSUInteger, LZWorkMode) {
    /// 需要断开链接
    LZWorkModeNormal = 0,
    /// 已绑定的流程
    LZWorkModeBinded = 1,
    /// 进入绑定中
    LZWorkModeBinding,
    /// ota模式
    LZWorkModeOta,
};

typedef NS_ENUM(NSUInteger, LZBluetoothErrorCode) {
    /// 没有错误
    LZBluetoothErrorCodeSuccess = 0,
    /// 未连接
    LZBluetoothErrorCodeDisconnect,
    /// 没有服务特征
    LZBluetoothErrorCodeNoCharacteristic,
    /// 设备回ack报错
    LZBluetoothErrorCodeTimeout,
    /// 丢弃或者取消
    LZBluetoothErrorCodeDiscarded,
    /// 协议ack报错
    LZBluetoothErrorCodeACKError,
    /// 蓝牙库报的错误
    LZBluetoothErrorCodeBluetoothError,
    /// 工作繁忙，比如ota升级
    LZBluetoothErrorCodeWorkingBusy,
    /// ota文件不支持
    LZBluetoothErrorCodeFileUnsupported,
    /// 低电量
    LZBluetoothErrorCodeLowBattery,
    /// 不支持类型
    LZBluetoothErrorCodeUnsupported,
    /// 鉴权失败
    LZBluetoothErrorCodeAuthorizeFailure,
    /// 未知错误
    LZBluetoothErrorCodeUnknow = 9999,
};

@class LZBaseDevice;

/// 发送数据回调
typedef void(^LZSendDataCompletion)(LZBluetoothErrorCode result);
typedef void(^LZDeviceHandlerCompletion)(LZBluetoothErrorCode errorCode);
typedef void(^LZReadMacCompletion)(NSString *_Nullable mac, LZBluetoothErrorCode errorCode);
typedef void(^LZDeviceReadCharValueCompletion)(NSData * _Nullable data, LZBluetoothErrorCode errorCode);
typedef void(^LZOtaCompletion)(LZBluetoothErrorCode result);
typedef void(^LZOtaProgress)(double progress);

typedef void(^LZFindDeviceCompletion)(__kindof LZBaseDevice *_Nullable device, LZBluetoothErrorCode errorCode);
typedef void(^LZSearchResultBlock)(__kindof LZBaseDevice *device);
typedef void(^LZBindDeviceBlock)(LZBaseDevice * _Nullable device, LZBindState bindState);

/// 蓝牙错误Domain
extern NSErrorDomain const LZBluetoothErrorDomain;
extern NSString *lz_errString(LZBluetoothErrorCode errorCode);

/// 设备信息所使用的key
typedef NSString *kLZBluetoothDeviceInfoKey;

/// 设备id
extern kLZBluetoothDeviceInfoKey const kLZBluetoothDeviceInfoKeySystemID;
/// 实际产品型号
extern kLZBluetoothDeviceInfoKey const kLZBluetoothDeviceInfoKeyModelName;
/// MAC 地址
extern kLZBluetoothDeviceInfoKey const kLZBluetoothDeviceInfoKeyMacAddress;
///固件版本“*XXX” 其中第一个“*”代表下面其中的之一 “S”表示正式版， “T”表示测试版， “X”表示内测版， “XXX”是数字，表示版本号
extern kLZBluetoothDeviceInfoKey const kLZBluetoothDeviceInfoKeyFirmwareVersion;
/// 硬件版本
extern kLZBluetoothDeviceInfoKey const kLZBluetoothDeviceInfoKeyHardwareVersion;
/// 固件版本
extern kLZBluetoothDeviceInfoKey const kLZBluetoothDeviceInfoKeySoftwareVersion;
/// 制造商
extern kLZBluetoothDeviceInfoKey const kLZBluetoothDeviceInfoKeyManufacturerName;
/// 厂商id 只有a6设备 才有
extern kLZBluetoothDeviceInfoKey const kLZBluetoothDeviceInfoKeyManufactureId;
/// 算法版本
extern kLZBluetoothDeviceInfoKey const kLZBluetoothDeviceInfoKeyAlgorithmVersion;
/// 设备信息服务id
extern NSString * const LZDeviceInfoServiceUuid;


NS_ASSUME_NONNULL_END
