//
//  Scale.h
//  Scale
//
//  Created by tanjian on 2022/2/14.
//

#import <Foundation/Foundation.h>

//! Project version number for Scale.
FOUNDATION_EXPORT double LZScaleVersionNumber;

//! Project version string for Scale.
FOUNDATION_EXPORT const unsigned char LZScaleVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Scale/PublicHeader.h>


#import <LZScale/LZA6Header.h>
#import <LZScale/LZScaleDefine.h>

