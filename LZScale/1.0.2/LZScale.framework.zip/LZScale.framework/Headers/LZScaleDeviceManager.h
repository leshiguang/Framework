//
//  LZScaleDeviceManager.h
//  LZBluetooth
//
//  Created by tanjian on 2020/12/7.
//



#import <LZBluetooth/LZBaseDeviceManager.h>



NS_ASSUME_NONNULL_BEGIN

@protocol LZScaleDeviceDelegate;
 
@interface LZScaleDeviceManager : LZBaseDeviceManager

@end

NS_ASSUME_NONNULL_END
